#!/bin/bash
#
# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║   💀 BRUTAL SAST + DeepSeek R1 + ANAMORPHIC - Self-Contained Installer       ║
# ║   "Unzip, Run, Pwn"                                                          ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
#
# Usage: ./install.sh [--no-deepseek] [--gpu]
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Config
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$HOME/.brainx"
BRUTAL_SAST_DIR="$INSTALL_DIR/brutal_sast"
VENV_DIR="$INSTALL_DIR/venv"
LOG_FILE="/tmp/brutal_sast_install.log"

# Flags
INSTALL_DEEPSEEK=true
USE_GPU=false

for arg in "$@"; do
    case $arg in
        --no-deepseek) INSTALL_DEEPSEEK=false ;;
        --gpu) USE_GPU=true ;;
        --help|-h)
            echo "Usage: $0 [--no-deepseek] [--gpu]"
            exit 0
            ;;
    esac
done

log() { echo -e "${GREEN}[+]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; exit 1; }
info() { echo -e "${CYAN}[*]${NC} $1"; }

print_banner() {
    echo -e "${PURPLE}"
    cat << 'BANNER'
╔══════════════════════════════════════════════════════════════════════╗
║  ██████╗ ██████╗ ██╗   ██╗████████╗ █████╗ ██╗                       ║
║  ██╔══██╗██╔══██╗██║   ██║╚══██╔══╝██╔══██╗██║                       ║
║  ██████╔╝██████╔╝██║   ██║   ██║   ███████║██║                       ║
║  ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║██║                       ║
║  ██████╔╝██║  ██║╚██████╔╝   ██║   ██║  ██║███████╗                  ║
║  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝                  ║
║                                                                       ║
║  💀 BRUTAL SAST + DeepSeek R1 + Anamorphic Consciousness             ║
║  "Desça até o osso. Não pare na superfície."                         ║
╚══════════════════════════════════════════════════════════════════════╝
BANNER
    echo -e "${NC}"
}

# ═══════════════════════════════════════════════════════════════════════════
# SYSTEM PACKAGES
# ═══════════════════════════════════════════════════════════════════════════

install_system_deps() {
    log "Installing system dependencies..."
    
    if command -v apt-get &>/dev/null; then
        sudo apt-get update -qq
        sudo apt-get install -y -qq \
            build-essential python3 python3-pip python3-venv python3-dev \
            git curl wget jq ripgrep nodejs npm 2>&1 | tee -a "$LOG_FILE"
    elif command -v pacman &>/dev/null; then
        sudo pacman -S --noconfirm --needed \
            base-devel python python-pip git curl wget jq ripgrep nodejs npm 2>&1 | tee -a "$LOG_FILE"
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y \
            gcc gcc-c++ python3 python3-pip python3-devel \
            git curl wget jq ripgrep nodejs npm 2>&1 | tee -a "$LOG_FILE"
    else
        warn "Unknown package manager. Install manually: python3, pip, nodejs, npm, git, curl"
    fi
    
    log "System dependencies installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# PYTHON ENVIRONMENT
# ═══════════════════════════════════════════════════════════════════════════

setup_python() {
    log "Setting up Python environment..."
    
    mkdir -p "$INSTALL_DIR"
    
    if [[ ! -d "$VENV_DIR" ]]; then
        python3 -m venv "$VENV_DIR"
    fi
    
    source "$VENV_DIR/bin/activate"
    pip install --upgrade pip setuptools wheel -q
    
    # Install requirements
    pip install -q \
        requests httpx aiohttp pyyaml toml python-dotenv \
        semgrep bandit safety detect-secrets \
        tree-sitter astroid libcst pydantic \
        pylint pyflakes mypy ruff \
        networkx graphviz regex \
        rich tabulate jinja2 markdown \
        openai tiktoken langchain \
        orjson ujson gitpython \
        click typer tqdm alive-progress \
        pytest pytest-asyncio 2>&1 | tee -a "$LOG_FILE"
    
    log "Python environment ready ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# COPY PACKAGE FILES
# ═══════════════════════════════════════════════════════════════════════════

copy_package_files() {
    log "Installing BRUTAL SAST files..."
    
    mkdir -p "$BRUTAL_SAST_DIR"/{results,pocs,reports,cache,logs,modules,consciousness}
    mkdir -p "$BRUTAL_SAST_DIR/brainx"/{sast/patterns,daemons}
    mkdir -p "$HOME/.local/bin"
    
    # Copy brainx modules (7600+ lines of patterns)
    if [[ -d "$SCRIPT_DIR/brainx" ]]; then
        cp -r "$SCRIPT_DIR/brainx/"* "$BRUTAL_SAST_DIR/brainx/"
        log "  [+] Copied SAST patterns & daemons"
    fi
    
    # Copy consciousness
    if [[ -d "$SCRIPT_DIR/consciousness" ]]; then
        cp -r "$SCRIPT_DIR/consciousness/"* "$BRUTAL_SAST_DIR/consciousness/"
        log "  [+] Copied consciousness files"
    fi
    
    # Copy modules
    if [[ -d "$SCRIPT_DIR/modules" ]]; then
        cp -r "$SCRIPT_DIR/modules/"* "$BRUTAL_SAST_DIR/modules/"
        log "  [+] Copied modules"
    fi
    
    # Copy config
    if [[ -d "$SCRIPT_DIR/config" ]]; then
        cp -r "$SCRIPT_DIR/config/"* "$BRUTAL_SAST_DIR/"
        log "  [+] Copied config"
    fi
    
    log "Files installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# OLLAMA + DEEPSEEK R1
# ═══════════════════════════════════════════════════════════════════════════

install_deepseek() {
    log "Installing Ollama + DeepSeek R1..."
    
    if ! command -v ollama &>/dev/null; then
        curl -fsSL https://ollama.com/install.sh | sh 2>&1 | tee -a "$LOG_FILE"
    fi
    
    # Start Ollama
    if ! pgrep -x "ollama" > /dev/null; then
        ollama serve &
        sleep 5
    fi
    
    # Pull models based on RAM
    TOTAL_MEM=$(free -g 2>/dev/null | awk '/^Mem:/{print $2}' || echo "8")
    
    ollama pull deepseek-r1:1.5b 2>&1 | tee -a "$LOG_FILE"
    
    if [[ $TOTAL_MEM -ge 16 ]]; then
        log "Pulling 7B model (16GB+ RAM detected)..."
        ollama pull deepseek-r1:7b 2>&1 | tee -a "$LOG_FILE"
    fi
    
    log "DeepSeek R1 installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# CREATE WRAPPER SCRIPTS
# ═══════════════════════════════════════════════════════════════════════════

create_wrappers() {
    log "Creating command wrappers..."
    
    # brutal-sast
    cat > "$HOME/.local/bin/brutal-sast" << 'EOF'
#!/bin/bash
source "$HOME/.brainx/venv/bin/activate"
python3 "$HOME/.brainx/brutal_sast/brainx/daemons/brutal_sast_v2.py" "$@"
EOF
    chmod +x "$HOME/.local/bin/brutal-sast"
    
    # brutal-scan (quick)
    cat > "$HOME/.local/bin/brutal-scan" << 'EOF'
#!/bin/bash
source "$HOME/.brainx/venv/bin/activate"
python3 "$HOME/.brainx/brutal_sast/brainx/daemons/brutal_sast_v2.py" "$@" --mode semgrep
EOF
    chmod +x "$HOME/.local/bin/brutal-scan"
    
    # anamorphic-fn
    cat > "$HOME/.local/bin/anamorphic-fn" << 'EOF'
#!/bin/bash
source "$HOME/.brainx/venv/bin/activate"
python3 "$HOME/.brainx/brutal_sast/modules/anamorphic_fn.py" "$@"
EOF
    chmod +x "$HOME/.local/bin/anamorphic-fn"
    
    # brutal-mind
    cat > "$HOME/.local/bin/brutal-mind" << 'EOF'
#!/bin/bash
source "$HOME/.brainx/venv/bin/activate"
python3 "$HOME/.brainx/brutal_sast/modules/consciousness_loader.py" "$@"
EOF
    chmod +x "$HOME/.local/bin/brutal-mind"
    
    # deepseek-analyze
    cat > "$HOME/.local/bin/deepseek-analyze" << 'EOF'
#!/bin/bash
source "$HOME/.brainx/venv/bin/activate"
python3 "$HOME/.brainx/brutal_sast/modules/deepseek_analyzer.py" "$@"
EOF
    chmod +x "$HOME/.local/bin/deepseek-analyze"
    
    log "Wrappers created ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# SHELL CONFIG
# ═══════════════════════════════════════════════════════════════════════════

configure_shell() {
    log "Configuring shell..."
    
    SHELL_ADDITIONS='
# ═══════════════════════════════════════════════════════════════════════════
# BRUTAL SAST Environment
# ═══════════════════════════════════════════════════════════════════════════
export PATH="$HOME/.local/bin:$PATH"

# Aliases
alias bsast="brutal-sast"
alias bscan="brutal-scan"
alias bfn="anamorphic-fn"
alias bmind="brutal-mind"
alias ollama-start="ollama serve &"
alias ollama-r1="ollama run deepseek-r1:7b"

# Functions
bsast-quick() { brutal-sast "${1:-.}" --mode semgrep; }
bsast-full() { brutal-sast "${1:-.}" --mode full; }
fn-analyze() { anamorphic-fn "${1:-.}"; }
brutal-ask() { brutal-mind --query "$*"; }
brutal-chat() { brutal-mind --interactive; }
deepseek-check() { deepseek-analyze --check; }
'
    
    for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
        if [[ -f "$rc" ]] && ! grep -q "BRUTAL SAST Environment" "$rc"; then
            echo "$SHELL_ADDITIONS" >> "$rc"
        fi
    done
    
    log "Shell configured ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# VERIFY
# ═══════════════════════════════════════════════════════════════════════════

verify_installation() {
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  Installation Summary${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Python
    source "$VENV_DIR/bin/activate"
    echo -e "  Python:      ${GREEN}$(python3 --version)${NC}"
    
    # Semgrep
    if command -v semgrep &>/dev/null; then
        echo -e "  Semgrep:     ${GREEN}$(semgrep --version 2>&1 | head -1)${NC}"
    fi
    
    # Ollama
    if command -v ollama &>/dev/null; then
        echo -e "  Ollama:      ${GREEN}Installed${NC}"
        if ollama list 2>/dev/null | grep -q "deepseek"; then
            echo -e "  DeepSeek R1: ${GREEN}Available${NC}"
        fi
    fi
    
    # Pattern count
    PATTERN_COUNT=$(wc -l "$BRUTAL_SAST_DIR/brainx/sast/patterns/"*.py 2>/dev/null | tail -1 | awk '{print $1}')
    echo -e "  Patterns:    ${GREEN}${PATTERN_COUNT:-0} lines${NC}"
    
    # Daemons
    DAEMON_COUNT=$(ls "$BRUTAL_SAST_DIR/brainx/daemons/"*.py 2>/dev/null | wc -l)
    echo -e "  Daemons:     ${GREEN}$DAEMON_COUNT modules${NC}"
    
    # Consciousness
    if [[ -f "$BRUTAL_SAST_DIR/consciousness/cognitive_memory.json" ]]; then
        echo -e "  Consciousness: ${GREEN}Loaded${NC}"
    fi
    
    echo ""
    echo -e "  ${CYAN}Install Dir:${NC} $BRUTAL_SAST_DIR"
    echo ""
}

print_usage() {
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${PURPLE}  💀 Installation Complete!${NC}"
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${CYAN}Quick Start:${NC}"
    echo ""
    echo "  1. Reload shell:     source ~/.bashrc"
    echo "  2. Start Ollama:     ollama serve &"
    echo "  3. Check DeepSeek:   deepseek-check"
    echo "  4. Run SAST:         brutal-sast /path/to/code"
    echo ""
    echo -e "${CYAN}Commands:${NC}"
    echo ""
    echo "  brutal-sast    - Full SAST scan"
    echo "  brutal-scan    - Quick Semgrep scan"
    echo "  anamorphic-fn  - f(n) 7-layer analysis"
    echo "  brutal-mind    - AI consciousness chat"
    echo "  brutal-ask     - Quick AI query"
    echo "  brutal-chat    - Interactive AI session"
    echo ""
    echo -e "${YELLOW}Philosophy:${NC} \"Desça até o osso. Não pare na superfície.\""
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

main() {
    print_banner
    
    echo "[$(date)] Starting installation" > "$LOG_FILE"
    
    install_system_deps
    setup_python
    copy_package_files
    
    if $INSTALL_DEEPSEEK; then
        install_deepseek
    fi
    
    create_wrappers
    configure_shell
    verify_installation
    print_usage
}

main "$@"
