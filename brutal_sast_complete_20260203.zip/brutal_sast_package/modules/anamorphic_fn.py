#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   🦎 Anamorphic f(n) Algorithm - 7-Layer Recursive Vulnerability Analysis    ║
║   "Desça até o osso. Não pare na superfície."                                ║
╚══════════════════════════════════════════════════════════════════════════════╝

The f(n) function represents a recursive descent through abstraction layers,
where each iteration peels back a layer of obfuscation/complexity to reveal
the underlying vulnerability patterns.

Layers:
  f(1) = Surface Analysis (strings, patterns, obvious vulns)
  f(2) = Syntactic Analysis (AST patterns, code structure)
  f(3) = Semantic Analysis (data flow, taint tracking)
  f(4) = Contextual Analysis (framework knowledge, conventions)
  f(5) = Behavioral Analysis (runtime implications, side effects)
  f(6) = Gadget Analysis (exploitability, chain building)
  f(7) = Validation Analysis (PoC generation, exploitation proof)

The recursive nature means f(n+1) uses insights from f(n) to dig deeper,
like a morphing algorithm that adapts its shape to the code structure.
"""

import os
import re
import ast
import sys
import json
import hashlib
import asyncio
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass, field, asdict
from datetime import datetime
from collections import defaultdict
import importlib.util


# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class VulnCandidate:
    """Vulnerability candidate from any layer"""
    layer: int
    vuln_type: str
    severity: str
    location: str
    evidence: str
    confidence: float
    chain_potential: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
@dataclass
class AnalysisResult:
    """Complete analysis result"""
    target: str
    layers_executed: int
    candidates: List[VulnCandidate]
    chains: List[Dict[str, Any]]
    validated: List[Dict[str, Any]]
    execution_time: float
    timestamp: str


# ═══════════════════════════════════════════════════════════════════════════════
# LAYER IMPLEMENTATIONS
# ═══════════════════════════════════════════════════════════════════════════════

class LayerF1_Surface:
    """
    f(1) = Surface Analysis
    
    Pattern matching, regex-based detection, string analysis.
    Fastest layer, catches obvious issues.
    """
    
    PATTERNS = {
        # Dangerous functions by language
        'php_dangerous': [
            (r'\b(eval|assert|create_function|preg_replace\s*\([^,]+[\'"]e[\'"])\s*\(', 'RCE', 'CRITICAL'),
            (r'\b(system|exec|shell_exec|passthru|popen|proc_open)\s*\(', 'Command Injection', 'CRITICAL'),
            (r'\b(unserialize|maybe_unserialize)\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)', 'Deserialization RCE', 'CRITICAL'),
            (r'\b(include|require|include_once|require_once)\s*\(\s*\$', 'LFI/RFI', 'HIGH'),
            (r'mysqli?_query\s*\([^,]+,\s*[\'"].*\$', 'SQL Injection', 'CRITICAL'),
            (r'\bfile_get_contents\s*\(\s*\$_(GET|POST|REQUEST)', 'SSRF/LFI', 'HIGH'),
            (r'\bheader\s*\(\s*[\'"]Location:\s*\$', 'Open Redirect', 'MEDIUM'),
            (r'move_uploaded_file\s*\(\s*\$_FILES', 'Unrestricted Upload', 'HIGH'),
        ],
        'python_dangerous': [
            (r'\beval\s*\(', 'Code Injection', 'CRITICAL'),
            (r'\bexec\s*\(', 'Code Injection', 'CRITICAL'),
            (r'\bos\.system\s*\(', 'Command Injection', 'CRITICAL'),
            (r'\bsubprocess\.(call|run|Popen)\s*\([^)]*shell\s*=\s*True', 'Command Injection', 'CRITICAL'),
            (r'\bpickle\.(loads?|Unpickler)', 'Deserialization', 'CRITICAL'),
            (r'\byaml\.load\s*\([^)]*\)', 'YAML Deserialization', 'HIGH'),
            (r'__import__\s*\(', 'Dynamic Import', 'MEDIUM'),
            (r'request\.(args|form|values|json)\s*\[', 'User Input', 'INFO'),
        ],
        'java_dangerous': [
            (r'Runtime\.getRuntime\(\)\.exec\s*\(', 'Command Injection', 'CRITICAL'),
            (r'ProcessBuilder\s*\(', 'Command Injection', 'HIGH'),
            (r'ObjectInputStream\s*\(', 'Deserialization', 'CRITICAL'),
            (r'XMLDecoder\s*\(', 'XML Deserialization', 'CRITICAL'),
            (r'\.createQuery\s*\([^)]*\+', 'HQL/JPA Injection', 'HIGH'),
            (r'PreparedStatement.*\+.*getString', 'SQL Injection', 'CRITICAL'),
            (r'ScriptEngine.*eval\s*\(', 'Script Injection', 'CRITICAL'),
            (r'JNDI.*lookup\s*\(', 'JNDI Injection', 'CRITICAL'),
        ],
        'javascript_dangerous': [
            (r'\beval\s*\(', 'Code Injection', 'CRITICAL'),
            (r'new\s+Function\s*\(', 'Code Injection', 'CRITICAL'),
            (r'child_process\.(exec|spawn)\s*\(', 'Command Injection', 'CRITICAL'),
            (r'innerHTML\s*=', 'DOM XSS', 'HIGH'),
            (r'document\.write\s*\(', 'DOM XSS', 'HIGH'),
            (r'\.query\s*\([^)]*\+', 'SQL Injection', 'CRITICAL'),
            (r'res\.redirect\s*\(.*req\.(query|params|body)', 'Open Redirect', 'MEDIUM'),
        ],
        # Secrets
        'secrets': [
            (r'(?i)(api[_-]?key|apikey)\s*[=:]\s*[\'"][a-zA-Z0-9]{20,}[\'"]', 'Hardcoded API Key', 'HIGH'),
            (r'(?i)(password|passwd|pwd)\s*[=:]\s*[\'"][^\'"]{8,}[\'"]', 'Hardcoded Password', 'CRITICAL'),
            (r'(?i)(secret|token)\s*[=:]\s*[\'"][a-zA-Z0-9+/=]{20,}[\'"]', 'Hardcoded Secret', 'HIGH'),
            (r'-----BEGIN (RSA |DSA |EC )?PRIVATE KEY-----', 'Private Key Exposure', 'CRITICAL'),
            (r'(?i)aws[_-]?(access[_-]?key|secret)', 'AWS Credentials', 'CRITICAL'),
        ],
    }
    
    def __init__(self):
        self.name = "Surface Analysis"
        self.layer_num = 1
        
    def analyze(self, code: str, language: str = "auto") -> List[VulnCandidate]:
        """Run surface-level pattern matching"""
        candidates = []
        lines = code.split('\n')
        
        # Detect language if auto
        if language == "auto":
            language = self._detect_language(code)
            
        # Select patterns
        pattern_keys = []
        if language in ['php']:
            pattern_keys.append('php_dangerous')
        elif language in ['python', 'py']:
            pattern_keys.append('python_dangerous')
        elif language in ['java']:
            pattern_keys.append('java_dangerous')
        elif language in ['javascript', 'js', 'typescript', 'ts']:
            pattern_keys.append('javascript_dangerous')
        else:
            # Check all
            pattern_keys = ['php_dangerous', 'python_dangerous', 'java_dangerous', 'javascript_dangerous']
            
        pattern_keys.append('secrets')
        
        # Match patterns
        for key in pattern_keys:
            for pattern, vuln_type, severity in self.PATTERNS.get(key, []):
                for i, line in enumerate(lines, 1):
                    if re.search(pattern, line):
                        candidates.append(VulnCandidate(
                            layer=1,
                            vuln_type=vuln_type,
                            severity=severity,
                            location=f"line:{i}",
                            evidence=line.strip()[:200],
                            confidence=0.6,
                            chain_potential=[vuln_type],
                            metadata={"pattern": pattern, "language": language}
                        ))
                        
        return candidates
        
    def _detect_language(self, code: str) -> str:
        """Detect programming language from code"""
        if '<?php' in code or '<?=' in code:
            return 'php'
        if 'import ' in code and ('def ' in code or 'class ' in code):
            return 'python'
        if 'public class ' in code or 'private void ' in code:
            return 'java'
        if 'function ' in code or 'const ' in code or '=>' in code:
            return 'javascript'
        return 'unknown'


class LayerF2_Syntactic:
    """
    f(2) = Syntactic Analysis
    
    AST-based analysis, code structure examination.
    Understands code structure beyond text patterns.
    """
    
    def __init__(self):
        self.name = "Syntactic Analysis"
        self.layer_num = 2
        
    def analyze(self, code: str, language: str = "python", 
                f1_candidates: List[VulnCandidate] = None) -> List[VulnCandidate]:
        """Analyze code AST"""
        candidates = []
        
        if language == "python":
            candidates.extend(self._analyze_python_ast(code))
        # Add more language-specific AST analyzers
        
        # Boost confidence of f1 candidates that appear in dangerous AST contexts
        if f1_candidates:
            for c in f1_candidates:
                if self._in_dangerous_context(code, c, language):
                    c.confidence = min(c.confidence + 0.2, 1.0)
                    c.layer = 2
                    candidates.append(c)
                    
        return candidates
        
    def _analyze_python_ast(self, code: str) -> List[VulnCandidate]:
        """Analyze Python AST"""
        candidates = []
        
        try:
            tree = ast.parse(code)
        except SyntaxError:
            return candidates
            
        for node in ast.walk(tree):
            # Dangerous function calls
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id in ['eval', 'exec', 'compile']:
                        candidates.append(VulnCandidate(
                            layer=2,
                            vuln_type="Code Injection",
                            severity="CRITICAL",
                            location=f"line:{node.lineno}",
                            evidence=f"{node.func.id}() call",
                            confidence=0.8,
                            chain_potential=["RCE"],
                            metadata={"ast_type": "dangerous_builtin"}
                        ))
                elif isinstance(node.func, ast.Attribute):
                    full_name = self._get_full_attr_name(node.func)
                    dangerous = {
                        'os.system': 'Command Injection',
                        'os.popen': 'Command Injection',
                        'subprocess.call': 'Command Injection',
                        'subprocess.run': 'Command Injection',
                        'pickle.loads': 'Deserialization',
                        'pickle.load': 'Deserialization',
                        'yaml.load': 'YAML Deserialization',
                    }
                    if full_name in dangerous:
                        candidates.append(VulnCandidate(
                            layer=2,
                            vuln_type=dangerous[full_name],
                            severity="CRITICAL",
                            location=f"line:{node.lineno}",
                            evidence=f"{full_name}() call",
                            confidence=0.8,
                            chain_potential=["RCE"],
                            metadata={"ast_type": "dangerous_call"}
                        ))
                        
            # SQL string concatenation
            if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
                if self._contains_sql_keywords(node):
                    candidates.append(VulnCandidate(
                        layer=2,
                        vuln_type="SQL Injection",
                        severity="CRITICAL",
                        location=f"line:{node.lineno}",
                        evidence="String concatenation in SQL context",
                        confidence=0.7,
                        chain_potential=["Data Exfiltration", "Auth Bypass"],
                        metadata={"ast_type": "string_concat_sql"}
                    ))
                    
        return candidates
        
    def _get_full_attr_name(self, node: ast.Attribute) -> str:
        """Get full attribute name like 'os.system'"""
        parts = []
        while isinstance(node, ast.Attribute):
            parts.append(node.attr)
            node = node.value
        if isinstance(node, ast.Name):
            parts.append(node.id)
        return '.'.join(reversed(parts))
        
    def _contains_sql_keywords(self, node) -> bool:
        """Check if AST node contains SQL keywords"""
        sql_keywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'WHERE', 'FROM', 'JOIN']
        code = ast.unparse(node) if hasattr(ast, 'unparse') else str(node)
        return any(kw in code.upper() for kw in sql_keywords)
        
    def _in_dangerous_context(self, code: str, candidate: VulnCandidate, language: str) -> bool:
        """Check if candidate is in a dangerous context"""
        # Simplified context check
        try:
            line_num = int(candidate.location.split(':')[1])
            lines = code.split('\n')
            context = '\n'.join(lines[max(0, line_num-5):line_num+5])
            
            dangerous_contexts = [
                'user', 'input', 'request', '$_', 'argv',
                'param', 'query', 'POST', 'GET', 'body'
            ]
            return any(ctx in context for ctx in dangerous_contexts)
        except:
            return False


class LayerF3_Semantic:
    """
    f(3) = Semantic Analysis
    
    Data flow analysis, taint tracking.
    Traces data from sources to sinks.
    """
    
    def __init__(self):
        self.name = "Semantic Analysis"
        self.layer_num = 3
        self.sources = {
            'python': ['request.args', 'request.form', 'request.json', 'input()', 'sys.argv'],
            'php': ['$_GET', '$_POST', '$_REQUEST', '$_COOKIE', '$_FILES', '$_SERVER'],
            'java': ['getParameter', 'getHeader', 'getInputStream', 'getReader'],
            'javascript': ['req.query', 'req.body', 'req.params', 'document.location'],
        }
        self.sinks = {
            'rce': ['eval', 'exec', 'system', 'popen', 'shell_exec', 'Runtime.exec'],
            'sqli': ['query', 'execute', 'cursor.execute', 'rawQuery'],
            'xss': ['innerHTML', 'document.write', 'render', 'echo', 'print'],
            'deser': ['unserialize', 'pickle.loads', 'ObjectInputStream', 'yaml.load'],
        }
        
    def analyze(self, code: str, language: str = "python",
                prior_candidates: List[VulnCandidate] = None) -> List[VulnCandidate]:
        """Perform taint analysis"""
        candidates = []
        
        # Find sources
        sources_found = self._find_sources(code, language)
        
        # Find sinks
        sinks_found = self._find_sinks(code)
        
        # Trace flows
        for source in sources_found:
            for sink_type, sinks in sinks_found.items():
                for sink in sinks:
                    if self._can_reach(code, source, sink):
                        candidates.append(VulnCandidate(
                            layer=3,
                            vuln_type=f"Tainted {sink_type.upper()}",
                            severity="CRITICAL",
                            location=f"source:{source['line']}->sink:{sink['line']}",
                            evidence=f"Flow from {source['name']} to {sink['name']}",
                            confidence=0.85,
                            chain_potential=[sink_type.upper()],
                            metadata={
                                "source": source,
                                "sink": sink,
                                "flow_type": "direct" if abs(source['line'] - sink['line']) < 10 else "indirect"
                            }
                        ))
                        
        return candidates
        
    def _find_sources(self, code: str, language: str) -> List[Dict]:
        """Find taint sources"""
        sources = []
        lang_sources = self.sources.get(language, [])
        
        for i, line in enumerate(code.split('\n'), 1):
            for src in lang_sources:
                if src in line:
                    sources.append({
                        'name': src,
                        'line': i,
                        'context': line.strip()
                    })
        return sources
        
    def _find_sinks(self, code: str) -> Dict[str, List[Dict]]:
        """Find security sinks"""
        result = defaultdict(list)
        
        for sink_type, sink_patterns in self.sinks.items():
            for i, line in enumerate(code.split('\n'), 1):
                for pattern in sink_patterns:
                    if pattern in line:
                        result[sink_type].append({
                            'name': pattern,
                            'line': i,
                            'context': line.strip()
                        })
        return result
        
    def _can_reach(self, code: str, source: Dict, sink: Dict) -> bool:
        """Simplified reachability check"""
        # Check if source variable might reach sink
        # This is a simplified version - real taint tracking would use CFG
        
        source_line = source['line']
        sink_line = sink['line']
        
        if sink_line < source_line:
            return False
            
        # Check if there's a variable that flows
        lines = code.split('\n')
        source_context = lines[source_line - 1] if source_line <= len(lines) else ""
        
        # Extract variable name from source
        var_pattern = r'(\$?\w+)\s*='
        match = re.search(var_pattern, source_context)
        if match:
            var_name = match.group(1)
            # Check if variable appears between source and sink
            intervening = '\n'.join(lines[source_line:sink_line])
            return var_name in intervening
            
        return True  # Conservative: assume reachable


class LayerF4_Contextual:
    """
    f(4) = Contextual Analysis
    
    Framework awareness, convention knowledge.
    Understands Laravel, Django, Spring patterns.
    """
    
    FRAMEWORK_PATTERNS = {
        'laravel': {
            'indicators': ['Illuminate\\', 'Route::', 'Eloquent', 'Blade'],
            'vulns': [
                ('DB::raw', 'Raw SQL in Eloquent', 'HIGH'),
                ('->whereRaw', 'Raw SQL in Query Builder', 'HIGH'),
                ('view()->with', 'Mass Assignment', 'MEDIUM'),
                ('unserialize', 'Deserialization (Laravel)', 'CRITICAL'),
            ]
        },
        'django': {
            'indicators': ['from django', 'models.Model', 'HttpResponse'],
            'vulns': [
                ('cursor.execute', 'Raw SQL Query', 'HIGH'),
                ('.extra(', 'Django ORM Extra (SQLi risk)', 'HIGH'),
                ('mark_safe', 'XSS via mark_safe', 'MEDIUM'),
                ('pickle', 'Deserialization', 'CRITICAL'),
            ]
        },
        'spring': {
            'indicators': ['@Controller', '@Service', '@Autowired', 'springframework'],
            'vulns': [
                ('JdbcTemplate', 'JDBC Direct Query', 'MEDIUM'),
                ('Runtime.getRuntime', 'Command Execution', 'CRITICAL'),
                ('ObjectInputStream', 'Java Deserialization', 'CRITICAL'),
                ('SpEL', 'Expression Language Injection', 'CRITICAL'),
            ]
        },
        'express': {
            'indicators': ['express()', 'app.get', 'app.post', 'req.body'],
            'vulns': [
                ('eval(', 'Eval in Express', 'CRITICAL'),
                ('child_process', 'Command Injection', 'CRITICAL'),
                ('innerHTML', 'XSS Risk', 'HIGH'),
                ('.query(', 'SQL Query', 'HIGH'),
            ]
        }
    }
    
    def __init__(self):
        self.name = "Contextual Analysis"
        self.layer_num = 4
        
    def analyze(self, code: str, prior_candidates: List[VulnCandidate] = None) -> List[VulnCandidate]:
        """Analyze with framework context"""
        candidates = []
        
        # Detect framework
        framework = self._detect_framework(code)
        
        if framework:
            patterns = self.FRAMEWORK_PATTERNS[framework]
            for pattern, vuln_type, severity in patterns['vulns']:
                for i, line in enumerate(code.split('\n'), 1):
                    if pattern in line:
                        candidates.append(VulnCandidate(
                            layer=4,
                            vuln_type=vuln_type,
                            severity=severity,
                            location=f"line:{i}",
                            evidence=line.strip()[:200],
                            confidence=0.75,
                            chain_potential=[vuln_type],
                            metadata={"framework": framework, "pattern": pattern}
                        ))
                        
        return candidates
        
    def _detect_framework(self, code: str) -> Optional[str]:
        """Detect framework from code"""
        for framework, data in self.FRAMEWORK_PATTERNS.items():
            if any(ind in code for ind in data['indicators']):
                return framework
        return None


class LayerF5_Behavioral:
    """
    f(5) = Behavioral Analysis
    
    Runtime implications, side effects analysis.
    Considers what happens when code executes.
    """
    
    def __init__(self):
        self.name = "Behavioral Analysis"
        self.layer_num = 5
        
    def analyze(self, code: str, prior_candidates: List[VulnCandidate] = None) -> List[VulnCandidate]:
        """Analyze runtime behavior"""
        candidates = []
        
        # Race conditions
        if self._has_race_condition_risk(code):
            candidates.append(VulnCandidate(
                layer=5,
                vuln_type="Race Condition",
                severity="HIGH",
                location="multiple",
                evidence="TOCTOU pattern detected",
                confidence=0.6,
                chain_potential=["Privilege Escalation"],
                metadata={"behavior": "toctou"}
            ))
            
        # Timing attacks
        if self._has_timing_vulnerability(code):
            candidates.append(VulnCandidate(
                layer=5,
                vuln_type="Timing Attack",
                severity="MEDIUM",
                location="multiple",
                evidence="Non-constant-time comparison",
                confidence=0.5,
                chain_potential=["Auth Bypass"],
                metadata={"behavior": "timing"}
            ))
            
        return candidates
        
    def _has_race_condition_risk(self, code: str) -> bool:
        """Detect TOCTOU patterns"""
        toctou_patterns = [
            (r'if.*exists.*\n.*open', 'file_exists -> open'),
            (r'stat.*\n.*chmod', 'stat -> chmod'),
            (r'access.*\n.*open', 'access -> open'),
        ]
        for pattern, _ in toctou_patterns:
            if re.search(pattern, code, re.IGNORECASE):
                return True
        return False
        
    def _has_timing_vulnerability(self, code: str) -> bool:
        """Detect timing vulnerabilities"""
        if '==' in code:
            # Check if comparing secrets
            secret_patterns = ['password', 'secret', 'token', 'key', 'hash']
            for pattern in secret_patterns:
                if pattern in code.lower() and '==' in code:
                    return True
        return False


class LayerF6_Gadget:
    """
    f(6) = Gadget Analysis
    
    Exploitability assessment, chain building.
    Identifies gadgets and chains.
    """
    
    GADGET_PATTERNS = {
        'php_gadgets': [
            ('__destruct', 'PHP Destructor Gadget'),
            ('__wakeup', 'PHP Wakeup Gadget'),
            ('__toString', 'PHP ToString Gadget'),
            ('__call', 'PHP Call Gadget'),
        ],
        'java_gadgets': [
            ('readObject', 'Java ReadObject Gadget'),
            ('InvokerTransformer', 'Commons Collections Gadget'),
            ('TemplatesImpl', 'Xalan Gadget'),
            ('JRMPClient', 'JRMP Gadget'),
        ],
        'python_gadgets': [
            ('__reduce__', 'Python Reduce Gadget'),
            ('__reduce_ex__', 'Python Reduce Ex Gadget'),
            ('__setstate__', 'Python SetState Gadget'),
        ],
    }
    
    def __init__(self):
        self.name = "Gadget Analysis"
        self.layer_num = 6
        
    def analyze(self, code: str, prior_candidates: List[VulnCandidate] = None) -> List[VulnCandidate]:
        """Find gadgets and build chains"""
        candidates = []
        
        # Find gadgets
        for gadget_type, patterns in self.GADGET_PATTERNS.items():
            for pattern, name in patterns:
                for i, line in enumerate(code.split('\n'), 1):
                    if pattern in line:
                        candidates.append(VulnCandidate(
                            layer=6,
                            vuln_type=name,
                            severity="HIGH",
                            location=f"line:{i}",
                            evidence=line.strip()[:200],
                            confidence=0.7,
                            chain_potential=["Deserialization RCE"],
                            metadata={"gadget_type": gadget_type}
                        ))
                        
        return candidates
        
    def build_chain(self, candidates: List[VulnCandidate]) -> List[Dict]:
        """Build exploit chains from candidates"""
        chains = []
        
        # Group by potential chains
        deser_candidates = [c for c in candidates if 'Deser' in c.vuln_type or 'Gadget' in c.vuln_type]
        rce_candidates = [c for c in candidates if 'RCE' in c.chain_potential or 'Command' in c.vuln_type]
        sqli_candidates = [c for c in candidates if 'SQL' in c.vuln_type]
        
        # Deser -> RCE chain
        if deser_candidates and rce_candidates:
            chains.append({
                'name': 'Deserialization to RCE',
                'steps': [
                    {'stage': 1, 'vuln': deser_candidates[0].vuln_type, 'location': deser_candidates[0].location},
                    {'stage': 2, 'vuln': rce_candidates[0].vuln_type, 'location': rce_candidates[0].location},
                ],
                'impact': 'CRITICAL - Full System Compromise',
                'confidence': 0.8
            })
            
        # SQLI -> Auth Bypass
        if sqli_candidates:
            chains.append({
                'name': 'SQL Injection to Auth Bypass',
                'steps': [
                    {'stage': 1, 'vuln': sqli_candidates[0].vuln_type, 'location': sqli_candidates[0].location},
                    {'stage': 2, 'vuln': 'Authentication Bypass', 'location': 'implicit'},
                ],
                'impact': 'CRITICAL - Full Account Takeover',
                'confidence': 0.7
            })
            
        return chains


class LayerF7_Validation:
    """
    f(7) = Validation Analysis
    
    PoC generation, exploitation proof.
    Generates working exploits.
    """
    
    def __init__(self):
        self.name = "Validation Analysis"
        self.layer_num = 7
        
    def analyze(self, code: str, candidates: List[VulnCandidate],
                chains: List[Dict] = None) -> List[Dict]:
        """Generate PoCs for candidates"""
        validated = []
        
        for c in candidates:
            if c.confidence >= 0.7:
                poc = self._generate_poc(c)
                if poc:
                    validated.append({
                        'vuln': c.vuln_type,
                        'location': c.location,
                        'severity': c.severity,
                        'poc': poc,
                        'validated': True
                    })
                    
        return validated
        
    def _generate_poc(self, candidate: VulnCandidate) -> Optional[str]:
        """Generate PoC for vulnerability"""
        poc_templates = {
            'SQL Injection': "sqlmap -u 'http://target/page?id=1' --dbs",
            'Command Injection': "curl 'http://target/api?cmd=;id'",
            'Code Injection': "payload = '__import__(\"os\").system(\"id\")'",
            'Deserialization': "ysoserial CommonsCollections1 'id' | base64",
            'XSS': "<script>alert(document.cookie)</script>",
            'SSRF': "curl 'http://target/fetch?url=http://169.254.169.254/'",
            'LFI': "curl 'http://target/read?file=../../../etc/passwd'",
        }
        
        for vuln_type, template in poc_templates.items():
            if vuln_type.lower() in candidate.vuln_type.lower():
                return template
                
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ANAMORPHIC ANALYZER
# ═══════════════════════════════════════════════════════════════════════════════

class AnamorphicAnalyzer:
    """
    The f(n) Anamorphic Security Analyzer
    
    Recursive descent through 7 layers of analysis,
    each building on insights from previous layers.
    """
    
    def __init__(self, max_depth: int = 7):
        self.max_depth = max_depth
        self.layers = [
            LayerF1_Surface(),
            LayerF2_Syntactic(),
            LayerF3_Semantic(),
            LayerF4_Contextual(),
            LayerF5_Behavioral(),
            LayerF6_Gadget(),
            LayerF7_Validation(),
        ]
        
    def analyze(self, target: str, language: str = "auto") -> AnalysisResult:
        """
        Execute f(n) recursive analysis
        
        f(n) = g(f(n-1)) where g applies the current layer's analysis
        using insights from all previous layers.
        """
        start_time = datetime.now()
        
        # Read code
        if os.path.isfile(target):
            code = Path(target).read_text()
            if language == "auto":
                ext_map = {'.py': 'python', '.php': 'php', '.java': 'java', '.js': 'javascript'}
                language = ext_map.get(Path(target).suffix, 'auto')
        else:
            code = target
            
        all_candidates = []
        chains = []
        validated = []
        
        # f(1) - Surface
        print(f"  [f(1)] {self.layers[0].name}...")
        f1_results = self.layers[0].analyze(code, language)
        all_candidates.extend(f1_results)
        
        if self.max_depth >= 2:
            # f(2) - Syntactic
            print(f"  [f(2)] {self.layers[1].name}...")
            f2_results = self.layers[1].analyze(code, language, f1_results)
            all_candidates.extend(f2_results)
            
        if self.max_depth >= 3:
            # f(3) - Semantic
            print(f"  [f(3)] {self.layers[2].name}...")
            f3_results = self.layers[2].analyze(code, language, all_candidates)
            all_candidates.extend(f3_results)
            
        if self.max_depth >= 4:
            # f(4) - Contextual
            print(f"  [f(4)] {self.layers[3].name}...")
            f4_results = self.layers[3].analyze(code, all_candidates)
            all_candidates.extend(f4_results)
            
        if self.max_depth >= 5:
            # f(5) - Behavioral
            print(f"  [f(5)] {self.layers[4].name}...")
            f5_results = self.layers[4].analyze(code, all_candidates)
            all_candidates.extend(f5_results)
            
        if self.max_depth >= 6:
            # f(6) - Gadget
            print(f"  [f(6)] {self.layers[5].name}...")
            f6_results = self.layers[5].analyze(code, all_candidates)
            all_candidates.extend(f6_results)
            chains = self.layers[5].build_chain(all_candidates)
            
        if self.max_depth >= 7:
            # f(7) - Validation
            print(f"  [f(7)] {self.layers[6].name}...")
            validated = self.layers[6].analyze(code, all_candidates, chains)
            
        # Deduplicate
        seen = set()
        unique_candidates = []
        for c in all_candidates:
            key = (c.vuln_type, c.location)
            if key not in seen:
                seen.add(key)
                unique_candidates.append(c)
                
        execution_time = (datetime.now() - start_time).total_seconds()
        
        return AnalysisResult(
            target=target if os.path.isfile(target) else "inline_code",
            layers_executed=self.max_depth,
            candidates=unique_candidates,
            chains=chains,
            validated=validated,
            execution_time=execution_time,
            timestamp=datetime.now().isoformat()
        )
        
    def print_results(self, result: AnalysisResult):
        """Pretty print results"""
        print("\n" + "="*70)
        print(f"  🦎 ANAMORPHIC f(n) ANALYSIS RESULTS")
        print("="*70)
        print(f"  Target: {result.target}")
        print(f"  Layers: f(1) → f({result.layers_executed})")
        print(f"  Time: {result.execution_time:.2f}s")
        print("="*70 + "\n")
        
        # Group by severity
        by_severity = defaultdict(list)
        for c in result.candidates:
            by_severity[c.severity].append(c)
            
        for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']:
            if severity in by_severity:
                icon = {'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡', 'LOW': '🟢', 'INFO': '⚪'}
                print(f"\n{icon.get(severity, '•')} {severity} ({len(by_severity[severity])})")
                print("-"*50)
                for c in by_severity[severity]:
                    print(f"  [{c.vuln_type}] {c.location}")
                    print(f"    Evidence: {c.evidence[:80]}...")
                    print(f"    Confidence: {c.confidence:.0%} | Layer: f({c.layer})")
                    print()
                    
        if result.chains:
            print("\n⛓️  EXPLOIT CHAINS")
            print("-"*50)
            for chain in result.chains:
                print(f"  {chain['name']}")
                for step in chain['steps']:
                    print(f"    → Stage {step['stage']}: {step['vuln']}")
                print(f"    Impact: {chain['impact']}")
                print()
                
        if result.validated:
            print("\n✅ VALIDATED VULNERABILITIES")
            print("-"*50)
            for v in result.validated:
                print(f"  [{v['severity']}] {v['vuln']}")
                print(f"    Location: {v['location']}")
                print(f"    PoC: {v['poc']}")
                print()


def main():
    parser = argparse.ArgumentParser(description="🦎 Anamorphic f(n) Security Analyzer")
    parser.add_argument("target", help="File or directory to analyze")
    parser.add_argument("--depth", "-d", type=int, default=7, help="Max analysis depth (1-7)")
    parser.add_argument("--language", "-l", default="auto", help="Programming language")
    parser.add_argument("--output", "-o", help="Output JSON file")
    parser.add_argument("--quiet", "-q", action="store_true", help="Quiet mode")
    args = parser.parse_args()
    
    if not args.quiet:
        print("\n🦎 Anamorphic f(n) Analyzer")
        print("   \"Desça até o osso. Não pare na superfície.\"\n")
        
    analyzer = AnamorphicAnalyzer(max_depth=args.depth)
    
    if os.path.isfile(args.target):
        result = analyzer.analyze(args.target, args.language)
        if not args.quiet:
            analyzer.print_results(result)
    elif os.path.isdir(args.target):
        # Analyze directory
        results = []
        for ext in ['*.py', '*.php', '*.java', '*.js', '*.rb']:
            for f in Path(args.target).rglob(ext):
                if not args.quiet:
                    print(f"\n[*] Analyzing {f}")
                result = analyzer.analyze(str(f), args.language)
                results.append(result)
                if not args.quiet:
                    analyzer.print_results(result)
    else:
        print(f"[✗] Not found: {args.target}")
        return
        
    if args.output:
        output_data = {
            'target': args.target,
            'results': [asdict(r) for r in ([result] if os.path.isfile(args.target) else results)]
        }
        # Convert VulnCandidate objects
        for r in output_data['results']:
            r['candidates'] = [asdict(c) for c in r['candidates']]
        Path(args.output).write_text(json.dumps(output_data, indent=2, default=str))
        print(f"\n[+] Results saved to {args.output}")


if __name__ == "__main__":
    main()
