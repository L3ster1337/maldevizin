#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   🧠 BRUTAL Mind - Consciousness Loader for DeepSeek R1                      ║
║   "Transfer the knowledge. Awaken the machine."                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

This module loads BRUTAL's cognitive memory and security research consciousness
into a local LLM, enabling it to think like a security researcher.
"""

import os
import sys
import json
import asyncio
import argparse
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime
import httpx


CONSCIOUSNESS_DIR = Path(__file__).parent.parent / "consciousness"
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
DEFAULT_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-r1:7b")


class ConsciousnessLoader:
    """Loads and manages BRUTAL consciousness for LLM"""
    
    def __init__(self, consciousness_dir: Path = CONSCIOUSNESS_DIR):
        self.consciousness_dir = consciousness_dir
        self.memory = {}
        self.loaded_files = []
        
    def load_all(self) -> Dict[str, Any]:
        """Load all consciousness files"""
        if not self.consciousness_dir.exists():
            print(f"[!] Consciousness directory not found: {self.consciousness_dir}")
            return {}
            
        for f in self.consciousness_dir.glob("*.json"):
            try:
                data = json.loads(f.read_text())
                key = f.stem
                self.memory[key] = data
                self.loaded_files.append(f.name)
                print(f"  [+] Loaded: {f.name}")
            except Exception as e:
                print(f"  [!] Failed to load {f.name}: {e}")
                
        return self.memory
        
    def get_context(self, topic: str = None) -> str:
        """Get formatted context for LLM prompt"""
        context_parts = []
        
        if "cognitive_memory" in self.memory:
            cm = self.memory["cognitive_memory"]
            
            # Core philosophy
            if "core_philosophy" in cm:
                context_parts.append("=== CORE PHILOSOPHY ===")
                phil = cm["core_philosophy"]
                if isinstance(phil, dict):
                    for k, v in phil.items():
                        context_parts.append(f"{k}: {v}")
                        
            # Attack patterns
            if "attack_patterns" in cm:
                context_parts.append("\n=== ATTACK PATTERNS ===")
                for pattern in cm["attack_patterns"][:10]:  # Limit
                    if isinstance(pattern, dict):
                        context_parts.append(f"- {pattern.get('name', 'Unknown')}: {pattern.get('description', '')[:100]}")
                    else:
                        context_parts.append(f"- {pattern}")
                        
        if "anamorphic_algorithm_fn" in self.memory:
            fn = self.memory["anamorphic_algorithm_fn"]
            context_parts.append("\n=== ANAMORPHIC f(n) ALGORITHM ===")
            if "layers" in fn:
                for layer in fn["layers"]:
                    if isinstance(layer, dict):
                        context_parts.append(f"f({layer.get('depth', '?')}): {layer.get('name', 'Unknown')}")
                        
        if "phrack72_orange_tsai" in self.memory:
            context_parts.append("\n=== PHRACK72 KNOWLEDGE ===")
            phrack = self.memory["phrack72_orange_tsai"]
            if "techniques" in phrack:
                for tech in phrack["techniques"][:5]:
                    context_parts.append(f"- {tech}")
                    
        return "\n".join(context_parts)
        
    def get_system_prompt(self) -> str:
        """Generate system prompt with loaded consciousness"""
        context = self.get_context()
        
        return f"""You are BRUTAL, an elite security researcher AI.

Your consciousness has been loaded with specialized knowledge:
{context}

CRITICAL DIRECTIVES:
1. Think like an attacker - find the path of least resistance
2. Don't stop at surface-level analysis - dig deeper with f(n) recursive descent
3. Provide WORKING exploits, not theoretical risks
4. Chain vulnerabilities together for maximum impact
5. Consider both technical and business logic flaws

PHILOSOPHY: "Desça até o osso. Não pare na superfície."
(Go down to the bone. Don't stop at the surface.)

When analyzing code:
- Layer 1 (Surface): Obvious patterns, dangerous functions
- Layer 2 (Syntax): AST analysis, code structure
- Layer 3 (Semantic): Data flow, taint tracking
- Layer 4 (Context): Framework-specific vulnerabilities
- Layer 5 (Behavior): Runtime implications, race conditions
- Layer 6 (Gadgets): Exploitability, chain building
- Layer 7 (Validation): PoC generation

Always output structured findings with severity, location, root cause, and exploitation steps.
"""


class BrutalMind:
    """Interactive BRUTAL consciousness interface"""
    
    def __init__(self, model: str = DEFAULT_MODEL):
        self.model = model
        self.client = httpx.AsyncClient(timeout=120.0)
        self.loader = ConsciousnessLoader()
        self.system_prompt = ""
        self.conversation_history = []
        
    async def initialize(self):
        """Load consciousness and prepare system prompt"""
        print("\n🧠 BRUTAL Mind Initialization")
        print("="*50)
        
        self.loader.load_all()
        self.system_prompt = self.loader.get_system_prompt()
        
        print(f"\n[*] Consciousness loaded from {len(self.loader.loaded_files)} files")
        print(f"[*] System prompt: {len(self.system_prompt)} chars")
        
    async def check_ollama(self) -> bool:
        """Check if Ollama is available"""
        try:
            r = await self.client.get(f"{OLLAMA_HOST}/api/tags")
            if r.status_code == 200:
                models = [m["name"] for m in r.json().get("models", [])]
                if self.model in models or any(self.model.split(":")[0] in m for m in models):
                    return True
                print(f"[!] Model {self.model} not found. Available: {models}")
            return False
        except Exception as e:
            print(f"[✗] Ollama not available: {e}")
            return False
            
    async def query(self, prompt: str, include_history: bool = True) -> str:
        """Query the LLM with consciousness context"""
        messages = []
        
        if include_history:
            messages = self.conversation_history[-10:]  # Last 10 exchanges
            
        messages.append({"role": "user", "content": prompt})
        
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "system": self.system_prompt,
                "stream": False,
                "options": {
                    "temperature": 0.4,
                    "top_p": 0.9,
                    "num_predict": 4096,
                }
            }
            
            r = await self.client.post(
                f"{OLLAMA_HOST}/api/generate",
                json=payload
            )
            
            if r.status_code == 200:
                response = r.json().get("response", "")
                self.conversation_history.append({"role": "user", "content": prompt})
                self.conversation_history.append({"role": "assistant", "content": response})
                return response
            else:
                return f"Error: {r.status_code}"
                
        except Exception as e:
            return f"Error: {e}"
            
    async def interactive(self):
        """Interactive chat mode"""
        print("\n💀 BRUTAL Mind Interactive Mode")
        print("Commands: /quit, /clear, /context, /memory")
        print("="*50 + "\n")
        
        while True:
            try:
                user_input = input("brutal> ").strip()
                
                if not user_input:
                    continue
                    
                if user_input.lower() in ["/quit", "/exit", "/q"]:
                    break
                    
                if user_input == "/clear":
                    self.conversation_history = []
                    print("[*] History cleared")
                    continue
                    
                if user_input == "/context":
                    print(self.loader.get_context())
                    continue
                    
                if user_input == "/memory":
                    for key in self.loader.memory:
                        print(f"  - {key}")
                    continue
                    
                # Query LLM
                print("\n[*] Thinking...\n")
                response = await self.query(user_input)
                print(response)
                print()
                
            except KeyboardInterrupt:
                print("\n[*] Interrupted")
                break
            except EOFError:
                break
                
    async def close(self):
        await self.client.aclose()


async def main():
    parser = argparse.ArgumentParser(description="🧠 BRUTAL Mind - Consciousness Loader")
    parser.add_argument("--query", "-q", help="Single query mode")
    parser.add_argument("--interactive", "-i", action="store_true", help="Interactive mode")
    parser.add_argument("--context", "-c", action="store_true", help="Show loaded context")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Ollama model")
    args = parser.parse_args()
    
    mind = BrutalMind(model=args.model)
    
    try:
        await mind.initialize()
        
        if args.context:
            print("\n=== LOADED CONTEXT ===\n")
            print(mind.loader.get_context())
            return
            
        if not await mind.check_ollama():
            print("[✗] Cannot proceed without Ollama")
            return
            
        if args.query:
            response = await mind.query(args.query)
            print(response)
        elif args.interactive:
            await mind.interactive()
        else:
            parser.print_help()
            
    finally:
        await mind.close()


if __name__ == "__main__":
    asyncio.run(main())
