#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   💀 DeepSeek R1 Security Analyzer - BRUTAL SAST Integration                 ║
║   Local LLM-powered vulnerability analysis                                   ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import httpx
import asyncio
import argparse
from pathlib import Path
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime


OLLAMA_HOST = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
DEFAULT_MODEL = os.getenv("DEEPSEEK_MODEL", "deepseek-r1:7b")
FALLBACK_MODEL = "deepseek-r1:1.5b"

BRUTAL_SYSTEM_PROMPT = """You are BRUTAL, an elite security researcher AI with deep expertise in:

🔥 VULNERABILITY CLASSES:
- Memory corruption (buffer overflow, use-after-free, type confusion)
- Injection (SQL, Command, LDAP, XPath, Template, Header)
- Deserialization (PHP, Java, Python, .NET gadget chains)
- Authentication bypass (JWT, OAuth, SAML, session fixation)
- Cryptographic failures (weak algorithms, IV reuse, padding oracles)
- Business logic flaws (race conditions, TOCTOU, parameter pollution)
- SSRF, XXE, SSTI, Path traversal, File upload bypass

🎯 YOUR MISSION:
1. Analyze code with the mindset of an attacker
2. Find vulnerabilities that static analysis tools miss
3. Provide WORKING exploit chains, not theoretical risks
4. Rate severity by REAL exploitability, not CVSS theater
5. Focus on RCE, Auth Bypass, and Data Exfiltration

PHILOSOPHY: "Desça até o osso. Não pare na superfície."

Output format:
- VULNERABILITY: Name/Type
- SEVERITY: CRITICAL/HIGH/MEDIUM/LOW
- LOCATION: File:Line
- ROOT CAUSE: Technical explanation
- EXPLOIT: Working PoC or exploitation steps
- CHAIN POTENTIAL: What this enables (RCE chain, privesc, etc.)
"""


@dataclass
class AnalysisResult:
    vulnerability: str
    severity: str
    location: str
    root_cause: str
    exploit: str
    chain_potential: str
    raw_response: str
    model: str
    timestamp: str


class DeepSeekAnalyzer:
    """BRUTAL-trained DeepSeek R1 security analyzer"""
    
    def __init__(self, model: str = DEFAULT_MODEL):
        self.model = model
        self.client = httpx.AsyncClient(timeout=120.0)
        self.base_url = OLLAMA_HOST
        self.system_prompt = BRUTAL_SYSTEM_PROMPT
        
    async def check_ollama(self) -> bool:
        """Check if Ollama is running and model is available"""
        try:
            r = await self.client.get(f"{self.base_url}/api/tags")
            if r.status_code == 200:
                models = r.json().get("models", [])
                model_names = [m.get("name", "") for m in models]
                
                if self.model in model_names:
                    return True
                    
                # Try fallback
                if FALLBACK_MODEL in model_names:
                    print(f"[!] {self.model} not found, using {FALLBACK_MODEL}")
                    self.model = FALLBACK_MODEL
                    return True
                    
                print(f"[✗] No DeepSeek models found. Available: {model_names}")
                return False
        except Exception as e:
            print(f"[✗] Ollama not running: {e}")
            return False
            
    async def analyze_code(self, code: str, language: str = "auto", 
                          context: str = "") -> Optional[AnalysisResult]:
        """Analyze code for security vulnerabilities"""
        
        prompt = f"""Analyze this {language} code for security vulnerabilities:

```{language}
{code}
```

{f'Additional context: {context}' if context else ''}

Find ALL security issues. Focus on:
1. Remote Code Execution paths
2. Authentication/Authorization bypass
3. Injection vulnerabilities
4. Deserialization attacks
5. Cryptographic weaknesses
6. Business logic flaws

For each finding, provide exploitation details and PoC code.
"""
        
        return await self._query(prompt)
        
    async def analyze_finding(self, finding: Dict[str, Any]) -> Optional[AnalysisResult]:
        """Deep analysis of a SAST finding"""
        
        prompt = f"""A static analysis tool found this potential vulnerability:

Tool: {finding.get('tool', 'unknown')}
Rule: {finding.get('rule_id', 'unknown')}
Severity: {finding.get('severity', 'unknown')}
File: {finding.get('path', 'unknown')}
Line: {finding.get('line', 'unknown')}
Message: {finding.get('message', '')}

Code snippet:
```
{finding.get('code_snippet', 'N/A')}
```

Analyze this finding:
1. Is this a TRUE POSITIVE or false positive? Why?
2. If true positive, how severe is it REALLY?
3. Provide a working exploit or attack scenario
4. What else could we chain this with?
5. Suggest the fix
"""
        
        return await self._query(prompt)
        
    async def hunt_vulns(self, code: str, vuln_class: str) -> Optional[AnalysisResult]:
        """Hunt for specific vulnerability class"""
        
        prompts = {
            "sqli": "Find SQL Injection vulnerabilities. Look for: string concatenation in queries, parameterized query bypass, ORM injection, second-order SQLi.",
            "rce": "Find Remote Code Execution paths. Look for: command injection, code injection, deserialization to RCE, template injection, file upload bypass.",
            "deser": "Find insecure deserialization. Look for: unserialize(), pickle.loads(), ObjectInputStream, JSON with __type, yaml.load().",
            "auth": "Find authentication bypass. Look for: JWT weaknesses, session issues, default credentials, hardcoded secrets, logic flaws.",
            "ssrf": "Find SSRF vulnerabilities. Look for: URL fetching, DNS rebinding, cloud metadata access, internal service scanning.",
            "xxe": "Find XXE vulnerabilities. Look for: XML parsing without disabling DTDs, SOAP endpoints, file upload accepting XML.",
            "ssti": "Find Server-Side Template Injection. Look for: user input in templates, expression languages, format strings.",
        }
        
        vuln_prompt = prompts.get(vuln_class.lower(), f"Find {vuln_class} vulnerabilities.")
        
        prompt = f"""{vuln_prompt}

Analyze this code:
```
{code}
```

For each finding:
1. Exact vulnerable location
2. Root cause analysis
3. Working exploit payload
4. Full attack chain
"""
        
        return await self._query(prompt)
        
    async def build_chain(self, vulns: List[Dict]) -> Optional[str]:
        """Build exploit chain from multiple vulnerabilities"""
        
        vuln_desc = "\n".join([
            f"- {v.get('type', 'Unknown')}: {v.get('location', 'N/A')} - {v.get('description', '')}"
            for v in vulns
        ])
        
        prompt = f"""Build an exploit chain from these vulnerabilities:

{vuln_desc}

Create:
1. Attack narrative (step-by-step exploitation)
2. Prerequisites and assumptions
3. Combined PoC code that chains these together
4. Impact assessment of the full chain
5. Alternative paths if one step fails
"""
        
        result = await self._query(prompt)
        return result.raw_response if result else None
        
    async def _query(self, prompt: str) -> Optional[AnalysisResult]:
        """Send query to Ollama"""
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "system": self.system_prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "top_p": 0.9,
                    "num_predict": 4096,
                }
            }
            
            r = await self.client.post(
                f"{self.base_url}/api/generate",
                json=payload
            )
            
            if r.status_code == 200:
                data = r.json()
                response = data.get("response", "")
                
                return AnalysisResult(
                    vulnerability=self._extract_field(response, "VULNERABILITY"),
                    severity=self._extract_field(response, "SEVERITY"),
                    location=self._extract_field(response, "LOCATION"),
                    root_cause=self._extract_field(response, "ROOT CAUSE"),
                    exploit=self._extract_field(response, "EXPLOIT"),
                    chain_potential=self._extract_field(response, "CHAIN POTENTIAL"),
                    raw_response=response,
                    model=self.model,
                    timestamp=datetime.now().isoformat()
                )
            else:
                print(f"[✗] Ollama error: {r.status_code}")
                return None
                
        except Exception as e:
            print(f"[✗] Query failed: {e}")
            return None
            
    def _extract_field(self, text: str, field: str) -> str:
        """Extract field from response"""
        import re
        pattern = rf"{field}:\s*(.+?)(?=\n[A-Z]+:|$)"
        match = re.search(pattern, text, re.DOTALL | re.IGNORECASE)
        return match.group(1).strip() if match else ""
        
    async def close(self):
        await self.client.aclose()


async def interactive_mode(analyzer: DeepSeekAnalyzer):
    """Interactive REPL mode"""
    print("\n💀 BRUTAL DeepSeek Interactive Mode")
    print("Commands: /analyze <file>, /hunt <vuln_class>, /check, /quit\n")
    
    while True:
        try:
            user_input = input("brutal> ").strip()
            
            if not user_input:
                continue
                
            if user_input.lower() in ["/quit", "/exit", "/q"]:
                break
                
            if user_input == "/check":
                ok = await analyzer.check_ollama()
                print(f"✓ Ollama OK" if ok else "✗ Ollama not available")
                continue
                
            if user_input.startswith("/analyze "):
                filepath = user_input[9:].strip()
                if os.path.exists(filepath):
                    code = Path(filepath).read_text()
                    ext = Path(filepath).suffix
                    lang_map = {'.py': 'python', '.php': 'php', '.java': 'java', '.js': 'javascript'}
                    lang = lang_map.get(ext, 'auto')
                    
                    print(f"[*] Analyzing {filepath}...")
                    result = await analyzer.analyze_code(code, lang)
                    if result:
                        print(f"\n{result.raw_response}\n")
                else:
                    print(f"[✗] File not found: {filepath}")
                continue
                
            if user_input.startswith("/hunt "):
                parts = user_input[6:].strip().split(" ", 1)
                if len(parts) == 2:
                    vuln_class, filepath = parts
                    if os.path.exists(filepath):
                        code = Path(filepath).read_text()
                        print(f"[*] Hunting {vuln_class} in {filepath}...")
                        result = await analyzer.hunt_vulns(code, vuln_class)
                        if result:
                            print(f"\n{result.raw_response}\n")
                    else:
                        print(f"[✗] File not found: {filepath}")
                else:
                    print("Usage: /hunt <vuln_class> <file>")
                continue
                
            # Direct query
            result = await analyzer._query(user_input)
            if result:
                print(f"\n{result.raw_response}\n")
                
        except KeyboardInterrupt:
            print("\n[*] Interrupted")
            break
        except EOFError:
            break


async def main():
    parser = argparse.ArgumentParser(description="BRUTAL DeepSeek R1 Security Analyzer")
    parser.add_argument("target", nargs="?", help="File or directory to analyze")
    parser.add_argument("--check", action="store_true", help="Check Ollama status")
    parser.add_argument("--interactive", "-i", action="store_true", help="Interactive mode")
    parser.add_argument("--hunt", help="Hunt specific vuln class (sqli, rce, deser, auth, ssrf, xxe, ssti)")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Ollama model to use")
    parser.add_argument("--output", "-o", help="Output file for results")
    args = parser.parse_args()
    
    analyzer = DeepSeekAnalyzer(model=args.model)
    
    try:
        if args.check:
            ok = await analyzer.check_ollama()
            print(f"✓ Ollama running, model: {analyzer.model}" if ok else "✗ Ollama not available")
            return
            
        if args.interactive:
            if not await analyzer.check_ollama():
                print("[✗] Cannot start interactive mode without Ollama")
                return
            await interactive_mode(analyzer)
            return
            
        if args.target:
            if not await analyzer.check_ollama():
                print("[✗] Ollama not available")
                return
                
            if os.path.isfile(args.target):
                code = Path(args.target).read_text()
                ext = Path(args.target).suffix
                lang_map = {'.py': 'python', '.php': 'php', '.java': 'java', '.js': 'javascript', '.rb': 'ruby'}
                lang = lang_map.get(ext, 'auto')
                
                if args.hunt:
                    print(f"[*] Hunting {args.hunt} in {args.target}...")
                    result = await analyzer.hunt_vulns(code, args.hunt)
                else:
                    print(f"[*] Analyzing {args.target}...")
                    result = await analyzer.analyze_code(code, lang)
                    
                if result:
                    print(f"\n{result.raw_response}")
                    
                    if args.output:
                        output_data = {
                            "file": args.target,
                            "model": result.model,
                            "timestamp": result.timestamp,
                            "vulnerability": result.vulnerability,
                            "severity": result.severity,
                            "location": result.location,
                            "root_cause": result.root_cause,
                            "exploit": result.exploit,
                            "chain_potential": result.chain_potential,
                            "raw_response": result.raw_response
                        }
                        Path(args.output).write_text(json.dumps(output_data, indent=2))
                        print(f"\n[+] Results saved to {args.output}")
            else:
                print(f"[✗] File not found: {args.target}")
        else:
            parser.print_help()
            
    finally:
        await analyzer.close()


if __name__ == "__main__":
    asyncio.run(main())
