"""
BrainX SAST Module
Static Application Security Testing patterns and scanners
"""

from .scanner import SASTScanner
from .patterns import (
    get_all_patterns, 
    get_patterns_for_language,
    get_pattern_stats,
    get_language_by_extension,
    ALL_PATTERNS,
    ALL_MAGIC_METHODS,
)

__all__ = [
    'SASTScanner', 
    'get_all_patterns', 
    'get_patterns_for_language',
    'get_pattern_stats',
    'get_language_by_extension',
    'ALL_PATTERNS',
    'ALL_MAGIC_METHODS',
]
