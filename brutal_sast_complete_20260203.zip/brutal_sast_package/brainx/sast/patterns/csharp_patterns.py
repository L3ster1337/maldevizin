"""
C# SAST Patterns - Complete Magic Methods and Exploitation Patterns
"""

# ============================================================================
# C# MAGIC METHODS & SPECIAL ATTRIBUTES
# ============================================================================
CSHARP_MAGIC_METHODS = {
    'name': 'C# Serialization & Special Methods',
    'description': 'All C# methods that can be abused for exploitation',
    'methods': {
        # SERIALIZATION CALLBACKS
        'OnSerializing': {
            'trigger': '[OnSerializing] attribute, before serialization',
            'exploit_scenarios': [
                'Pre-serialization code execution',
            ],
            'dangerous_with': [],
        },
        'OnSerialized': {
            'trigger': '[OnSerialized] attribute, after serialization',
            'exploit_scenarios': [
                'Post-serialization side effects',
            ],
            'dangerous_with': [],
        },
        'OnDeserializing': {
            'trigger': '[OnDeserializing] attribute, before deserialization',
            'exploit_scenarios': [
                'Pre-deserialization attacks',
            ],
            'dangerous_with': [],
        },
        'OnDeserialized': {
            'trigger': '[OnDeserialized] attribute, after deserialization',
            'exploit_scenarios': [
                'CRITICAL: Post-deserialization RCE',
                'Gadget chain execution point',
            ],
            'dangerous_with': ['Process.Start', 'Assembly.Load'],
        },
        
        # ISERIALIZABLE
        'GetObjectData': {
            'trigger': 'ISerializable.GetObjectData()',
            'exploit_scenarios': [
                'Serialization data manipulation',
            ],
            'dangerous_with': [],
        },
        'SpecialConstructor': {
            'trigger': 'ISerializable constructor (SerializationInfo, StreamingContext)',
            'exploit_scenarios': [
                'CRITICAL: Deserialization RCE',
                'Object state injection',
            ],
            'dangerous_with': [],
        },
        
        # FINALIZER
        '~ClassName (Finalizer)': {
            'trigger': 'Garbage collection',
            'exploit_scenarios': [
                'Destructor chain attacks',
                'Resource cleanup exploitation',
            ],
            'dangerous_with': [],
        },
        'Dispose': {
            'trigger': 'IDisposable.Dispose()',
            'exploit_scenarios': [
                'Disposal exploitation',
                'Use-after-dispose',
            ],
            'dangerous_with': [],
        },
        
        # TYPE CONVERSION
        'implicit operator': {
            'trigger': 'Implicit type conversion',
            'exploit_scenarios': [
                'Type confusion via implicit cast',
            ],
            'dangerous_with': [],
        },
        'explicit operator': {
            'trigger': 'Explicit type conversion',
            'exploit_scenarios': [
                'Type confusion via cast',
            ],
            'dangerous_with': [],
        },
        
        # INDEXERS
        'this[]': {
            'trigger': 'Indexer access',
            'exploit_scenarios': [
                'Array/collection access manipulation',
            ],
            'dangerous_with': [],
        },
        
        # EVENTS
        'add_EventName': {
            'trigger': 'Event subscription',
            'exploit_scenarios': [
                'Event handler injection',
            ],
            'dangerous_with': [],
        },
        'remove_EventName': {
            'trigger': 'Event unsubscription',
            'exploit_scenarios': [
                'Event handler manipulation',
            ],
            'dangerous_with': [],
        },
        
        # STATIC CONSTRUCTOR
        'cctor (.cctor)': {
            'trigger': 'Type initialization (static constructor)',
            'exploit_scenarios': [
                'Type initialization code execution',
            ],
            'dangerous_with': [],
        },
        
        # DYNAMIC
        'TryGetMember': {
            'trigger': 'DynamicObject member access',
            'exploit_scenarios': [
                'Dynamic member resolution attacks',
            ],
            'dangerous_with': [],
        },
        'TrySetMember': {
            'trigger': 'DynamicObject member set',
            'exploit_scenarios': [
                'Dynamic property injection',
            ],
            'dangerous_with': [],
        },
        'TryInvokeMember': {
            'trigger': 'DynamicObject method invoke',
            'exploit_scenarios': [
                'Dynamic method invocation attacks',
            ],
            'dangerous_with': [],
        },
        'TryConvert': {
            'trigger': 'DynamicObject conversion',
            'exploit_scenarios': [
                'Type conversion manipulation',
            ],
            'dangerous_with': [],
        },
        
        # EQUALITY
        'Equals': {
            'trigger': 'Object.Equals()',
            'exploit_scenarios': [
                'Equality bypass',
            ],
            'dangerous_with': [],
        },
        'GetHashCode': {
            'trigger': 'Object.GetHashCode()',
            'exploit_scenarios': [
                'Hash collision DoS',
            ],
            'dangerous_with': [],
        },
        
        # FORMATTING
        'ToString': {
            'trigger': 'Object.ToString()',
            'exploit_scenarios': [
                'Format string attacks',
                'Information disclosure',
            ],
            'dangerous_with': [],
        },
        'IFormattable.ToString': {
            'trigger': 'String.Format() with format provider',
            'exploit_scenarios': [
                'Format string vulnerabilities',
            ],
            'dangerous_with': [],
        },
    },
    
    # .NET DESERIALIZATION GADGETS
    'gadget_chains': {
        'TypeConfuseDelegate': {
            'description': 'Type confusion via delegate',
            'classes': ['Comparison<T>', 'MulticastDelegate'],
        },
        'TextFormattingRunProperties': {
            'description': 'WPF XAML gadget',
            'classes': ['TextFormattingRunProperties', 'XamlReader'],
        },
        'ObjectDataProvider': {
            'description': 'WPF ObjectDataProvider gadget',
            'classes': ['ObjectDataProvider', 'MethodBase'],
        },
        'WindowsIdentity': {
            'description': 'Windows Identity gadget',
            'classes': ['WindowsIdentity', 'ClaimsIdentity'],
        },
        'ActivitySurrogateSelector': {
            'description': 'Workflow Foundation gadget',
            'classes': ['ActivitySurrogateSelector'],
        },
        'PSObject': {
            'description': 'PowerShell gadget',
            'classes': ['PSObject', 'ScriptBlock'],
        },
    },
}

# ============================================================================
# C# VULNERABILITY PATTERNS
# ============================================================================
CSHARP_PATTERNS = [
    # ----- DESERIALIZATION -----
    {
        'id': 'cs_deser_binaryformatter',
        'name': 'C# BinaryFormatter Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'BinaryFormatter\s*\(\s*\)\s*\.Deserialize\s*\(',
        'description': 'CRITICAL: BinaryFormatter is inherently unsafe',
        'exploit': 'ysoserial.net TypeConfuseDelegate',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_soapformatter',
        'name': 'C# SoapFormatter Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'SoapFormatter\s*\(\s*\)\s*\.Deserialize\s*\(',
        'description': 'SoapFormatter is unsafe like BinaryFormatter',
        'exploit': 'Same as BinaryFormatter',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_losformatter',
        'name': 'C# LosFormatter Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'LosFormatter\s*\(\s*\)\s*\.Deserialize\s*\(',
        'description': 'LosFormatter is unsafe (ASP.NET ViewState)',
        'exploit': 'ViewState deserialization attack',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_objectstateformatter',
        'name': 'C# ObjectStateFormatter Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'ObjectStateFormatter\s*\(\s*\)\s*\.Deserialize\s*\(',
        'description': 'ObjectStateFormatter is unsafe',
        'exploit': 'Same as BinaryFormatter',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_netdatacontract',
        'name': 'C# NetDataContractSerializer Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'NetDataContractSerializer\s*\(\s*\)\s*\.ReadObject\s*\(',
        'description': 'NetDataContractSerializer is unsafe',
        'exploit': 'ObjectDataProvider gadget',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_datacontract',
        'name': 'C# DataContractSerializer Type Resolution',
        'category': 'deserialization',
        'severity': 'high',
        'pattern': r'DataContractSerializer\s*\([^)]*\)\s*\.ReadObject',
        'description': 'DataContractSerializer with dynamic type',
        'exploit': 'Type injection if type comes from input',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_xmlserializer_type',
        'name': 'C# XmlSerializer Type Injection',
        'category': 'deserialization',
        'severity': 'high',
        'pattern': r'XmlSerializer\s*\(\s*Type\.GetType\s*\([^)]*\)\s*\)',
        'description': 'XmlSerializer with dynamic type',
        'exploit': 'Type injection for gadget loading',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_javascriptserializer',
        'name': 'C# JavaScriptSerializer Type Resolvers',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'JavaScriptSerializer\s*\([^)]*\)\s*{[^}]*TypeResolver',
        'description': 'JavaScriptSerializer with type resolver',
        'exploit': '__type property injection',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_jsonnet_typenamehandling',
        'name': 'C# Json.NET TypeNameHandling',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'TypeNameHandling\s*=\s*TypeNameHandling\.(All|Objects|Arrays|Auto)',
        'description': 'Json.NET with TypeNameHandling enabled',
        'exploit': '{"$type":"System.Windows.Data.ObjectDataProvider, ..."}',
        'cwe': 'CWE-502',
    },
    {
        'id': 'cs_deser_fastjson',
        'name': 'C# fastJSON Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'fastJSON\.JSON\.ToObject\s*<[^>]+>\s*\(',
        'description': 'fastJSON may be vulnerable to type attacks',
        'exploit': '$type property injection',
        'cwe': 'CWE-502',
    },
    
    # ----- COMMAND INJECTION -----
    {
        'id': 'cs_cmdi_process_start',
        'name': 'C# Process.Start() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'Process\.Start\s*\([^)]*(?:Request|input|param|\+)',
        'description': 'Command injection via Process.Start()',
        'exploit': 'cmd /c command & attacker_command',
        'cwe': 'CWE-78',
    },
    {
        'id': 'cs_cmdi_startinfo',
        'name': 'C# ProcessStartInfo Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'ProcessStartInfo\s*\{[^}]*(FileName|Arguments)\s*=\s*[^}]*(?:Request|input|param)',
        'description': 'Command injection via ProcessStartInfo',
        'exploit': 'Argument injection',
        'cwe': 'CWE-78',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'cs_sqli_concat',
        'name': 'C# SQL Injection (Concatenation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(SqlCommand|OleDbCommand|OdbcCommand)\s*\([^)]*\+[^)]*(?:Request|input|param)',
        'description': 'SQL injection via string concatenation',
        'exploit': '\' OR 1=1--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'cs_sqli_interpolation',
        'name': 'C# SQL Injection (String Interpolation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(SqlCommand|OleDbCommand|OdbcCommand)\s*\(\s*\$"[^"]*\{',
        'description': 'SQL injection via string interpolation',
        'exploit': '\'; DROP TABLE users;--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'cs_sqli_ef_raw',
        'name': 'C# Entity Framework Raw SQL',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(FromSql|ExecuteSqlCommand|SqlQuery)\s*\([^)]*\+[^)]*(?:Request|input|param)',
        'description': 'SQL injection via EF raw query',
        'exploit': 'Same as standard SQLi',
        'cwe': 'CWE-89',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'cs_path_traversal',
        'name': 'C# Path Traversal',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'(File\.Open|File\.Read|StreamReader)\s*\([^)]*(?:Request|input|param|\+)',
        'description': 'Path traversal vulnerability',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- XXE -----
    {
        'id': 'cs_xxe_xmldocument',
        'name': 'C# XXE (XmlDocument)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'XmlDocument\s*\(\s*\)(?!.*XmlResolver\s*=\s*null)',
        'description': 'XXE via XmlDocument (before .NET 4.5.2)',
        'exploit': '<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>',
        'cwe': 'CWE-611',
    },
    {
        'id': 'cs_xxe_xmlreader',
        'name': 'C# XXE (XmlReader)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'XmlReader\.Create\s*\([^)]*(?:Request|input)',
        'description': 'XXE via XmlReader with DTD enabled',
        'exploit': 'Same XXE payload',
        'cwe': 'CWE-611',
    },
    
    # ----- SSRF -----
    {
        'id': 'cs_ssrf_webclient',
        'name': 'C# SSRF (WebClient)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'WebClient\s*\(\s*\)\s*\.(Download|Open|Upload)[^(]*\([^)]*(?:Request|input|param)',
        'description': 'SSRF via WebClient',
        'exploit': 'http://169.254.169.254/latest/meta-data/',
        'cwe': 'CWE-918',
    },
    {
        'id': 'cs_ssrf_httpclient',
        'name': 'C# SSRF (HttpClient)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'HttpClient\s*\(\s*\)\s*\.(Get|Post|Put|Delete|Send)[^(]*\([^)]*(?:Request|input|param)',
        'description': 'SSRF via HttpClient',
        'exploit': 'file:///etc/passwd',
        'cwe': 'CWE-918',
    },
    
    # ----- XSS -----
    {
        'id': 'cs_xss_response_write',
        'name': 'C# XSS (Response.Write)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'Response\.Write\s*\([^)]*(?:Request|input|param)',
        'description': 'XSS via Response.Write()',
        'exploit': '<script>alert(1)</script>',
        'cwe': 'CWE-79',
    },
    {
        'id': 'cs_xss_htmlraw',
        'name': 'C# XSS (Html.Raw)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'Html\.Raw\s*\([^)]*(?:Request|Model\.|ViewBag\.)',
        'description': 'XSS via Html.Raw() in Razor',
        'exploit': '<img src=x onerror=alert(1)>',
        'cwe': 'CWE-79',
    },
    
    # ----- LDAP INJECTION -----
    {
        'id': 'cs_ldap_injection',
        'name': 'C# LDAP Injection',
        'category': 'ldap_injection',
        'severity': 'high',
        'pattern': r'DirectorySearcher\s*\{[^}]*Filter\s*=\s*[^}]*(?:Request|input|param|\+)',
        'description': 'LDAP injection vulnerability',
        'exploit': '*)(uid=*))(|(uid=*',
        'cwe': 'CWE-90',
    },
    
    # ----- REFLECTION -----
    {
        'id': 'cs_reflection_invoke',
        'name': 'C# Reflection Invoke',
        'category': 'reflection',
        'severity': 'high',
        'pattern': r'\.GetMethod\s*\([^)]+\)\s*\.Invoke\s*\([^)]*(?:Request|input)',
        'description': 'Reflection invoke with user input',
        'exploit': 'Arbitrary method invocation',
        'cwe': 'CWE-470',
    },
    {
        'id': 'cs_reflection_assembly_load',
        'name': 'C# Assembly.Load() Abuse',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'Assembly\.Load(File|From)?\s*\([^)]*(?:Request|input|param)',
        'description': 'Assembly loading from user input',
        'exploit': 'Load malicious assembly',
        'cwe': 'CWE-94',
    },
    
    # ----- CODE EXECUTION -----
    {
        'id': 'cs_rce_codedom',
        'name': 'C# CodeDom Compilation',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(CSharpCodeProvider|VBCodeProvider)\s*\(\s*\)\s*\.CompileAssemblyFrom',
        'description': 'Dynamic code compilation',
        'exploit': 'Inject malicious code',
        'cwe': 'CWE-94',
    },
    {
        'id': 'cs_rce_roslyn',
        'name': 'C# Roslyn Script Execution',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'CSharpScript\.EvaluateAsync\s*\([^)]*(?:Request|input)',
        'description': 'Code execution via Roslyn',
        'exploit': 'System.Diagnostics.Process.Start("cmd", "/c id")',
        'cwe': 'CWE-94',
    },
    
    # ----- VIEWSTATE -----
    {
        'id': 'cs_viewstate_mac_disabled',
        'name': 'C# ViewState MAC Disabled',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'enableViewStateMac\s*=\s*["\']?false',
        'description': 'ViewState MAC validation disabled',
        'exploit': 'ViewState deserialization attack',
        'cwe': 'CWE-502',
    },
    
    # ----- HARDCODED SECRETS -----
    {
        'id': 'cs_secrets',
        'name': 'C# Hardcoded Secrets',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'(Password|ConnectionString|ApiKey|Secret)\s*=\s*"[^"]{8,}"',
        'description': 'Hardcoded secrets',
        'exploit': 'Credential theft',
        'cwe': 'CWE-798',
    },
    
    # ----- CRYPTO -----
    {
        'id': 'cs_weak_crypto',
        'name': 'C# Weak Cryptography',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'(DES|RC2|MD5|SHA1)CryptoServiceProvider',
        'description': 'Weak cryptographic algorithm',
        'exploit': 'Cryptographic attack',
        'cwe': 'CWE-327',
    },
    
    # ----- REGEX DOS -----
    {
        'id': 'cs_redos',
        'name': 'C# ReDoS',
        'category': 'dos',
        'severity': 'medium',
        'pattern': r'new\s+Regex\s*\([^)]*(?:Request|input)',
        'description': 'ReDoS via user-controlled regex',
        'exploit': '(a+)+$ with long input',
        'cwe': 'CWE-1333',
    },
]
