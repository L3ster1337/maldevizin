"""
BrainX SAST Patterns Index
Aggregates all language-specific patterns
"""

from typing import Dict, List, Any, Optional

from .php_patterns import PHP_PATTERNS, PHP_MAGIC_METHODS
from .python_patterns import PYTHON_PATTERNS, PYTHON_MAGIC_METHODS
from .javascript_patterns import JAVASCRIPT_PATTERNS, JAVASCRIPT_MAGIC_METHODS
from .java_patterns import JAVA_PATTERNS, JAVA_MAGIC_METHODS
from .c_patterns import C_PATTERNS
from .csharp_patterns import CSHARP_PATTERNS, CSHARP_MAGIC_METHODS
from .ruby_patterns import RUBY_PATTERNS, RUBY_MAGIC_METHODS
from .go_patterns import GO_PATTERNS
from .sql_patterns import SQL_PATTERNS

# HTB Ultimate Patterns (500+ from real writeups)
from .htb_ultimate_patterns import (
    HTB_ULTIMATE_PATTERNS,
    get_all_patterns as get_htb_patterns,
    get_pattern_count as get_htb_pattern_count,
    get_categories as get_htb_categories,
    get_patterns_by_severity,
    get_patterns_by_category,
)

# Language extensions map
EXTENSION_MAP = {
    '.php': 'php', '.phtml': 'php', '.php3': 'php', '.php4': 'php', 
    '.php5': 'php', '.php7': 'php', '.phps': 'php',
    '.py': 'python', '.pyw': 'python', '.pyi': 'python',
    '.js': 'javascript', '.jsx': 'javascript', '.mjs': 'javascript',
    '.ts': 'typescript', '.tsx': 'typescript',
    '.java': 'java', '.jsp': 'java', '.jspx': 'java',
    '.c': 'c', '.h': 'c',
    '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.hpp': 'cpp', '.hxx': 'cpp',
    '.cs': 'csharp', '.cshtml': 'csharp', '.aspx': 'csharp', '.ascx': 'csharp',
    '.rb': 'ruby', '.erb': 'ruby', '.rake': 'ruby', '.gemspec': 'ruby',
    '.go': 'go',
    '.sql': 'sql',
}

ALL_PATTERNS = {
    'php': PHP_PATTERNS,
    'python': PYTHON_PATTERNS,
    'javascript': JAVASCRIPT_PATTERNS,
    'typescript': JAVASCRIPT_PATTERNS,  # Same patterns
    'java': JAVA_PATTERNS,
    'c': C_PATTERNS,
    'cpp': C_PATTERNS,  # Similar patterns
    'csharp': CSHARP_PATTERNS,
    'ruby': RUBY_PATTERNS,
    'go': GO_PATTERNS,
    'sql': SQL_PATTERNS,
}

ALL_MAGIC_METHODS = {
    'php': PHP_MAGIC_METHODS,
    'python': PYTHON_MAGIC_METHODS,
    'javascript': JAVASCRIPT_MAGIC_METHODS,
    'typescript': JAVASCRIPT_MAGIC_METHODS,
    'java': JAVA_MAGIC_METHODS,
    'csharp': CSHARP_MAGIC_METHODS,
    'ruby': RUBY_MAGIC_METHODS,
}

def get_all_patterns() -> Dict[str, List[Dict]]:
    """Get all patterns for all languages"""
    return ALL_PATTERNS

def get_patterns(language: str) -> Dict:
    """Get patterns dict for a language (scanner compatibility)"""
    return {
        'patterns': ALL_PATTERNS.get(language.lower(), []),
        'magic_methods': ALL_MAGIC_METHODS.get(language.lower()),
    }

def get_patterns_for_language(language: str) -> List[Dict]:
    """Get patterns for a specific language"""
    return ALL_PATTERNS.get(language.lower(), [])

def get_magic_methods_for_language(language: str) -> Dict:
    """Get magic methods for a specific language"""
    return ALL_MAGIC_METHODS.get(language.lower(), {})

def get_all_magic_methods() -> Dict[str, Dict]:
    """Get all magic methods for all languages"""
    return ALL_MAGIC_METHODS

def get_language_by_extension(ext: str) -> Optional[str]:
    """Get language from file extension"""
    return EXTENSION_MAP.get(ext.lower())

def get_pattern_stats() -> Dict[str, Dict]:
    """Get pattern count statistics"""
    stats = {}
    for lang, patterns in ALL_PATTERNS.items():
        magic = ALL_MAGIC_METHODS.get(lang, {})
        magic_count = len(magic.get('methods', {})) if isinstance(magic, dict) and 'methods' in magic else 0
        stats[lang] = {
            'patterns': len(patterns) if isinstance(patterns, list) else 0,
            'magic_methods': magic_count,
        }
    return stats

# Exports
__all__ = [
    'ALL_PATTERNS',
    'ALL_MAGIC_METHODS',
    'EXTENSION_MAP',
    # Standard getters
    'get_all_patterns',
    'get_patterns',
    'get_patterns_for_language',
    'get_magic_methods_for_language',
    'get_all_magic_methods',
    'get_language_by_extension',
    'get_pattern_stats',
    # Language-specific
    'PHP_PATTERNS', 'PHP_MAGIC_METHODS',
    'PYTHON_PATTERNS', 'PYTHON_MAGIC_METHODS',
    'JAVASCRIPT_PATTERNS', 'JAVASCRIPT_MAGIC_METHODS',
    'JAVA_PATTERNS', 'JAVA_MAGIC_METHODS',
    'C_PATTERNS',
    'CSHARP_PATTERNS', 'CSHARP_MAGIC_METHODS',
    'RUBY_PATTERNS', 'RUBY_MAGIC_METHODS',
    'GO_PATTERNS',
    'SQL_PATTERNS',
    # HTB Ultimate Patterns (500+)
    'HTB_ULTIMATE_PATTERNS',
    'get_htb_patterns',
    'get_htb_pattern_count',
    'get_htb_categories',
    'get_patterns_by_severity',
    'get_patterns_by_category',
]
