"""
Ruby SAST Patterns - Complete Magic Methods and Exploitation Patterns
"""

# ============================================================================
# RUBY MAGIC METHODS
# ============================================================================
RUBY_MAGIC_METHODS = {
    'name': 'Ruby Magic Methods',
    'description': 'All Ruby methods that can be abused for exploitation',
    'methods': {
        # OBJECT LIFECYCLE
        'initialize': {
            'trigger': 'Object.new',
            'exploit_scenarios': [
                'Object instantiation attacks via deserialization',
            ],
            'dangerous_with': ['Marshal', 'YAML'],
        },
        
        # METHOD MISSING - CRITICAL
        'method_missing': {
            'trigger': 'Calling undefined method',
            'exploit_scenarios': [
                'Dynamic method invocation attacks',
                'Arbitrary method execution',
            ],
            'dangerous_with': ['send', 'public_send', 'eval'],
        },
        'respond_to_missing?': {
            'trigger': 'respond_to? for undefined methods',
            'exploit_scenarios': [
                'Method existence spoofing',
            ],
            'dangerous_with': [],
        },
        
        # CONSTANT MISSING
        'const_missing': {
            'trigger': 'Accessing undefined constant',
            'exploit_scenarios': [
                'Dynamic constant loading',
                'Autoload attacks',
            ],
            'dangerous_with': ['const_get', 'constantize'],
        },
        
        # TYPE COERCION
        'to_s': {
            'trigger': 'String conversion',
            'exploit_scenarios': [
                'String injection',
            ],
            'dangerous_with': [],
        },
        'to_str': {
            'trigger': 'Implicit string conversion',
            'exploit_scenarios': [
                'Type coercion attacks',
            ],
            'dangerous_with': [],
        },
        'to_i': {
            'trigger': 'Integer conversion',
            'exploit_scenarios': [],
            'dangerous_with': [],
        },
        'to_a': {
            'trigger': 'Array conversion',
            'exploit_scenarios': [],
            'dangerous_with': [],
        },
        'to_ary': {
            'trigger': 'Implicit array conversion',
            'exploit_scenarios': [
                'Array splat attacks',
            ],
            'dangerous_with': [],
        },
        'to_hash': {
            'trigger': 'Implicit hash conversion',
            'exploit_scenarios': [
                'Hash splat attacks',
            ],
            'dangerous_with': [],
        },
        'to_proc': {
            'trigger': 'Block conversion (&object)',
            'exploit_scenarios': [
                'Proc injection',
            ],
            'dangerous_with': [],
        },
        
        # COMPARISON
        '<=>': {
            'trigger': 'Comparison operator',
            'exploit_scenarios': [
                'Comparison manipulation',
            ],
            'dangerous_with': [],
        },
        '==': {
            'trigger': 'Equality check',
            'exploit_scenarios': [
                'Equality bypass',
            ],
            'dangerous_with': [],
        },
        'eql?': {
            'trigger': 'Hash key equality',
            'exploit_scenarios': [
                'Hash collision',
            ],
            'dangerous_with': [],
        },
        'hash': {
            'trigger': 'Hash code generation',
            'exploit_scenarios': [
                'Hash collision DoS',
            ],
            'dangerous_with': [],
        },
        
        # ATTRIBUTE ACCESS
        'instance_variable_get': {
            'trigger': 'Dynamic ivar access',
            'exploit_scenarios': [
                'Information disclosure',
                'State inspection',
            ],
            'dangerous_with': [],
        },
        'instance_variable_set': {
            'trigger': 'Dynamic ivar set',
            'exploit_scenarios': [
                'State manipulation',
                'Object injection',
            ],
            'dangerous_with': [],
        },
        
        # SERIALIZATION - CRITICAL
        '_dump': {
            'trigger': 'Marshal.dump custom',
            'exploit_scenarios': [
                'Serialization manipulation',
            ],
            'dangerous_with': [],
        },
        '_load': {
            'trigger': 'Marshal.load custom (class method)',
            'exploit_scenarios': [
                'CRITICAL: Deserialization RCE',
            ],
            'dangerous_with': ['system', 'exec', 'eval'],
        },
        'marshal_dump': {
            'trigger': 'Marshal.dump custom (instance)',
            'exploit_scenarios': [
                'Serialization control',
            ],
            'dangerous_with': [],
        },
        'marshal_load': {
            'trigger': 'Marshal.load custom (instance)',
            'exploit_scenarios': [
                'CRITICAL: Deserialization RCE',
            ],
            'dangerous_with': ['system', 'exec', 'eval'],
        },
        
        # YAML SERIALIZATION
        'init_with': {
            'trigger': 'Psych (YAML) deserialization',
            'exploit_scenarios': [
                'YAML deserialization attacks',
            ],
            'dangerous_with': [],
        },
        'encode_with': {
            'trigger': 'Psych (YAML) serialization',
            'exploit_scenarios': [
                'YAML serialization manipulation',
            ],
            'dangerous_with': [],
        },
        
        # CLONING
        'initialize_copy': {
            'trigger': 'clone/dup',
            'exploit_scenarios': [
                'Clone state manipulation',
            ],
            'dangerous_with': [],
        },
        'initialize_clone': {
            'trigger': 'clone',
            'exploit_scenarios': [
                'Clone-specific attacks',
            ],
            'dangerous_with': [],
        },
        'initialize_dup': {
            'trigger': 'dup',
            'exploit_scenarios': [
                'Dup-specific attacks',
            ],
            'dangerous_with': [],
        },
        
        # REFLECTION
        'send': {
            'trigger': 'Dynamic method invocation',
            'exploit_scenarios': [
                'CRITICAL: Arbitrary method execution',
                'Private method access',
            ],
            'dangerous_with': ['eval', 'system', 'exec'],
        },
        'public_send': {
            'trigger': 'Dynamic public method invocation',
            'exploit_scenarios': [
                'Arbitrary public method execution',
            ],
            'dangerous_with': [],
        },
        '__send__': {
            'trigger': 'send (cannot be overridden)',
            'exploit_scenarios': [
                'Same as send',
            ],
            'dangerous_with': [],
        },
        
        # CLASS/MODULE
        'included': {
            'trigger': 'Module included in class',
            'exploit_scenarios': [
                'Module inclusion side effects',
            ],
            'dangerous_with': [],
        },
        'extended': {
            'trigger': 'Module extended onto object',
            'exploit_scenarios': [
                'Extension side effects',
            ],
            'dangerous_with': [],
        },
        'inherited': {
            'trigger': 'Class inherited',
            'exploit_scenarios': [
                'Inheritance chain manipulation',
            ],
            'dangerous_with': [],
        },
        'prepended': {
            'trigger': 'Module prepended',
            'exploit_scenarios': [
                'Method override attacks',
            ],
            'dangerous_with': [],
        },
    },
    
    # RUBY DESERIALIZATION GADGETS
    'gadget_chains': {
        'ERB': {
            'description': 'ERB template RCE',
            'payload': 'ERB.new("<%= `id` %>").result',
        },
        'Gem::Requirement': {
            'description': 'Gem::Requirement RCE (CVE-2013-0156)',
            'classes': ['Gem::Requirement', 'Gem::DependencyList'],
        },
        'Gem::Installer': {
            'description': 'Gem installation RCE',
            'classes': ['Gem::Installer'],
        },
        'Gem::SpecFetcher': {
            'description': 'Gem fetch RCE',
            'classes': ['Gem::SpecFetcher'],
        },
    },
}

# ============================================================================
# RUBY VULNERABILITY PATTERNS
# ============================================================================
RUBY_PATTERNS = [
    # ----- COMMAND INJECTION -----
    {
        'id': 'ruby_cmdi_system',
        'name': 'Ruby system() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'system\s*\([^)]*(?:params|request|input|\#\{)',
        'description': 'Command injection via system()',
        'exploit': '; id #',
        'cwe': 'CWE-78',
    },
    {
        'id': 'ruby_cmdi_exec',
        'name': 'Ruby exec() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'exec\s*\([^)]*(?:params|request|input|\#\{)',
        'description': 'Command injection via exec()',
        'exploit': '| cat /etc/passwd',
        'cwe': 'CWE-78',
    },
    {
        'id': 'ruby_cmdi_backtick',
        'name': 'Ruby Backtick Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'`[^`]*\#\{',
        'description': 'Command injection via backticks',
        'exploit': '`id`',
        'cwe': 'CWE-78',
    },
    {
        'id': 'ruby_cmdi_popen',
        'name': 'Ruby IO.popen Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'IO\.popen\s*\([^)]*(?:params|request|input|\#\{)',
        'description': 'Command injection via IO.popen()',
        'exploit': '; whoami',
        'cwe': 'CWE-78',
    },
    {
        'id': 'ruby_cmdi_open',
        'name': 'Ruby Open Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'open\s*\(\s*"\|[^"]*\#\{',
        'description': 'Command injection via open("|cmd")',
        'exploit': '|id',
        'cwe': 'CWE-78',
    },
    {
        'id': 'ruby_cmdi_spawn',
        'name': 'Ruby spawn Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'spawn\s*\([^)]*(?:params|request|input|\#\{)',
        'description': 'Command injection via spawn()',
        'exploit': 'Same as system',
        'cwe': 'CWE-78',
    },
    {
        'id': 'ruby_cmdi_percent_x',
        'name': 'Ruby %x Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'%x\{[^}]*\#\{',
        'description': 'Command injection via %x{}',
        'exploit': '%x{id}',
        'cwe': 'CWE-78',
    },
    
    # ----- CODE EXECUTION -----
    {
        'id': 'ruby_rce_eval',
        'name': 'Ruby eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'eval\s*\([^)]*(?:params|request|input)',
        'description': 'Code execution via eval()',
        'exploit': 'system("id")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'ruby_rce_instance_eval',
        'name': 'Ruby instance_eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'instance_eval\s*\([^)]*(?:params|request|input)',
        'description': 'Code execution via instance_eval()',
        'exploit': 'Same as eval',
        'cwe': 'CWE-94',
    },
    {
        'id': 'ruby_rce_class_eval',
        'name': 'Ruby class_eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'class_eval\s*\([^)]*(?:params|request|input)',
        'description': 'Code execution via class_eval()',
        'exploit': 'Same as eval',
        'cwe': 'CWE-94',
    },
    {
        'id': 'ruby_rce_module_eval',
        'name': 'Ruby module_eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'module_eval\s*\([^)]*(?:params|request|input)',
        'description': 'Code execution via module_eval()',
        'exploit': 'Same as eval',
        'cwe': 'CWE-94',
    },
    {
        'id': 'ruby_rce_send',
        'name': 'Ruby send() Method Injection',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'\.(send|public_send|__send__)\s*\([^)]*(?:params|request|input)',
        'description': 'Arbitrary method invocation via send()',
        'exploit': 'obj.send(:system, "id")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'ruby_rce_constantize',
        'name': 'Ruby constantize() Class Injection',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'\.constantize\s*(?:\(\s*\))?',
        'description': 'Arbitrary class instantiation (Rails)',
        'exploit': '"Kernel".constantize.system("id")',
        'cwe': 'CWE-94',
    },
    
    # ----- DESERIALIZATION -----
    {
        'id': 'ruby_deser_marshal',
        'name': 'Ruby Marshal.load() Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'Marshal\.load\s*\(',
        'description': 'CRITICAL: Marshal deserialization RCE',
        'exploit': 'ERB gadget chain',
        'cwe': 'CWE-502',
    },
    {
        'id': 'ruby_deser_yaml',
        'name': 'Ruby YAML.load() Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'YAML\.load\s*\([^)]*(?!_file)',
        'description': 'CRITICAL: YAML deserialization RCE',
        'exploit': '--- !ruby/object:Gem::Installer',
        'cwe': 'CWE-502',
    },
    {
        'id': 'ruby_deser_psych',
        'name': 'Ruby Psych.unsafe_load()',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'Psych\.unsafe_load\s*\(',
        'description': 'Unsafe YAML loading',
        'exploit': 'Same as YAML.load',
        'cwe': 'CWE-502',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'ruby_sqli_interpolation',
        'name': 'Ruby SQL Injection (Interpolation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'\.(where|find_by_sql|select|joins|order|group|having)\s*\([^)]*\#\{',
        'description': 'SQL injection via string interpolation',
        'exploit': "' OR 1=1--",
        'cwe': 'CWE-89',
    },
    {
        'id': 'ruby_sqli_concat',
        'name': 'Ruby SQL Injection (Concatenation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'\.(where|find_by_sql|select)\s*\([^)]*\+\s*(?:params|request|input)',
        'description': 'SQL injection via concatenation',
        'exploit': "'; DROP TABLE users;--",
        'cwe': 'CWE-89',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'ruby_path_traversal',
        'name': 'Ruby Path Traversal',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'(File\.read|File\.open|IO\.read|send_file)\s*\([^)]*(?:params|request|input)',
        'description': 'Path traversal vulnerability',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- XSS -----
    {
        'id': 'ruby_xss_raw',
        'name': 'Ruby XSS (raw helper)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'raw\s*\([^)]*(?:params|request|input)',
        'description': 'XSS via raw() helper',
        'exploit': '<script>alert(1)</script>',
        'cwe': 'CWE-79',
    },
    {
        'id': 'ruby_xss_html_safe',
        'name': 'Ruby XSS (html_safe)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'\.html_safe\s*(?!\s*\.\s*gsub)',
        'description': 'XSS via html_safe',
        'exploit': '<img src=x onerror=alert(1)>',
        'cwe': 'CWE-79',
    },
    
    # ----- SSRF -----
    {
        'id': 'ruby_ssrf',
        'name': 'Ruby SSRF',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'(open-uri|Net::HTTP|HTTParty|Faraday|RestClient)\.[^(]*\([^)]*(?:params|request|input)',
        'description': 'SSRF via HTTP client',
        'exploit': 'http://169.254.169.254/',
        'cwe': 'CWE-918',
    },
    
    # ----- TEMPLATE INJECTION -----
    {
        'id': 'ruby_ssti_erb',
        'name': 'Ruby SSTI (ERB)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'ERB\.new\s*\([^)]*(?:params|request|input)',
        'description': 'ERB template injection',
        'exploit': '<%= system("id") %>',
        'cwe': 'CWE-94',
    },
    
    # ----- MASS ASSIGNMENT -----
    {
        'id': 'ruby_mass_assignment',
        'name': 'Ruby Mass Assignment',
        'category': 'mass_assignment',
        'severity': 'high',
        'pattern': r'\.(new|create|update)\s*\(\s*params(?!\[)',
        'description': 'Mass assignment vulnerability',
        'exploit': 'params[:admin] = true',
        'cwe': 'CWE-915',
    },
    
    # ----- OPEN REDIRECT -----
    {
        'id': 'ruby_open_redirect',
        'name': 'Ruby Open Redirect',
        'category': 'open_redirect',
        'severity': 'medium',
        'pattern': r'redirect_to\s*\([^)]*(?:params|request)',
        'description': 'Open redirect vulnerability',
        'exploit': '//evil.com',
        'cwe': 'CWE-601',
    },
    
    # ----- SECRETS -----
    {
        'id': 'ruby_hardcoded_secrets',
        'name': 'Ruby Hardcoded Secrets',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'(password|secret|api_key|token)\s*=\s*[\'"][^\'"]{8,}[\'"]',
        'description': 'Hardcoded secrets',
        'exploit': 'Credential theft',
        'cwe': 'CWE-798',
    },
    
    # ----- REGEX DOS -----
    {
        'id': 'ruby_redos',
        'name': 'Ruby ReDoS',
        'category': 'dos',
        'severity': 'medium',
        'pattern': r'Regexp\.new\s*\([^)]*(?:params|request|input)',
        'description': 'ReDoS via user-controlled regex',
        'exploit': '(a+)+$ attack',
        'cwe': 'CWE-1333',
    },
]
