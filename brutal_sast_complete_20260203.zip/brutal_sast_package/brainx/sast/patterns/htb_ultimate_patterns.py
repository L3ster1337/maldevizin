#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════════╗
║  ☢️  BRAINX HTB ULTIMATE PATTERNS - NEVER MISS A VULNERABILITY  ☢️               ║
║                                                                                   ║
║  Patterns extraídos de 500+ writeups do HackTheBox, VulnLab, Bug Bounty reports  ║
║  e CVEs reais. Cada pattern foi testado em código vulnerável REAL.               ║
║                                                                                   ║
║  "If it's exploitable, we'll find it." - l3ster                                  ║
╚══════════════════════════════════════════════════════════════════════════════════╝

Categories:
  - DESERIALIZATION (PHP, Python, Java, Ruby, Node.js, .NET)
  - COMMAND INJECTION (All languages)
  - SQL INJECTION (Classic, Blind, Second-Order, NoSQL)
  - TEMPLATE INJECTION (SSTI - Jinja2, Twig, Smarty, Velocity, Freemarker, etc)
  - FILE OPERATIONS (LFI, RFI, Path Traversal, Arbitrary Write)
  - TYPE JUGGLING / COMPARISON FLAWS
  - RACE CONDITIONS (TOCTOU patterns)
  - AUTHENTICATION BYPASS
  - PRIVILEGE ESCALATION
  - PROTOTYPE POLLUTION (JavaScript)
  - XXE (XML External Entity)
  - SSRF (Server-Side Request Forgery)
  - XSS (Reflected, Stored, DOM-based)
  - BUSINESS LOGIC FLAWS
  - CRYPTOGRAPHIC WEAKNESSES
  - HEADER INJECTION / CRLF
  - OPEN REDIRECT
  - CORS MISCONFIGURATION
  - JWT VULNERABILITIES
  - OAUTH FLAWS
  - WEBSOCKET VULNERABILITIES
  - GRAPHQL INJECTION
  - MEMORY CORRUPTION (Buffer Overflow, Use-After-Free, etc)
  - KUBERNETES / CLOUD MISCONFIGS
  - HARDCODED SECRETS / CREDENTIALS

Total: 500+ patterns covering 30+ vulnerability categories
"""

from typing import Dict, Tuple, List
import re

# ═══════════════════════════════════════════════════════════════════════════════
# PATTERN FORMAT: (regex, description, severity, cwe_id, exploitation_difficulty)
# Severity: critical, high, medium, low, info
# Exploitation: trivial, easy, moderate, hard, expert
# ═══════════════════════════════════════════════════════════════════════════════

HTB_ULTIMATE_PATTERNS: Dict[str, Dict[str, Tuple[str, str, str, str, str]]] = {
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PHP DESERIALIZATION - FROM HTB WRITEUPS
    # Based on: HTBank, Retired, various PHP challenges
    # ═══════════════════════════════════════════════════════════════════════════
    'php_deserialization': {
        # Basic unserialize
        'php_unserialize_direct': (
            r'unserialize\s*\(\s*\$_(GET|POST|REQUEST|COOKIE|SERVER)',
            'Direct unserialize of user input - CRITICAL RCE vector',
            'critical', 'CWE-502', 'trivial'
        ),
        'php_unserialize_var': (
            r'unserialize\s*\(\s*\$[a-zA-Z_][a-zA-Z0-9_]*\s*\)',
            'Unserialize of variable - trace data source',
            'high', 'CWE-502', 'easy'
        ),
        'php_maybe_unserialize': (
            r'maybe_unserialize\s*\(',
            'WordPress maybe_unserialize - potential deserialization',
            'high', 'CWE-502', 'easy'
        ),
        
        # PHAR deserialization (HTB: Retired machine)
        'php_phar_wrapper': (
            r'phar://[\$\w]',
            'PHAR wrapper usage - deserialization via file operations',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_phar_file_ops': (
            r'(file_exists|is_dir|is_file|filesize|filemtime|file_get_contents|include|require|fopen|readfile|copy|unlink|rename|rmdir|mkdir|scandir|glob|stat|lstat)\s*\([^)]*phar://',
            'PHAR deserialization via file operation',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_phar_potential': (
            r'(file_exists|is_dir|is_file|filesize|filemtime|file_get_contents|include|require|fopen|readfile|copy|unlink|rename|rmdir|mkdir|scandir|glob|stat|lstat)\s*\([^)]*\$',
            'File operation with user input - potential PHAR vector',
            'high', 'CWE-502', 'moderate'
        ),
        
        # Magic methods (gadget chains)
        'php_wakeup_shell': (
            r'function\s+__wakeup\s*\([^)]*\)\s*\{[^}]*(shell_exec|system|exec|passthru|popen|proc_open|pcntl_exec)',
            'Dangerous __wakeup gadget with shell execution',
            'critical', 'CWE-502', 'trivial'
        ),
        'php_wakeup_include': (
            r'function\s+__wakeup\s*\([^)]*\)\s*\{[^}]*(include|require|include_once|require_once|file_get_contents)',
            'Dangerous __wakeup gadget with file inclusion',
            'critical', 'CWE-502', 'easy'
        ),
        'php_wakeup_eval': (
            r'function\s+__wakeup\s*\([^)]*\)\s*\{[^}]*(eval|assert|create_function|preg_replace\s*\([^)]*\/[^\/]*e)',
            'Dangerous __wakeup gadget with code execution',
            'critical', 'CWE-502', 'trivial'
        ),
        'php_destruct_unlink': (
            r'function\s+__destruct\s*\([^)]*\)\s*\{[^}]*(unlink|rmdir|file_put_contents)',
            'Dangerous __destruct gadget with file operations',
            'high', 'CWE-502', 'easy'
        ),
        'php_destruct_shell': (
            r'function\s+__destruct\s*\([^)]*\)\s*\{[^}]*(shell_exec|system|exec|passthru)',
            'Dangerous __destruct gadget with shell execution',
            'critical', 'CWE-502', 'trivial'
        ),
        'php_tostring_include': (
            r'function\s+__toString\s*\([^)]*\)\s*\{[^}]*(include|require|file_get_contents|eval)',
            'Dangerous __toString gadget',
            'critical', 'CWE-502', 'easy'
        ),
        'php_call_dynamic': (
            r'function\s+__call\s*\([^)]*\)\s*\{[^}]*(call_user_func|\$[a-zA-Z_]+\s*\()',
            'Dangerous __call gadget with dynamic function call',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_get_dynamic': (
            r'function\s+__get\s*\([^)]*\)\s*\{[^}]*(->|\[)',
            'Property access in __get - potential chain link',
            'medium', 'CWE-502', 'moderate'
        ),
        'php_set_write': (
            r'function\s+__set\s*\([^)]*\)\s*\{[^}]*(file_put_contents|fwrite|fputs)',
            'File write in __set gadget',
            'high', 'CWE-502', 'moderate'
        ),
        
        # Additional magic methods
        'php_invoke_callable': (
            r'function\s+__invoke\s*\([^)]*\)\s*\{[^}]*(call_user_func|system|exec|eval|\$this->)',
            'Dangerous __invoke gadget - object used as callable',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_unserialize_method': (
            r'function\s+__unserialize\s*\([^)]*\)\s*\{[^}]*(eval|system|exec|include|file_)',
            'Dangerous __unserialize (PHP 7.4+) gadget',
            'critical', 'CWE-502', 'trivial'
        ),
        'php_sleep_disclosure': (
            r'function\s+__sleep\s*\([^)]*\)\s*\{[^}]*(file_put_contents|fwrite|log)',
            'Info disclosure in __sleep before serialization',
            'medium', 'CWE-502', 'moderate'
        ),
        'php_callstatic': (
            r'function\s+__callStatic\s*\([^)]*\)\s*\{[^}]*(call_user_func|forward_static_call)',
            'Dangerous __callStatic with dynamic static call',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_isset_unset': (
            r'function\s+__(isset|unset)\s*\([^)]*\)\s*\{[^}]*(unlink|file_exists|\$this->)',
            '__isset/__unset with file operations or chain potential',
            'medium', 'CWE-502', 'moderate'
        ),
        'php_clone_resource': (
            r'function\s+__clone\s*\([^)]*\)\s*\{[^}]*(file_get_contents|fopen|curl|mysqli)',
            '__clone with resource access - potential chain link',
            'medium', 'CWE-502', 'moderate'
        ),
        'php_setstate_eval': (
            r'function\s+__set_state\s*\([^)]*\)\s*\{[^}]*(eval|include|require)',
            'Dangerous __set_state (var_export) gadget',
            'high', 'CWE-502', 'moderate'
        ),
        'php_debuginfo_leak': (
            r'function\s+__debugInfo\s*\([^)]*\)\s*\{[^}]*(password|secret|key|token|credential)',
            '__debugInfo exposing sensitive data',
            'medium', 'CWE-200', 'easy'
        ),
        
        # Known vulnerable libraries
        'php_monolog_rce': (
            r'Monolog\\\\Handler\\\\(BufferHandler|FingersCrossedHandler|SyslogUdpHandler)',
            'Monolog handler - known deserialization gadgets',
            'high', 'CWE-502', 'moderate'
        ),
        'php_guzzle_gadget': (
            r'GuzzleHttp\\\\(Cookie\\\\FileCookieJar|Psr7\\\\FnStream)',
            'Guzzle gadget chain - file write/RCE',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_symfony_gadget': (
            r'Symfony\\\\Component\\\\(Cache\\\\|Process\\\\)',
            'Symfony component - potential gadget chain',
            'high', 'CWE-502', 'moderate'
        ),
        'php_laravel_gadget': (
            r'Illuminate\\\\(Broadcasting\\\\PendingBroadcast|Support\\\\MessageBag)',
            'Laravel gadget chain',
            'critical', 'CWE-502', 'moderate'
        ),
        'php_yii_gadget': (
            r'yii\\\\(db\\\\BatchQueryResult|rest\\\\)',
            'Yii2 gadget chain',
            'high', 'CWE-502', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PYTHON DESERIALIZATION
    # Based on: HTBooks, various Python challenges
    # ═══════════════════════════════════════════════════════════════════════════
    'python_deserialization': {
        'py_pickle_load_direct': (
            r'pickle\.loads?\s*\(\s*(request\.|flask\.|data|user|input)',
            'Direct pickle load of user input - CRITICAL RCE',
            'critical', 'CWE-502', 'trivial'
        ),
        'py_pickle_any': (
            r'pickle\.(loads?|Unpickler)\s*\(',
            'Pickle deserialization - trace data source',
            'high', 'CWE-502', 'easy'
        ),
        'py_cpickle': (
            r'cPickle\.(loads?|Unpickler)\s*\(',
            'cPickle deserialization',
            'high', 'CWE-502', 'easy'
        ),
        'py_yaml_load_unsafe': (
            r'yaml\.load\s*\([^)]*\)(?!\s*,\s*Loader\s*=\s*(SafeLoader|yaml\.SafeLoader))',
            'Unsafe YAML load - missing SafeLoader',
            'critical', 'CWE-502', 'trivial'
        ),
        'py_yaml_unsafe_load': (
            r'yaml\.(unsafe_load|full_load|UnsafeLoader|FullLoader)\s*\(',
            'Explicitly unsafe YAML loader',
            'critical', 'CWE-502', 'trivial'
        ),
        'py_yaml_construct': (
            r'yaml\.add_constructor\s*\(',
            'Custom YAML constructor - potential RCE',
            'high', 'CWE-502', 'moderate'
        ),
        'py_marshal_load': (
            r'marshal\.loads?\s*\(',
            'Marshal deserialization - code execution',
            'critical', 'CWE-502', 'easy'
        ),
        'py_shelve_open': (
            r'shelve\.open\s*\([^)]*\)',
            'Shelve uses pickle internally',
            'high', 'CWE-502', 'moderate'
        ),
        'py_jsonpickle': (
            r'jsonpickle\.(decode|loads?)\s*\(',
            'jsonpickle deserialization',
            'high', 'CWE-502', 'easy'
        ),
        'py_dill_load': (
            r'dill\.(loads?|load)\s*\(',
            'Dill deserialization (extended pickle)',
            'critical', 'CWE-502', 'easy'
        ),
        
        # PyYAML specific payloads (from writeups)
        'py_yaml_python_object': (
            r'!!python/(object|module|name)',
            'PyYAML Python object in data - deserialization attack',
            'critical', 'CWE-502', 'trivial'
        ),
        
        # Python Magic Methods for Pickle RCE
        'py_reduce_rce': (
            r'def\s+__reduce__\s*\(\s*self\s*\)\s*:.*(?:os\.system|subprocess|eval|exec|import)',
            '__reduce__ method - CRITICAL pickle RCE gadget',
            'critical', 'CWE-502', 'trivial'
        ),
        'py_reduce_ex_rce': (
            r'def\s+__reduce_ex__\s*\(\s*self[^)]*\)\s*:.*(?:os\.|subprocess|eval|exec)',
            '__reduce_ex__ method - pickle RCE gadget',
            'critical', 'CWE-502', 'trivial'
        ),
        'py_getstate_leak': (
            r'def\s+__getstate__\s*\(\s*self\s*\)\s*:.*(?:password|secret|key|token)',
            '__getstate__ exposing sensitive data',
            'medium', 'CWE-200', 'easy'
        ),
        'py_setstate_rce': (
            r'def\s+__setstate__\s*\(\s*self[^)]*\)\s*:.*(?:eval|exec|os\.system|subprocess)',
            '__setstate__ method with code execution',
            'critical', 'CWE-502', 'trivial'
        ),
        'py_getattr_chain': (
            r'def\s+__getattr__\s*\(\s*self[^)]*\)\s*:.*(?:getattr|eval|\[\w+\])',
            '__getattr__ potential chain link',
            'medium', 'CWE-502', 'moderate'
        ),
        'py_setattr_injection': (
            r'def\s+__setattr__\s*\(\s*self[^)]*\)\s*:.*(?:setattr|exec|eval)',
            '__setattr__ with dangerous operations',
            'high', 'CWE-502', 'moderate'
        ),
        'py_call_rce': (
            r'def\s+__call__\s*\(\s*self[^)]*\)\s*:.*(?:os\.system|subprocess|eval|exec)',
            '__call__ method with code execution',
            'critical', 'CWE-502', 'easy'
        ),
        'py_init_subprocess': (
            r'def\s+__init__\s*\(\s*self[^)]*\)\s*:.*(?:subprocess\.call|os\.system|exec)',
            '__init__ with shell execution - pickle chain',
            'high', 'CWE-502', 'moderate'
        ),
        'py_del_unlink': (
            r'def\s+__del__\s*\(\s*self\s*\)\s*:.*(?:os\.remove|unlink|rmtree)',
            '__del__ with file deletion',
            'medium', 'CWE-502', 'moderate'
        ),
        'py_enter_resource': (
            r'def\s+__enter__\s*\(\s*self\s*\)\s*:.*(?:open|connect|socket)',
            '__enter__ context manager with resource access',
            'low', 'CWE-502', 'moderate'
        ),
        
        # Django
        'py_django_signed_cookie': (
            r'django\.core\.signing\.(loads|SignatureExpired)',
            'Django signed cookie - if key leaked, RCE possible',
            'medium', 'CWE-502', 'hard'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # JAVA DESERIALIZATION
    # Based on: Log4Shell, various Java challenges, real CVEs
    # ═══════════════════════════════════════════════════════════════════════════
    'java_deserialization': {
        'java_ois_readobject': (
            r'ObjectInputStream\s*\([^)]*\)\.readObject\s*\(\)',
            'ObjectInputStream readObject - classic deser RCE',
            'critical', 'CWE-502', 'easy'
        ),
        'java_ois_new': (
            r'new\s+ObjectInputStream\s*\(',
            'New ObjectInputStream - potential deserialization',
            'high', 'CWE-502', 'easy'
        ),
        'java_xmldecoder': (
            r'XMLDecoder\s*\([^)]*\)\.readObject\s*\(\)',
            'XMLDecoder deserialization - RCE',
            'critical', 'CWE-502', 'easy'
        ),
        'java_xstream_fromxml': (
            r'XStream\s*\(\s*\)\.fromXML\s*\(',
            'XStream deserialization without security',
            'critical', 'CWE-502', 'easy'
        ),
        'java_yaml_snakeyaml': (
            r'new\s+Yaml\s*\(\s*\)\.load\s*\(',
            'SnakeYAML unsafe load',
            'critical', 'CWE-502', 'easy'
        ),
        'java_kryo_read': (
            r'kryo\.readObject\s*\(',
            'Kryo deserialization',
            'high', 'CWE-502', 'moderate'
        ),
        'java_hessian': (
            r'(HessianInput|BurlapInput).*readObject',
            'Hessian/Burlap deserialization',
            'high', 'CWE-502', 'moderate'
        ),
        
        # JNDI Injection (Log4Shell family)
        'java_jndi_lookup': (
            r'(lookup|lookupLink)\s*\([^)]*(\$\{|\+\s*\w+)',
            'JNDI lookup with dynamic input - Log4Shell pattern',
            'critical', 'CWE-917', 'trivial'
        ),
        'java_jndi_initial_context': (
            r'new\s+InitialContext\s*\(\s*\)\.lookup\s*\(',
            'InitialContext lookup - JNDI injection',
            'critical', 'CWE-917', 'easy'
        ),
        'java_jndi_env': (
            r'InitialContext\s*\([^)]*env[^)]*\)',
            'InitialContext with environment - possible injection',
            'high', 'CWE-917', 'moderate'
        ),
        'java_naming_lookup': (
            r'javax\.naming.*lookup',
            'javax.naming lookup - JNDI vector',
            'high', 'CWE-917', 'moderate'
        ),
        
        # Spring specific
        'java_spring_spel': (
            r'SpelExpressionParser.*parseExpression.*\+',
            'Spring SpEL with dynamic input - RCE',
            'critical', 'CWE-917', 'easy'
        ),
        'java_spring_data_binding': (
            r'@ModelAttribute.*class\s+\w+\s*\{[^}]*Runtime',
            'Spring data binding with dangerous class',
            'high', 'CWE-94', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # NODE.JS DESERIALIZATION
    # ═══════════════════════════════════════════════════════════════════════════
    'nodejs_deserialization': {
        'node_serialize': (
            r'(node-serialize|serialize-javascript).*unserialize',
            'node-serialize deserialization - RCE via IIFE',
            'critical', 'CWE-502', 'trivial'
        ),
        'node_cryo': (
            r'cryo\.(parse|unserialize)',
            'Cryo deserialization',
            'high', 'CWE-502', 'easy'
        ),
        'node_funcster': (
            r'funcster\.deepDeserialize',
            'Funcster deserialization',
            'critical', 'CWE-502', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # COMMAND INJECTION - ALL LANGUAGES
    # Based on: Multiple HTB machines and real CVEs
    # ═══════════════════════════════════════════════════════════════════════════
    'command_injection': {
        # PHP
        'php_system_user': (
            r'system\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)',
            'Direct system() with user input',
            'critical', 'CWE-78', 'trivial'
        ),
        'php_exec_user': (
            r'exec\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)',
            'Direct exec() with user input',
            'critical', 'CWE-78', 'trivial'
        ),
        'php_shell_exec_user': (
            r'shell_exec\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)',
            'Direct shell_exec() with user input',
            'critical', 'CWE-78', 'trivial'
        ),
        'php_passthru_user': (
            r'passthru\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)',
            'Direct passthru() with user input',
            'critical', 'CWE-78', 'trivial'
        ),
        'php_popen_user': (
            r'popen\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)',
            'Direct popen() with user input',
            'critical', 'CWE-78', 'trivial'
        ),
        'php_proc_open_user': (
            r'proc_open\s*\([^)]*\$_(GET|POST|REQUEST|COOKIE)',
            'Direct proc_open() with user input',
            'critical', 'CWE-78', 'trivial'
        ),
        'php_backtick': (
            r'`[^`]*\$[^`]+`',
            'Backtick execution with variable',
            'critical', 'CWE-78', 'easy'
        ),
        'php_pcntl_exec': (
            r'pcntl_exec\s*\([^)]*\$',
            'pcntl_exec with variable',
            'critical', 'CWE-78', 'easy'
        ),
        'php_system_concat': (
            r'(system|exec|shell_exec|passthru)\s*\([^)]*\.\s*\$',
            'Command execution with concatenated variable',
            'critical', 'CWE-78', 'easy'
        ),
        'php_escapeshellcmd_bypass': (
            r'escapeshellcmd\s*\([^)]+\).*(-[a-zA-Z]|\|)',
            'escapeshellcmd bypass pattern',
            'high', 'CWE-78', 'moderate'
        ),
        
        # Python
        'py_os_system_user': (
            r'os\.system\s*\([^)]*request',
            'os.system with request data',
            'critical', 'CWE-78', 'trivial'
        ),
        'py_os_popen_user': (
            r'os\.popen\s*\([^)]*request',
            'os.popen with request data',
            'critical', 'CWE-78', 'trivial'
        ),
        'py_subprocess_shell_true': (
            r'subprocess\.(call|run|Popen)\s*\([^)]*shell\s*=\s*True[^)]*\+',
            'subprocess with shell=True and concatenation',
            'critical', 'CWE-78', 'trivial'
        ),
        'py_subprocess_user': (
            r'subprocess\.(call|run|Popen)\s*\([^)]*request',
            'subprocess with request data',
            'high', 'CWE-78', 'easy'
        ),
        'py_commands_getoutput': (
            r'commands\.(getoutput|getstatusoutput)\s*\(',
            'commands module (deprecated, insecure)',
            'high', 'CWE-78', 'easy'
        ),
        
        # Node.js
        'node_child_exec': (
            r'child_process\.(exec|execSync)\s*\([^)]*\+',
            'child_process.exec with concatenation',
            'critical', 'CWE-78', 'easy'
        ),
        'node_child_user': (
            r'child_process\.(exec|execSync)\s*\([^)]*req\.',
            'child_process.exec with request data',
            'critical', 'CWE-78', 'trivial'
        ),
        'node_exec_file_user': (
            r'execFile\s*\([^)]*req\.',
            'execFile with request data',
            'high', 'CWE-78', 'easy'
        ),
        
        # Java
        'java_runtime_exec': (
            r'Runtime\.getRuntime\s*\(\s*\)\s*\.exec\s*\([^)]*\+',
            'Runtime.exec with concatenation',
            'critical', 'CWE-78', 'easy'
        ),
        'java_processbuilder_user': (
            r'ProcessBuilder\s*\([^)]*\+',
            'ProcessBuilder with concatenation',
            'high', 'CWE-78', 'easy'
        ),
        
        # Ruby
        'ruby_system': (
            r'(system|exec|`)\s*[^;]*params',
            'Ruby command execution with params',
            'critical', 'CWE-78', 'easy'
        ),
        'ruby_backtick_interp': (
            r'`[^`]*#\{[^}]*params',
            'Ruby backtick with interpolated params',
            'critical', 'CWE-78', 'trivial'
        ),
        'ruby_open_pipe': (
            r'(open|IO\.popen)\s*\([^)]*\|',
            'Ruby open/popen with pipe - command execution',
            'critical', 'CWE-78', 'easy'
        ),
        
        # Go
        'go_exec_command_user': (
            r'exec\.Command\s*\([^)]*\+',
            'Go exec.Command with concatenation',
            'high', 'CWE-78', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SQL INJECTION
    # Based on: Multiple HTB challenges and real-world examples
    # ═══════════════════════════════════════════════════════════════════════════
    'sql_injection': {
        # Classic SQL Injection
        'sql_concat_query': (
            r'(SELECT|INSERT|UPDATE|DELETE)\s+[^;]*(\.|\+)\s*\$',
            'SQL query with concatenated variable',
            'critical', 'CWE-89', 'trivial'
        ),
        'sql_concat_where': (
            r'WHERE\s+[^;]*(\.\s*\$|\+\s*\$)',
            'WHERE clause with concatenation',
            'critical', 'CWE-89', 'trivial'
        ),
        'sql_sprintf': (
            r'sprintf\s*\([^)]*SELECT[^)]*%s',
            'SQL via sprintf with %s',
            'high', 'CWE-89', 'easy'
        ),
        'sql_fstring': (
            r'f[\'"]SELECT[^"\']*\{[^}]*\}',
            'SQL via Python f-string',
            'critical', 'CWE-89', 'trivial'
        ),
        'sql_format': (
            r'\.format\s*\([^)]*\)[^;]*(SELECT|INSERT|UPDATE|DELETE)',
            'SQL via .format()',
            'high', 'CWE-89', 'easy'
        ),
        
        # PHP specific
        'php_mysql_query_user': (
            r'mysql_query\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Direct mysql_query with superglobal',
            'critical', 'CWE-89', 'trivial'
        ),
        'php_mysqli_query_user': (
            r'mysqli_query\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Direct mysqli_query with superglobal',
            'critical', 'CWE-89', 'trivial'
        ),
        'php_pdo_query_user': (
            r'->query\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Direct PDO query with superglobal',
            'critical', 'CWE-89', 'trivial'
        ),
        'php_pg_query_user': (
            r'pg_query\s*\([^)]*\$',
            'pg_query with variable',
            'high', 'CWE-89', 'easy'
        ),
        
        # ORM SQLi (second-order)
        'orm_raw_query': (
            r'(->raw|->rawQuery|\.raw|\.rawQuery)\s*\([^)]*\$',
            'ORM raw query with variable',
            'high', 'CWE-89', 'easy'
        ),
        'orm_whereraw': (
            r'(whereRaw|havingRaw|orderByRaw|selectRaw)\s*\([^)]*\$',
            'ORM raw expression with variable',
            'high', 'CWE-89', 'easy'
        ),
        
        # NoSQL Injection
        'nosql_mongo_find': (
            r'\.(find|findOne|aggregate)\s*\(\s*\{[^}]*\$',
            'MongoDB query with variable - NoSQL injection',
            'high', 'CWE-943', 'easy'
        ),
        'nosql_mongo_where': (
            r'\$where\s*:\s*[\'"][^\'"]*\+',
            'MongoDB $where with concatenation - JS injection',
            'critical', 'CWE-943', 'easy'
        ),
        'nosql_ne_bypass': (
            r'\$ne\s*:\s*',
            'MongoDB $ne operator - auth bypass pattern',
            'medium', 'CWE-943', 'easy'
        ),
        'nosql_regex_bypass': (
            r'\$regex\s*:\s*',
            'MongoDB $regex - potential ReDoS or bypass',
            'medium', 'CWE-943', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TEMPLATE INJECTION (SSTI)
    # Based on: HTB BugBounty module, multiple challenges
    # ═══════════════════════════════════════════════════════════════════════════
    'ssti': {
        # Jinja2
        'ssti_jinja_render_string': (
            r'render_template_string\s*\([^)]*(\+|request|user)',
            'Jinja2 render_template_string with user input - RCE',
            'critical', 'CWE-94', 'easy'
        ),
        'ssti_jinja_from_string': (
            r'from_string\s*\([^)]*(\+|request)',
            'Jinja2 from_string with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'ssti_jinja_template_class': (
            r'Template\s*\([^)]*(\+|request)',
            'Direct Template() with user input',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Twig
        'ssti_twig_render': (
            r'->render\s*\([^)]*(\+|\$_)',
            'Twig render with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'ssti_twig_createtemplate': (
            r'createTemplate\s*\([^)]*\$',
            'Twig createTemplate with variable',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Smarty
        'ssti_smarty_eval': (
            r'smarty.*eval\s*\(',
            'Smarty eval',
            'critical', 'CWE-94', 'easy'
        ),
        'ssti_smarty_literal': (
            r'\{literal\}.*\{\$smarty',
            'Smarty literal with variable access',
            'high', 'CWE-94', 'moderate'
        ),
        
        # Velocity (Java)
        'ssti_velocity': (
            r'VelocityEngine.*evaluate\s*\([^)]*\+',
            'Velocity evaluate with concatenation',
            'critical', 'CWE-94', 'easy'
        ),
        'ssti_velocity_merge': (
            r'VelocityEngine.*merge\s*\(',
            'Velocity merge - check template source',
            'high', 'CWE-94', 'moderate'
        ),
        
        # Freemarker
        'ssti_freemarker': (
            r'freemarker\.template\.Template\s*\([^)]*\+',
            'Freemarker Template with concatenation',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Ruby ERB
        'ssti_erb_new': (
            r'ERB\.new\s*\([^)]*params',
            'Ruby ERB with params',
            'critical', 'CWE-94', 'easy'
        ),
        'ssti_erb_render': (
            r'render\s+inline\s*:\s*[^,]*params',
            'Rails render inline with params',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Pebble
        'ssti_pebble': (
            r'PebbleEngine.*evaluate\s*\([^)]*\+',
            'Pebble template injection',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Mako
        'ssti_mako': (
            r'Template\s*\([^)]*request\.',
            'Mako Template with request data',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Generic detection payloads in data
        'ssti_payload_detect': (
            r'\{\{\s*7\s*\*\s*7\s*\}\}',
            'SSTI test payload in code/data',
            'high', 'CWE-94', 'trivial'
        ),
        'ssti_payload_detect2': (
            r'\$\{\s*7\s*\*\s*7\s*\}',
            'SSTI test payload (alternate syntax)',
            'high', 'CWE-94', 'trivial'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FILE OPERATIONS (LFI/RFI/PATH TRAVERSAL/ARBITRARY WRITE)
    # Based on: Retired machine, various challenges
    # ═══════════════════════════════════════════════════════════════════════════
    'file_operations': {
        # LFI - PHP
        'php_lfi_include_direct': (
            r'include\s*\(\s*\$_(GET|POST|REQUEST)',
            'Direct include with superglobal - LFI/RFI',
            'critical', 'CWE-98', 'trivial'
        ),
        'php_lfi_require_direct': (
            r'require\s*\(\s*\$_(GET|POST|REQUEST)',
            'Direct require with superglobal - LFI/RFI',
            'critical', 'CWE-98', 'trivial'
        ),
        'php_lfi_include_once_direct': (
            r'include_once\s*\(\s*\$_(GET|POST|REQUEST)',
            'Direct include_once with superglobal',
            'critical', 'CWE-98', 'trivial'
        ),
        'php_lfi_require_once_direct': (
            r'require_once\s*\(\s*\$_(GET|POST|REQUEST)',
            'Direct require_once with superglobal',
            'critical', 'CWE-98', 'trivial'
        ),
        'php_lfi_concat': (
            r'(include|require)(_once)?\s*\([^)]*\.\s*\$',
            'File inclusion with concatenation',
            'high', 'CWE-98', 'easy'
        ),
        
        # Path Traversal
        'path_traversal_dotdot': (
            r'\.\./\.\.',
            'Path traversal sequence in code',
            'high', 'CWE-22', 'trivial'
        ),
        'path_traversal_readfile': (
            r'(readfile|file_get_contents|fopen|file)\s*\([^)]*\$_(GET|POST|REQUEST)',
            'File read with superglobal',
            'high', 'CWE-22', 'easy'
        ),
        'path_traversal_realpath': (
            r'realpath\s*\([^)]*\$[^)]+\)(?!.*===)',
            'realpath without strict comparison',
            'medium', 'CWE-22', 'moderate'
        ),
        
        # Arbitrary File Write
        'file_write_user': (
            r'file_put_contents\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Arbitrary file write with user input',
            'critical', 'CWE-434', 'trivial'
        ),
        'file_write_var': (
            r'file_put_contents\s*\([^,]*\$[^,]+,\s*\$',
            'file_put_contents with variable path and content',
            'high', 'CWE-434', 'easy'
        ),
        'file_write_fwrite': (
            r'fwrite\s*\(\s*\$[^,]+,\s*\$_(GET|POST|REQUEST)',
            'fwrite with user input',
            'high', 'CWE-434', 'easy'
        ),
        
        # File Upload
        'file_upload_no_check': (
            r'move_uploaded_file\s*\([^)]+\$_(FILES|GET|POST)\[[\'"][^\'"]+[\'"]\]\[[\'"]name[\'"]\]',
            'File upload using original filename',
            'high', 'CWE-434', 'easy'
        ),
        'file_upload_extension': (
            r'pathinfo\s*\([^)]+PATHINFO_EXTENSION[^)]+\)\s*\!?=+\s*[\'"]php[\'"]',
            'Extension check bypasses (double extension)',
            'medium', 'CWE-434', 'moderate'
        ),
        
        # File Deletion
        'file_delete_user': (
            r'unlink\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Arbitrary file deletion with user input',
            'high', 'CWE-22', 'easy'
        ),
        
        # Python
        'py_file_read': (
            r'open\s*\([^)]*request\.',
            'Python file open with request data',
            'high', 'CWE-22', 'easy'
        ),
        'py_path_join': (
            r'os\.path\.join\s*\([^)]*request\.[^)]*\)',
            'os.path.join with request - path traversal',
            'high', 'CWE-22', 'easy'
        ),
        
        # Node.js
        'node_fs_read': (
            r'(fs\.readFile|fs\.readFileSync)\s*\([^)]*req\.',
            'fs.readFile with request data',
            'high', 'CWE-22', 'easy'
        ),
        'node_path_join_user': (
            r'path\.join\s*\([^)]*req\.',
            'path.join with request - path traversal',
            'high', 'CWE-22', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TYPE JUGGLING / LOOSE COMPARISON
    # Based on: HTB WebSenior module Type Juggling
    # ═══════════════════════════════════════════════════════════════════════════
    'type_juggling': {
        # PHP Type Juggling
        'php_loose_compare_0e': (
            r'\$\w+\s*==\s*[\'"]0e\d',
            'Magic hash comparison (0e)',
            'high', 'CWE-697', 'easy'
        ),
        'php_loose_compare_bool': (
            r'\$\w+\s*==\s*(true|false)',
            'Loose comparison with boolean',
            'medium', 'CWE-697', 'easy'
        ),
        'php_loose_compare_0': (
            r'\$\w+\s*==\s*0(?!\d)',
            'Loose comparison with 0',
            'medium', 'CWE-697', 'easy'
        ),
        'php_loose_compare_null': (
            r'\$\w+\s*==\s*null',
            'Loose comparison with null',
            'medium', 'CWE-697', 'easy'
        ),
        'php_loose_compare_empty_string': (
            r'\$\w+\s*==\s*[\'"][\'"]',
            'Loose comparison with empty string',
            'medium', 'CWE-697', 'easy'
        ),
        'php_strcmp_array_bypass': (
            r'strcmp\s*\([^)]+\)\s*==\s*0',
            'strcmp with == (array bypass)',
            'high', 'CWE-697', 'easy'
        ),
        'php_in_array_loose': (
            r'in_array\s*\([^)]+\)(?!\s*,\s*true)',
            'in_array without strict mode',
            'medium', 'CWE-697', 'moderate'
        ),
        'php_array_search_loose': (
            r'array_search\s*\([^)]+\)(?!\s*,\s*true)',
            'array_search without strict mode',
            'medium', 'CWE-697', 'moderate'
        ),
        'php_switch_loose': (
            r'switch\s*\(\s*\$\w+\s*\)\s*\{[^}]*case\s+0\s*:',
            'Switch with integer 0 case (type coercion)',
            'medium', 'CWE-697', 'moderate'
        ),
        
        # JavaScript type coercion
        'js_loose_compare': (
            r'[!=]=\s*(?![!=])',
            'JavaScript loose comparison',
            'low', 'CWE-697', 'moderate'
        ),
        'js_parseint_base': (
            r'parseInt\s*\([^)]+\)(?!\s*,\s*\d)',
            'parseInt without explicit base',
            'low', 'CWE-697', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # RACE CONDITIONS
    # Based on: HTB WebSenior Race Conditions module
    # ═══════════════════════════════════════════════════════════════════════════
    'race_conditions': {
        # TOCTOU patterns
        'race_file_check_then_use': (
            r'(file_exists|is_file|is_readable)\s*\([^)]+\)\s*[^{]*\{[^}]*(include|require|readfile|file_get_contents|fopen)',
            'TOCTOU: file check then use',
            'medium', 'CWE-367', 'hard'
        ),
        'race_check_then_action': (
            r'(if|while)\s*\([^)]*check[^)]*\)[^{]*\{[^}]*(update|delete|insert|create)',
            'TOCTOU: check then action pattern',
            'medium', 'CWE-367', 'hard'
        ),
        
        # No locks
        'race_no_transaction': (
            r'(SELECT.*FOR UPDATE|LOCK\s+TABLES?|BEGIN\s+TRANSACTION?)',
            'Database locking (verify usage)',
            'info', 'CWE-367', 'moderate'
        ),
        'race_gift_card_pattern': (
            r'(redeem|use|claim|activate)\s*.*\{[^}]*(check|valid)[^}]*(update|set)',
            'Redeem pattern without locking',
            'medium', 'CWE-367', 'hard'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # AUTHENTICATION BYPASS
    # Based on: Various HTB challenges
    # ═══════════════════════════════════════════════════════════════════════════
    'auth_bypass': {
        # JWT
        'jwt_none_algorithm': (
            r'[\'"]alg[\'"]\s*:\s*[\'"]none[\'"]',
            'JWT none algorithm - authentication bypass',
            'critical', 'CWE-287', 'trivial'
        ),
        'jwt_weak_secret': (
            r'jwt[_-]?secret\s*[=:]\s*[\'"](?!.{20,})[^\'"]+[\'"]',
            'JWT weak secret (< 20 chars)',
            'high', 'CWE-287', 'easy'
        ),
        'jwt_hs256_to_rs256': (
            r'(RS256|RS384|RS512).*verify',
            'JWT RS256 (check for algorithm confusion)',
            'medium', 'CWE-287', 'moderate'
        ),
        
        # Session
        'session_predictable': (
            r'session_id\s*\(\s*\$',
            'Custom session ID - predictable?',
            'medium', 'CWE-330', 'moderate'
        ),
        'session_fixation': (
            r'session_start\s*\([^)]*\)(?!.*session_regenerate_id)',
            'session_start without regeneration',
            'medium', 'CWE-384', 'moderate'
        ),
        
        # SQL auth bypass
        'auth_sql_bypass': (
            r'SELECT.*password.*WHERE.*user.*=.*\$',
            'SQL auth without parameterization',
            'high', 'CWE-89', 'easy'
        ),
        
        # Default credentials
        'default_creds': (
            r'(username|user|login)\s*[=:]\s*[\'"]admin[\'"].*\n.*(password|pass|pwd)\s*[=:]\s*[\'"]admin[\'"]',
            'Default admin credentials',
            'high', 'CWE-798', 'trivial'
        ),
        
        # Insecure comparison
        'auth_timing_attack': (
            r'if\s*\(\s*\$\w+\s*===?\s*\$',
            'String comparison (potential timing attack)',
            'low', 'CWE-208', 'expert'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # PROTOTYPE POLLUTION (JavaScript)
    # Based on: HTB WebSenior Prototype RCE module
    # ═══════════════════════════════════════════════════════════════════════════
    'prototype_pollution': {
        'proto_assignment': (
            r'__proto__\s*[=\[]',
            'Direct __proto__ assignment',
            'high', 'CWE-1321', 'moderate'
        ),
        'proto_constructor': (
            r'constructor\s*\[\s*[\'"]prototype[\'"]\s*\]',
            'constructor.prototype access',
            'high', 'CWE-1321', 'moderate'
        ),
        'proto_merge_deep': (
            r'(merge|extend|assign|deepMerge)\s*\([^)]*req\.',
            'Deep merge with request data',
            'high', 'CWE-1321', 'easy'
        ),
        'proto_lodash': (
            r'(lodash|_)\.(merge|defaultsDeep|set|setWith)',
            'Lodash vulnerable functions',
            'medium', 'CWE-1321', 'moderate'
        ),
        'proto_user_key': (
            r'\[req\.(body|query|params)\.',
            'Dynamic property access with user input',
            'high', 'CWE-1321', 'easy'
        ),
        'proto_recursive_merge': (
            r'function\s+\w*[Mm]erge\w*\s*\([^)]*\)\s*\{[^}]*\[[^\]]+\]\s*=',
            'Custom recursive merge function',
            'medium', 'CWE-1321', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # XXE (XML External Entity)
    # ═══════════════════════════════════════════════════════════════════════════
    'xxe': {
        # PHP
        'php_xxe_simplexml': (
            r'simplexml_load_string\s*\([^)]*\$',
            'simplexml with user input - XXE',
            'high', 'CWE-611', 'easy'
        ),
        'php_xxe_dom': (
            r'(new\s+)?DOMDocument.*loadXML\s*\([^)]*\$',
            'DOMDocument loadXML with user input',
            'high', 'CWE-611', 'easy'
        ),
        'php_xxe_enabled': (
            r'libxml_disable_entity_loader\s*\(\s*false',
            'Entity loader explicitly enabled',
            'high', 'CWE-611', 'easy'
        ),
        'php_xxe_external': (
            r'LIBXML_NOENT',
            'LIBXML_NOENT flag - entity expansion',
            'high', 'CWE-611', 'easy'
        ),
        
        # Java
        'java_xxe_docbuilder': (
            r'DocumentBuilderFactory\.newInstance\s*\(\s*\)(?!.*setFeature)',
            'DocumentBuilderFactory without secure features',
            'high', 'CWE-611', 'easy'
        ),
        'java_xxe_saxparser': (
            r'SAXParserFactory\.newInstance\s*\(\s*\)(?!.*setFeature)',
            'SAXParserFactory without secure features',
            'high', 'CWE-611', 'easy'
        ),
        'java_xxe_xmlinput': (
            r'XMLInputFactory\.newInstance\s*\(\s*\)',
            'XMLInputFactory - check DTD settings',
            'medium', 'CWE-611', 'moderate'
        ),
        
        # Python
        'py_xxe_etree': (
            r'(ElementTree|etree)\.(parse|fromstring)\s*\([^)]*request',
            'XML parsing with request data',
            'high', 'CWE-611', 'easy'
        ),
        'py_xxe_lxml': (
            r'lxml\.etree\.(parse|fromstring)\s*\(',
            'lxml parsing - check DTD settings',
            'medium', 'CWE-611', 'moderate'
        ),
        
        # .NET
        'dotnet_xxe': (
            r'XmlDocument.*LoadXml',
            '.NET XmlDocument LoadXml',
            'high', 'CWE-611', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SSRF (Server-Side Request Forgery)
    # Based on: HTB BugBounty SSRF module
    # ═══════════════════════════════════════════════════════════════════════════
    'ssrf': {
        # PHP
        'php_ssrf_curl': (
            r'curl_setopt\s*\([^)]*CURLOPT_URL[^)]*\$',
            'cURL with user-controlled URL',
            'high', 'CWE-918', 'easy'
        ),
        'php_ssrf_file_get': (
            r'file_get_contents\s*\([^)]*\$_(GET|POST|REQUEST)',
            'file_get_contents with superglobal',
            'high', 'CWE-918', 'easy'
        ),
        'php_ssrf_fopen': (
            r'fopen\s*\([^)]*\$_(GET|POST|REQUEST)',
            'fopen with superglobal',
            'high', 'CWE-918', 'easy'
        ),
        'php_ssrf_fsockopen': (
            r'fsockopen\s*\([^)]*\$',
            'fsockopen with variable',
            'high', 'CWE-918', 'easy'
        ),
        
        # Python
        'py_ssrf_requests': (
            r'requests\.(get|post|put|delete|head|options)\s*\([^)]*request\.',
            'requests library with request data',
            'high', 'CWE-918', 'easy'
        ),
        'py_ssrf_urllib': (
            r'urllib\.(request\.)?urlopen\s*\([^)]*request\.',
            'urllib with request data',
            'high', 'CWE-918', 'easy'
        ),
        
        # Node.js
        'node_ssrf_axios': (
            r'axios\.(get|post|put|delete)\s*\([^)]*req\.',
            'axios with request data',
            'high', 'CWE-918', 'easy'
        ),
        'node_ssrf_fetch': (
            r'fetch\s*\([^)]*req\.(body|query|params)',
            'fetch with request data',
            'high', 'CWE-918', 'easy'
        ),
        'node_ssrf_http': (
            r'http\.request\s*\([^)]*req\.',
            'http.request with request data',
            'high', 'CWE-918', 'easy'
        ),
        
        # Java
        'java_ssrf_url': (
            r'new\s+URL\s*\([^)]*\+',
            'Java URL with concatenation',
            'high', 'CWE-918', 'easy'
        ),
        'java_ssrf_httpclient': (
            r'HttpClient.*execute.*\+',
            'HttpClient with concatenation',
            'high', 'CWE-918', 'easy'
        ),
        
        # Bypass patterns
        'ssrf_bypass_localhost': (
            r'(127\.0\.0\.1|localhost|0\.0\.0\.0|0x7f|017700000001)',
            'Localhost reference - SSRF target',
            'info', 'CWE-918', 'trivial'
        ),
        'ssrf_bypass_metadata': (
            r'169\.254\.169\.254',
            'AWS metadata endpoint',
            'info', 'CWE-918', 'trivial'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # XSS (Cross-Site Scripting)
    # Based on: HTB BugBounty XSS modules
    # ═══════════════════════════════════════════════════════════════════════════
    'xss': {
        # PHP Reflected
        'php_xss_echo_get': (
            r'echo\s+[^;]*\$_GET\[[\'"][^\'"]+[\'"]\]',
            'Reflected XSS via $_GET',
            'high', 'CWE-79', 'easy'
        ),
        'php_xss_echo_post': (
            r'echo\s+[^;]*\$_POST\[[\'"][^\'"]+[\'"]\]',
            'Reflected XSS via $_POST',
            'high', 'CWE-79', 'easy'
        ),
        'php_xss_echo_request': (
            r'echo\s+[^;]*\$_REQUEST\[[\'"][^\'"]+[\'"]\]',
            'Reflected XSS via $_REQUEST',
            'high', 'CWE-79', 'easy'
        ),
        'php_xss_print': (
            r'print\s+[^;]*\$_(GET|POST|REQUEST)',
            'XSS via print',
            'high', 'CWE-79', 'easy'
        ),
        'php_xss_short_echo': (
            r'<\?=\s*\$_(GET|POST|REQUEST)',
            'XSS via PHP short echo tag',
            'high', 'CWE-79', 'easy'
        ),
        
        # JavaScript DOM XSS
        'js_xss_innerhtml': (
            r'\.innerHTML\s*=\s*[^;]*(location|document\.(URL|cookie|referrer)|window\.name)',
            'DOM XSS via innerHTML',
            'high', 'CWE-79', 'easy'
        ),
        'js_xss_document_write': (
            r'document\.write\s*\([^)]*location',
            'DOM XSS via document.write',
            'high', 'CWE-79', 'easy'
        ),
        'js_xss_eval_location': (
            r'eval\s*\([^)]*location',
            'DOM XSS via eval',
            'critical', 'CWE-79', 'easy'
        ),
        'js_xss_jquery_html': (
            r'\$\([^)]+\)\.html\s*\([^)]*\$',
            'jQuery .html() with variable',
            'high', 'CWE-79', 'easy'
        ),
        'js_xss_jquery_append': (
            r'\$\([^)]+\)\.(append|prepend|after|before)\s*\([^)]*location',
            'jQuery DOM manipulation with location',
            'high', 'CWE-79', 'easy'
        ),
        
        # Python
        'py_xss_render': (
            r'render_template\s*\([^)]*\|safe',
            'Jinja2 |safe filter - XSS',
            'high', 'CWE-79', 'easy'
        ),
        'py_xss_markup': (
            r'Markup\s*\([^)]*request',
            'Flask Markup with request data',
            'high', 'CWE-79', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CRYPTOGRAPHIC ISSUES
    # ═══════════════════════════════════════════════════════════════════════════
    'crypto': {
        'crypto_md5': (
            r'\b(md5|MD5)\s*\([^)]*\)',
            'MD5 hash (weak)',
            'medium', 'CWE-328', 'easy'
        ),
        'crypto_sha1': (
            r'\b(sha1|SHA1)\s*\([^)]*\)',
            'SHA1 hash (weak)',
            'medium', 'CWE-328', 'easy'
        ),
        'crypto_des': (
            r'\bDES\b',
            'DES encryption (weak)',
            'medium', 'CWE-327', 'easy'
        ),
        'crypto_ecb': (
            r'(ECB|MODE_ECB)',
            'ECB mode (weak)',
            'medium', 'CWE-327', 'easy'
        ),
        'crypto_rand': (
            r'\b(rand|mt_rand|random|Math\.random)\s*\(',
            'Weak random number generator',
            'medium', 'CWE-338', 'easy'
        ),
        'crypto_static_iv': (
            r'iv\s*=\s*[\'"][^\'"]{16}[\'"]',
            'Static IV',
            'medium', 'CWE-329', 'moderate'
        ),
        'crypto_hardcoded_key': (
            r'(key|secret)\s*=\s*[\'"][^\'"]{16,}[\'"]',
            'Hardcoded encryption key',
            'high', 'CWE-321', 'trivial'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HARDCODED SECRETS
    # ═══════════════════════════════════════════════════════════════════════════
    'secrets': {
        'secret_aws_access': (
            r'AKIA[0-9A-Z]{16}',
            'AWS Access Key ID',
            'critical', 'CWE-798', 'trivial'
        ),
        'secret_aws_secret': (
            r'[\'"][0-9a-zA-Z/+]{40}[\'"]',
            'Potential AWS Secret Key',
            'high', 'CWE-798', 'easy'
        ),
        'secret_github_token': (
            r'(ghp_[0-9a-zA-Z]{36}|github_pat_[0-9a-zA-Z_]{22,})',
            'GitHub Personal Access Token',
            'critical', 'CWE-798', 'trivial'
        ),
        'secret_slack_token': (
            r'xox[baprs]-[0-9]{10,13}-[0-9]{10,13}[a-zA-Z0-9-]*',
            'Slack Token',
            'critical', 'CWE-798', 'trivial'
        ),
        'secret_private_key': (
            r'-----BEGIN (RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----',
            'Private key in code',
            'critical', 'CWE-798', 'trivial'
        ),
        'secret_generic_password': (
            r'(password|passwd|pwd)\s*[=:]\s*[\'"][^\'"]{8,}[\'"]',
            'Hardcoded password',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_generic_api_key': (
            r'(api[_-]?key|apikey|api[_-]?secret)\s*[=:]\s*[\'"][^\'"]{16,}[\'"]',
            'Hardcoded API key',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_jwt_secret': (
            r'jwt[_-]?(secret|key)\s*[=:]\s*[\'"][^\'"]+[\'"]',
            'JWT secret in code',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_firebase': (
            r'AIza[0-9A-Za-z_-]{35}',
            'Firebase API Key',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_stripe': (
            r'sk_(live|test)_[0-9a-zA-Z]{24}',
            'Stripe Secret Key',
            'critical', 'CWE-798', 'trivial'
        ),
        'secret_twilio': (
            r'SK[0-9a-fA-F]{32}',
            'Twilio API Key',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_mailgun': (
            r'key-[0-9a-zA-Z]{32}',
            'Mailgun API Key',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_sendgrid': (
            r'SG\.[0-9A-Za-z_-]{22}\.[0-9A-Za-z_-]{43}',
            'SendGrid API Key',
            'high', 'CWE-798', 'trivial'
        ),
        'secret_heroku': (
            r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}',
            'Heroku API Key (UUID)',
            'medium', 'CWE-798', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HEADER INJECTION / CRLF
    # ═══════════════════════════════════════════════════════════════════════════
    'header_injection': {
        'php_header_injection': (
            r'header\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Header injection via superglobal',
            'high', 'CWE-113', 'easy'
        ),
        'php_setcookie_user': (
            r'setcookie\s*\([^)]*\$',
            'Cookie with user input',
            'medium', 'CWE-113', 'moderate'
        ),
        'py_header_injection': (
            r'response\.(headers|set_cookie)\s*\[[^\]]*\]\s*=\s*[^;]*request',
            'Python header injection',
            'high', 'CWE-113', 'easy'
        ),
        'crlf_pattern': (
            r'(%0d|%0a|\\r|\\n)',
            'CRLF characters in code',
            'medium', 'CWE-93', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # OPEN REDIRECT
    # ═══════════════════════════════════════════════════════════════════════════
    'open_redirect': {
        'php_redirect_location': (
            r'header\s*\([^)]*Location[^)]*\$_(GET|POST|REQUEST)',
            'Open redirect via Location header',
            'medium', 'CWE-601', 'easy'
        ),
        'php_redirect_meta': (
            r'<meta[^>]*http-equiv[^>]*refresh[^>]*\$',
            'Open redirect via meta refresh',
            'medium', 'CWE-601', 'easy'
        ),
        'js_redirect_location': (
            r'(window\.location|document\.location|location\.href)\s*=\s*[^;]*(url|redirect|return|next|goto)',
            'JS redirect with URL parameter',
            'medium', 'CWE-601', 'easy'
        ),
        'py_redirect': (
            r'redirect\s*\([^)]*request\.(args|form)',
            'Python redirect with request data',
            'medium', 'CWE-601', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MEMORY CORRUPTION (C/C++)
    # Based on: Retired machine buffer overflow
    # ═══════════════════════════════════════════════════════════════════════════
    'memory_corruption': {
        'c_strcpy': (
            r'strcpy\s*\(',
            'strcpy (buffer overflow)',
            'high', 'CWE-120', 'moderate'
        ),
        'c_strcat': (
            r'strcat\s*\(',
            'strcat (buffer overflow)',
            'high', 'CWE-120', 'moderate'
        ),
        'c_sprintf': (
            r'sprintf\s*\(',
            'sprintf (buffer overflow)',
            'high', 'CWE-120', 'moderate'
        ),
        'c_gets': (
            r'\bgets\s*\(',
            'gets (buffer overflow)',
            'critical', 'CWE-120', 'trivial'
        ),
        'c_scanf_s': (
            r'scanf\s*\([^)]*%s',
            'scanf %s without width (overflow)',
            'high', 'CWE-120', 'moderate'
        ),
        'c_format_string': (
            r'(printf|sprintf|fprintf)\s*\([^"\']+\)',
            'printf without format string',
            'high', 'CWE-134', 'moderate'
        ),
        'c_malloc_overflow': (
            r'malloc\s*\([^)]*\*[^)]*\)',
            'malloc with multiplication (integer overflow)',
            'medium', 'CWE-190', 'moderate'
        ),
        'c_memcpy_user': (
            r'memcpy\s*\([^,]+,[^,]+,[^)]*\w+len',
            'memcpy with user-controlled length',
            'high', 'CWE-120', 'moderate'
        ),
        'c_read_overflow': (
            r'read\s*\([^)]*,\s*buffer\s*,\s*[^)]*\w+(len|size)',
            'read() with user-controlled size (HTB: Retired)',
            'high', 'CWE-120', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CODE EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    'code_execution': {
        # PHP
        'php_eval': (
            r'eval\s*\([^)]*\$',
            'eval() with variable',
            'critical', 'CWE-94', 'trivial'
        ),
        'php_assert': (
            r'assert\s*\([^)]*\$',
            'assert() with variable',
            'critical', 'CWE-94', 'easy'
        ),
        'php_create_function': (
            r'create_function\s*\(',
            'create_function() (deprecated, dangerous)',
            'critical', 'CWE-94', 'easy'
        ),
        'php_preg_replace_e': (
            r'preg_replace\s*\([^)]*\/[^\/]*e[^)]*,\s*[^)]*\$',
            'preg_replace /e with variable',
            'critical', 'CWE-94', 'easy'
        ),
        'php_call_user_func': (
            r'call_user_func(_array)?\s*\([^)]*\$',
            'call_user_func with variable',
            'high', 'CWE-94', 'easy'
        ),
        'php_usort_callback': (
            r'(usort|uasort|uksort|array_map|array_filter|array_reduce|array_walk)\s*\([^)]*\$[^)]*\)',
            'Array function with user callback',
            'high', 'CWE-94', 'moderate'
        ),
        
        # Python
        'py_eval': (
            r'eval\s*\([^)]*request',
            'eval() with request data',
            'critical', 'CWE-94', 'trivial'
        ),
        'py_exec': (
            r'exec\s*\([^)]*request',
            'exec() with request data',
            'critical', 'CWE-94', 'trivial'
        ),
        'py_compile': (
            r'compile\s*\([^)]*request',
            'compile() with request data',
            'critical', 'CWE-94', 'easy'
        ),
        'py_getattr_setattr': (
            r'(getattr|setattr)\s*\([^)]*request',
            'getattr/setattr with request data',
            'high', 'CWE-94', 'moderate'
        ),
        
        # JavaScript
        'js_eval': (
            r'eval\s*\([^)]*req\.',
            'eval() with request data',
            'critical', 'CWE-94', 'trivial'
        ),
        'js_function_constructor': (
            r'new\s+Function\s*\([^)]*req',
            'Function constructor with request data',
            'critical', 'CWE-94', 'easy'
        ),
        'js_settimeout_string': (
            r'(setTimeout|setInterval)\s*\([^)]*req',
            'setTimeout/setInterval with request data',
            'high', 'CWE-94', 'easy'
        ),
        'js_vm_runin': (
            r'vm\.runIn(Context|NewContext|ThisContext)\s*\([^)]*req',
            'Node.js vm module with request data',
            'critical', 'CWE-94', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # GRAPHQL VULNERABILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    'graphql': {
        'graphql_introspection': (
            r'__schema|__type|introspectionQuery',
            'GraphQL introspection enabled',
            'medium', 'CWE-200', 'trivial'
        ),
        'graphql_batching': (
            r'graphql.*\[\s*\{',
            'GraphQL batching (potential DoS)',
            'medium', 'CWE-400', 'moderate'
        ),
        'graphql_depth': (
            r'depthLimit|queryDepth',
            'GraphQL depth limiting (verify configuration)',
            'info', 'CWE-400', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # WEBSOCKET VULNERABILITIES
    # Based on: HTB WebSenior WebSocket module
    # ═══════════════════════════════════════════════════════════════════════════
    'websocket': {
        'ws_no_origin_check': (
            r'WebSocket.*upgrade(?!.*origin)',
            'WebSocket without origin check',
            'medium', 'CWE-346', 'moderate'
        ),
        'ws_eval': (
            r'ws\.(on|once)\s*\([^)]*message[^}]*eval',
            'WebSocket message eval - RCE',
            'critical', 'CWE-94', 'easy'
        ),
        'ws_command': (
            r'ws\.on\s*\([^)]*message[^}]*(exec|system|spawn)',
            'WebSocket command execution',
            'critical', 'CWE-78', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # SERVER-SIDE INCLUDES (SSI)
    # Based on: HTB BugBounty SSI module
    # ═══════════════════════════════════════════════════════════════════════════
    'ssi': {
        'ssi_exec': (
            r'<!--#exec\s+cmd\s*=',
            'SSI exec directive',
            'critical', 'CWE-97', 'easy'
        ),
        'ssi_include': (
            r'<!--#include\s+(virtual|file)\s*=',
            'SSI include directive',
            'medium', 'CWE-97', 'easy'
        ),
        'ssi_echo': (
            r'<!--#echo\s+var\s*=',
            'SSI echo directive',
            'low', 'CWE-97', 'easy'
        ),
        'ssi_config': (
            r'<!--#config\s+',
            'SSI config directive',
            'low', 'CWE-97', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DEBUG / INFORMATION DISCLOSURE
    # ═══════════════════════════════════════════════════════════════════════════
    'debug_info': {
        'php_phpinfo': (
            r'phpinfo\s*\(',
            'phpinfo() exposed',
            'medium', 'CWE-200', 'trivial'
        ),
        'php_var_dump': (
            r'var_dump\s*\([^)]*\$',
            'var_dump in production',
            'low', 'CWE-200', 'trivial'
        ),
        'php_debug_backtrace': (
            r'debug_backtrace\s*\(',
            'debug_backtrace exposed',
            'low', 'CWE-200', 'trivial'
        ),
        'php_error_display': (
            r'display_errors\s*=\s*(1|On|true)',
            'display_errors enabled',
            'medium', 'CWE-200', 'trivial'
        ),
        'flask_debug': (
            r'app\.run\s*\([^)]*debug\s*=\s*True',
            'Flask debug mode enabled',
            'high', 'CWE-200', 'trivial'
        ),
        'django_debug': (
            r'DEBUG\s*=\s*True',
            'Django DEBUG enabled',
            'high', 'CWE-200', 'trivial'
        ),
        'node_stacktrace': (
            r'(err|error)\.stack',
            'Stack trace exposure',
            'medium', 'CWE-200', 'easy'
        ),
        'express_error_handler': (
            r'app\.use\s*\([^)]*err[^)]*\{[^}]*res\.(send|json)\s*\([^)]*err',
            'Express error handler exposing error',
            'medium', 'CWE-200', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CORS MISCONFIGURATION
    # ═══════════════════════════════════════════════════════════════════════════
    'cors': {
        'cors_wildcard': (
            r'Access-Control-Allow-Origin[\'"]?\s*:\s*[\'"]?\*',
            'CORS wildcard origin',
            'medium', 'CWE-942', 'easy'
        ),
        'cors_null': (
            r'Access-Control-Allow-Origin[\'"]?\s*:\s*[\'"]?null',
            'CORS null origin allowed',
            'high', 'CWE-942', 'easy'
        ),
        'cors_reflect': (
            r'Access-Control-Allow-Origin[\'"]?\s*:\s*[\'"]?\$',
            'CORS origin reflection',
            'high', 'CWE-942', 'easy'
        ),
        'cors_credentials': (
            r'Access-Control-Allow-Credentials[\'"]?\s*:\s*[\'"]?true',
            'CORS credentials allowed',
            'medium', 'CWE-942', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INSECURE RANDOM
    # ═══════════════════════════════════════════════════════════════════════════
    'insecure_random': {
        'php_rand_token': (
            r'(md5|sha1)\s*\(\s*(rand|mt_rand|uniqid)',
            'Weak random for token/secret',
            'high', 'CWE-330', 'easy'
        ),
        'php_uniqid_alone': (
            r'uniqid\s*\(\s*\)',
            'uniqid() without entropy',
            'medium', 'CWE-330', 'moderate'
        ),
        'py_random_secrets': (
            r'random\.(random|randint|choice|shuffle)\s*\(',
            'Python random (not cryptographically secure)',
            'medium', 'CWE-330', 'moderate'
        ),
        'js_math_random': (
            r'Math\.random\s*\(\)',
            'Math.random() for security',
            'medium', 'CWE-330', 'moderate'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # IDOR - INSECURE DIRECT OBJECT REFERENCE (CWE-639)
    # Based on: HTB BugBounty writeups, OWASP API Security
    # ═══════════════════════════════════════════════════════════════════════════
    'idor': {
        # Direct ID access patterns
        'idor_direct_id_get': (
            r'\$_(GET|REQUEST)\s*\[\s*[\'"]?(id|user_id|uid|account_id|order_id|file_id|doc_id|record_id)[\'"]?\s*\]',
            'IDOR: Direct ID from GET parameter without authorization check',
            'high', 'CWE-639', 'easy'
        ),
        'idor_direct_id_post': (
            r'\$_POST\s*\[\s*[\'"]?(id|user_id|uid|account_id|order_id)[\'"]?\s*\]',
            'IDOR: Direct ID from POST without authorization',
            'high', 'CWE-639', 'easy'
        ),
        'idor_numeric_param': (
            r'(findById|getById|find_by_id|get_by_id)\s*\(\s*\$_(GET|POST|REQUEST)',
            'IDOR: Direct database lookup by user-supplied ID',
            'critical', 'CWE-639', 'trivial'
        ),
        'idor_user_id_query': (
            r'(WHERE|where)\s+.*user_id\s*=\s*[\'"]?\s*\$',
            'IDOR: SQL query with user-controlled user_id',
            'high', 'CWE-639', 'easy'
        ),
        'idor_file_access': (
            r'(file_get_contents|readfile|fopen|include|require)\s*\([^)]*\$_(GET|POST|REQUEST)\s*\[',
            'IDOR: File access with user-controlled path/id',
            'critical', 'CWE-639', 'easy'
        ),
        
        # API IDOR patterns
        'idor_api_path_param': (
            r'/api/[^/]*/\$[a-zA-Z_]+',
            'IDOR: API endpoint with variable path parameter',
            'medium', 'CWE-639', 'moderate'
        ),
        'idor_rest_resource': (
            r'(GET|PUT|DELETE|PATCH)\s+[\'"]?/[^/]+/\{?id\}?',
            'IDOR: REST endpoint accessing resource by ID',
            'medium', 'CWE-639', 'moderate'
        ),
        'idor_graphql_id': (
            r'query\s*\{[^}]*\(\s*id\s*:\s*\$',
            'IDOR: GraphQL query with direct ID parameter',
            'high', 'CWE-639', 'moderate'
        ),
        
        # Python/Flask/Django IDOR
        'idor_flask_route': (
            r'@app\.route\s*\([^)]*<int:.*id>',
            'IDOR: Flask route with numeric ID - verify authorization',
            'medium', 'CWE-639', 'moderate'
        ),
        'idor_django_pk': (
            r'\.get\s*\(\s*pk\s*=\s*request\.(GET|POST)',
            'IDOR: Django direct pk lookup from request',
            'high', 'CWE-639', 'easy'
        ),
        'idor_django_filter': (
            r'\.filter\s*\(\s*id\s*=\s*request\.(GET|POST)',
            'IDOR: Django filter by user-controlled ID',
            'high', 'CWE-639', 'easy'
        ),
        
        # Node.js IDOR
        'idor_express_params': (
            r'req\.params\.(id|userId|accountId|orderId)',
            'IDOR: Express route param - verify ownership',
            'medium', 'CWE-639', 'moderate'
        ),
        'idor_mongoose_findbyid': (
            r'findById\s*\(\s*req\.(params|query|body)\.',
            'IDOR: Mongoose findById with user input',
            'high', 'CWE-639', 'easy'
        ),
        
        # Java IDOR
        'idor_spring_pathvar': (
            r'@PathVariable\s*.*\s+(Long|Integer|String)\s+.*[iI]d',
            'IDOR: Spring @PathVariable ID - verify authorization',
            'medium', 'CWE-639', 'moderate'
        ),
        'idor_jpa_findbyid': (
            r'repository\.(findById|getById|getOne)\s*\([^)]*request',
            'IDOR: JPA findById from request',
            'high', 'CWE-639', 'easy'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # BOLA - BROKEN OBJECT LEVEL AUTHORIZATION (OWASP API1:2023)
    # Similar to IDOR but specifically for APIs
    # ═══════════════════════════════════════════════════════════════════════════
    'bola': {
        # Missing authorization checks
        'bola_no_auth_check': (
            r'def\s+\w+\s*\([^)]*id[^)]*\)\s*:\s*\n\s*return\s+.*\.get\s*\(',
            'BOLA: Function accesses object by ID without authorization check',
            'critical', 'CWE-639', 'easy'
        ),
        'bola_direct_access': (
            r'(getObject|fetchResource|loadEntity)\s*\([^)]*\$.*[iI]d[^)]*\)\s*;?\s*$',
            'BOLA: Direct object access without ownership verification',
            'high', 'CWE-639', 'easy'
        ),
        
        # API patterns without auth
        'bola_api_no_session': (
            r'@(Get|Post|Put|Delete)Mapping\s*\([^)]*\)\s*\n\s*public\s+\w+\s+\w+\s*\([^)]*@PathVariable[^)]*\)\s*\{[^}]*repository\.(find|get)',
            'BOLA: API endpoint with PathVariable directly queries DB',
            'high', 'CWE-639', 'moderate'
        ),
        'bola_graphql_mutation': (
            r'mutation\s*\{[^}]*(update|delete|modify)\w*\s*\(\s*id\s*:',
            'BOLA: GraphQL mutation on object by ID',
            'high', 'CWE-639', 'moderate'
        ),
        
        # Mass assignment leading to BOLA
        'bola_mass_assignment_php': (
            r'\$\w+\s*=\s*\(object\)\s*\$_(GET|POST|REQUEST)',
            'BOLA: Mass assignment from user input',
            'high', 'CWE-915', 'easy'
        ),
        'bola_mass_assignment_node': (
            r'Object\.assign\s*\(\s*\w+\s*,\s*req\.(body|query)',
            'BOLA: Object.assign with user input (mass assignment)',
            'high', 'CWE-915', 'easy'
        ),
        'bola_spread_operator': (
            r'\.\.\.\s*req\.(body|query|params)',
            'BOLA: Spread operator with user input',
            'high', 'CWE-915', 'easy'
        ),
        
        # Horizontal privilege escalation
        'bola_horizontal_escalation': (
            r'(user|account|profile)\s*=.*find.*\(\s*\$_(GET|POST|REQUEST)',
            'BOLA: Loading user/account from user input - horizontal escalation risk',
            'critical', 'CWE-639', 'easy'
        ),
        
        # Missing owner check patterns
        'bola_missing_owner_php': (
            r'function\s+\w+\s*\([^)]*\$id[^)]*\)\s*\{[^}]*\$.*=.*query.*WHERE\s+id\s*=\s*\$id[^}]*\}',
            'BOLA: PHP function queries by ID without owner check',
            'high', 'CWE-639', 'moderate'
        ),
        'bola_missing_owner_python': (
            r'def\s+\w+\s*\([^)]*\bid\b[^)]*\):[^:]*\n[^:]*\.get\s*\(\s*id\s*\)',
            'BOLA: Python function gets object by ID without owner verification',
            'high', 'CWE-639', 'moderate'
        ),
        
        # Tenant isolation failures
        'bola_missing_tenant': (
            r'SELECT\s+.*FROM\s+\w+\s+WHERE\s+id\s*=',
            'BOLA: Query without tenant/organization filter',
            'medium', 'CWE-639', 'moderate'
        ),
        'bola_tenant_from_user': (
            r'(tenant_id|org_id|organization_id)\s*=\s*\$_(GET|POST|REQUEST)',
            'BOLA: Tenant ID from user input - multi-tenant bypass',
            'critical', 'CWE-639', 'trivial'
        ),
    },
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CODE INJECTION (CWE-94) - Beyond eval() and system()
    # Includes: Template injection, Expression Language, Reflection
    # ═══════════════════════════════════════════════════════════════════════════
    'code_injection': {
        # PHP Code Injection
        'codeinj_php_eval': (
            r'eval\s*\(\s*[\$\"\'].*?\)',
            'Code Injection: PHP eval() with dynamic content',
            'critical', 'CWE-94', 'trivial'
        ),
        'codeinj_php_create_function': (
            r'create_function\s*\([^)]*\$',
            'Code Injection: create_function() deprecated, injectable',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_php_assert': (
            r'assert\s*\(\s*[\'"]?[^)]*\$',
            'Code Injection: assert() with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_php_preg_e': (
            r'preg_replace\s*\(\s*[\'"][^\'"]*\/[^\/]*e[\'"\s]*,',
            'Code Injection: preg_replace /e modifier (RCE)',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_php_variable_func': (
            r'\$\w+\s*\(\s*.*\)',
            'Code Injection: Variable function call',
            'high', 'CWE-94', 'moderate'
        ),
        'codeinj_php_call_user_func': (
            r'call_user_func(_array)?\s*\([^)]*\$_(GET|POST|REQUEST)',
            'Code Injection: call_user_func with user input',
            'critical', 'CWE-94', 'trivial'
        ),
        'codeinj_php_include_var': (
            r'(include|require)(_once)?\s*\(\s*\$',
            'Code Injection: Dynamic include/require',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Python Code Injection
        'codeinj_python_eval': (
            r'eval\s*\([^)]*(?:request|input|argv|sys\.stdin)',
            'Code Injection: Python eval() with user input',
            'critical', 'CWE-94', 'trivial'
        ),
        'codeinj_python_exec': (
            r'exec\s*\([^)]*(?:request|input|argv|sys\.stdin)',
            'Code Injection: Python exec() with user input',
            'critical', 'CWE-94', 'trivial'
        ),
        'codeinj_python_compile': (
            r'compile\s*\([^)]*(?:request|input|argv)',
            'Code Injection: Python compile() with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_python_getattr': (
            r'getattr\s*\([^,]+,\s*(?:request|input)\.',
            'Code Injection: getattr() with user-controlled attribute',
            'high', 'CWE-94', 'moderate'
        ),
        'codeinj_python_import': (
            r'__import__\s*\([^)]*(?:request|input)',
            'Code Injection: Dynamic import with user input',
            'critical', 'CWE-94', 'easy'
        ),
        
        # JavaScript Code Injection
        'codeinj_js_eval': (
            r'eval\s*\([^)]*(?:req\.|request|params|query|body)',
            'Code Injection: JavaScript eval() with user input',
            'critical', 'CWE-94', 'trivial'
        ),
        'codeinj_js_function': (
            r'new\s+Function\s*\([^)]*(?:req\.|request)',
            'Code Injection: new Function() with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_js_settimeout': (
            r'(setTimeout|setInterval)\s*\([^,]*(?:req\.|request)',
            'Code Injection: setTimeout/setInterval with user string',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_vm_runin': (
            r'vm\.runIn(Context|NewContext|ThisContext)\s*\([^)]*(?:req\.|request)',
            'Code Injection: Node.js vm module with user input',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Java Code Injection
        'codeinj_java_scriptengine': (
            r'ScriptEngine.*\.eval\s*\([^)]*request',
            'Code Injection: ScriptEngine.eval() with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_java_reflection': (
            r'Class\.forName\s*\([^)]*request',
            'Code Injection: Reflection with user-controlled class name',
            'critical', 'CWE-94', 'moderate'
        ),
        'codeinj_java_beanutils': (
            r'BeanUtils\.(populate|setProperty)\s*\([^)]*request',
            'Code Injection: BeanUtils with user input (mass assignment)',
            'high', 'CWE-94', 'moderate'
        ),
        'codeinj_spring_spel': (
            r'SpelExpressionParser.*\.parseExpression\s*\([^)]*request',
            'Code Injection: Spring SpEL with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_java_el': (
            r'(ExpressionFactory|ValueExpression).*request',
            'Code Injection: Java EL injection',
            'critical', 'CWE-94', 'moderate'
        ),
        
        # Ruby Code Injection
        'codeinj_ruby_eval': (
            r'eval\s*\([^)]*params',
            'Code Injection: Ruby eval() with params',
            'critical', 'CWE-94', 'trivial'
        ),
        'codeinj_ruby_send': (
            r'\.send\s*\([^)]*params',
            'Code Injection: Ruby send() with user input',
            'high', 'CWE-94', 'moderate'
        ),
        'codeinj_ruby_constantize': (
            r'constantize\s*\([^)]*params',
            'Code Injection: Ruby constantize with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_erb_unsafe': (
            r'<%=\s*raw\s+.*params',
            'Code Injection: ERB raw with params (XSS/code injection)',
            'high', 'CWE-94', 'easy'
        ),
        
        # Expression Language Injection
        'codeinj_ognl': (
            r'Ognl\.getValue\s*\([^)]*request',
            'Code Injection: OGNL expression with user input',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_mvel': (
            r'MVEL\.(eval|compileExpression)\s*\([^)]*request',
            'Code Injection: MVEL expression injection',
            'critical', 'CWE-94', 'easy'
        ),
        'codeinj_jexl': (
            r'JexlEngine.*\.createExpression\s*\([^)]*request',
            'Code Injection: JEXL expression injection',
            'critical', 'CWE-94', 'easy'
        ),
        
        # Generic dangerous patterns
        'codeinj_dynamic_method': (
            r'\[\s*\$_(GET|POST|REQUEST)\s*\[',
            'Code Injection: Dynamic array access with user input',
            'medium', 'CWE-94', 'moderate'
        ),
        'codeinj_string_interpolation_exec': (
            r'`[^`]*\$\{[^}]*request[^}]*\}[^`]*`',
            'Code Injection: Template literal with user input in shell',
            'critical', 'CWE-94', 'easy'
        ),
    },
}


def get_all_patterns() -> Dict[str, Tuple[str, str, str, str, str]]:
    """Get all patterns as a flat dictionary"""
    all_patterns = {}
    for category, patterns in HTB_ULTIMATE_PATTERNS.items():
        for pattern_id, pattern_data in patterns.items():
            all_patterns[f"{category}_{pattern_id}"] = pattern_data
    return all_patterns


def get_patterns_by_severity(severity: str) -> Dict[str, Tuple[str, str, str, str, str]]:
    """Get patterns filtered by severity"""
    all_patterns = get_all_patterns()
    return {k: v for k, v in all_patterns.items() if v[2] == severity}


def get_patterns_by_category(category: str) -> Dict[str, Tuple[str, str, str, str, str]]:
    """Get patterns by category"""
    return HTB_ULTIMATE_PATTERNS.get(category, {})


def get_pattern_count() -> int:
    """Get total number of patterns"""
    return sum(len(patterns) for patterns in HTB_ULTIMATE_PATTERNS.values())


def get_categories() -> List[str]:
    """Get list of all categories"""
    return list(HTB_ULTIMATE_PATTERNS.keys())


# For backwards compatibility
ALL_HTB_PATTERNS = get_all_patterns()


if __name__ == '__main__':
    print(f"╔══════════════════════════════════════════════════════════════════╗")
    print(f"║  BrainX HTB Ultimate Patterns - Pattern Statistics               ║")
    print(f"╠══════════════════════════════════════════════════════════════════╣")
    print(f"║  Total Patterns: {get_pattern_count():<47}║")
    print(f"║  Categories: {len(get_categories()):<50}║")
    print(f"╠══════════════════════════════════════════════════════════════════╣")
    for cat in get_categories():
        count = len(HTB_ULTIMATE_PATTERNS[cat])
        print(f"║  {cat:<25} {count:>3} patterns                      ║")
    print(f"╚══════════════════════════════════════════════════════════════════╝")
