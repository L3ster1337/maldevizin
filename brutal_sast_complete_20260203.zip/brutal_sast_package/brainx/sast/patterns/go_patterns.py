"""
Go SAST Patterns - Vulnerability Patterns
"""

# ============================================================================
# GO VULNERABILITY PATTERNS
# ============================================================================
GO_PATTERNS = [
    # ----- COMMAND INJECTION -----
    {
        'id': 'go_cmdi_exec',
        'name': 'Go exec.Command() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'exec\.Command\s*\([^)]*(?:r\.|request\.|input|args|\+)',
        'description': 'Command injection via exec.Command()',
        'exploit': '; id #',
        'cwe': 'CWE-78',
    },
    {
        'id': 'go_cmdi_commandcontext',
        'name': 'Go exec.CommandContext() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'exec\.CommandContext\s*\([^)]*(?:r\.|request\.|input|args|\+)',
        'description': 'Command injection via exec.CommandContext()',
        'exploit': '| cat /etc/passwd',
        'cwe': 'CWE-78',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'go_sqli_concat',
        'name': 'Go SQL Injection (Concatenation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'db\.(Query|Exec|QueryRow)\s*\([^)]*\+[^)]*(?:r\.|request\.|input)',
        'description': 'SQL injection via string concatenation',
        'exploit': '\' OR 1=1--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'go_sqli_sprintf',
        'name': 'Go SQL Injection (fmt.Sprintf)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'fmt\.Sprintf\s*\([^)]*SELECT[^)]*%s',
        'description': 'SQL injection via fmt.Sprintf()',
        'exploit': '\'; DROP TABLE users;--',
        'cwe': 'CWE-89',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'go_path_traversal',
        'name': 'Go Path Traversal',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'(ioutil\.ReadFile|os\.Open|os\.ReadFile|http\.ServeFile)\s*\([^)]*(?:r\.|request\.|input|\+)',
        'description': 'Path traversal vulnerability',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- SSRF -----
    {
        'id': 'go_ssrf',
        'name': 'Go SSRF',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'http\.(Get|Post|Head|NewRequest)\s*\([^)]*(?:r\.|request\.|input)',
        'description': 'SSRF via HTTP client',
        'exploit': 'http://169.254.169.254/',
        'cwe': 'CWE-918',
    },
    
    # ----- XSS -----
    {
        'id': 'go_xss',
        'name': 'Go XSS',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'template\.HTML\s*\([^)]*(?:r\.|request\.|input)',
        'description': 'XSS via template.HTML()',
        'exploit': '<script>alert(1)</script>',
        'cwe': 'CWE-79',
    },
    
    # ----- INSECURE TLS -----
    {
        'id': 'go_insecure_tls',
        'name': 'Go Insecure TLS',
        'category': 'crypto',
        'severity': 'high',
        'pattern': r'InsecureSkipVerify\s*:\s*true',
        'description': 'TLS certificate verification disabled',
        'exploit': 'MITM attack',
        'cwe': 'CWE-295',
    },
    
    # ----- HARDCODED SECRETS -----
    {
        'id': 'go_secrets',
        'name': 'Go Hardcoded Secrets',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'(password|secret|apiKey|token)\s*:?=\s*"[^"]{8,}"',
        'description': 'Hardcoded secrets',
        'exploit': 'Credential theft',
        'cwe': 'CWE-798',
    },
    
    # ----- WEAK CRYPTO -----
    {
        'id': 'go_weak_crypto_md5',
        'name': 'Go Weak Hash (MD5)',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'md5\.New\s*\(\s*\)',
        'description': 'Weak MD5 hashing',
        'exploit': 'Hash collision',
        'cwe': 'CWE-328',
    },
    {
        'id': 'go_weak_crypto_sha1',
        'name': 'Go Weak Hash (SHA1)',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'sha1\.New\s*\(\s*\)',
        'description': 'Weak SHA1 hashing',
        'exploit': 'Hash collision',
        'cwe': 'CWE-328',
    },
    {
        'id': 'go_weak_random',
        'name': 'Go Weak Random',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'math/rand',
        'description': 'Non-cryptographic random (use crypto/rand)',
        'exploit': 'Predict random values',
        'cwe': 'CWE-330',
    },
    
    # ----- RACE CONDITIONS -----
    {
        'id': 'go_race_condition',
        'name': 'Go Race Condition',
        'category': 'race_condition',
        'severity': 'medium',
        'pattern': r'go\s+func\s*\([^)]*\)\s*\{[^}]*[a-zA-Z_][a-zA-Z0-9_]*\s*=',
        'description': 'Potential race condition in goroutine',
        'exploit': 'Data race',
        'cwe': 'CWE-362',
    },
    
    # ----- XXE -----
    {
        'id': 'go_xxe',
        'name': 'Go XXE',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'xml\.NewDecoder\s*\([^)]*(?:r\.|request\.|input)',
        'description': 'XXE via XML decoder',
        'exploit': '<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>',
        'cwe': 'CWE-611',
    },
    
    # ----- OPEN REDIRECT -----
    {
        'id': 'go_open_redirect',
        'name': 'Go Open Redirect',
        'category': 'open_redirect',
        'severity': 'medium',
        'pattern': r'http\.Redirect\s*\([^)]*(?:r\.|request\.|input)',
        'description': 'Open redirect vulnerability',
        'exploit': '//evil.com',
        'cwe': 'CWE-601',
    },
    
    # ----- DESERIALIZATION -----
    {
        'id': 'go_deser_gob',
        'name': 'Go Gob Deserialization',
        'category': 'deserialization',
        'severity': 'high',
        'pattern': r'gob\.NewDecoder\s*\([^)]*\)\.Decode\s*\(',
        'description': 'Gob deserialization from untrusted source',
        'exploit': 'Malicious gob payload',
        'cwe': 'CWE-502',
    },
    
    # ----- INTEGER OVERFLOW -----
    {
        'id': 'go_int_overflow',
        'name': 'Go Integer Overflow',
        'category': 'integer_overflow',
        'severity': 'medium',
        'pattern': r'int\([^)]*(?:r\.|request\.|input)\)',
        'description': 'Integer overflow from user input',
        'exploit': 'Large number causing overflow',
        'cwe': 'CWE-190',
    },
    
    # ----- DIRECTORY LISTING -----
    {
        'id': 'go_dir_listing',
        'name': 'Go Directory Listing',
        'category': 'info_disclosure',
        'severity': 'medium',
        'pattern': r'http\.FileServer\s*\(\s*http\.Dir\s*\(',
        'description': 'Directory listing enabled',
        'exploit': 'Information disclosure',
        'cwe': 'CWE-548',
    },
    
    # ----- CORS MISCONFIGURATION -----
    {
        'id': 'go_cors_all',
        'name': 'Go CORS Allow All Origins',
        'category': 'cors',
        'severity': 'medium',
        'pattern': r'Access-Control-Allow-Origin["\']?\s*[:,]\s*["\']?\*',
        'description': 'CORS allows all origins',
        'exploit': 'Cross-origin data theft',
        'cwe': 'CWE-942',
    },
]
