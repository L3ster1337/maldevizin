"""
BrainX SAST Scanner - Multi-language vulnerability scanner
"""

import os
import re
import json
import hashlib
from pathlib import Path
from typing import List, Dict, Any, Optional, Iterator
from dataclasses import dataclass, field, asdict
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

from .patterns import ALL_PATTERNS, get_language_by_extension, get_patterns


@dataclass
class VulnerabilityMatch:
    """Single vulnerability match"""
    id: str
    pattern_id: str
    pattern_name: str
    category: str
    severity: str
    file_path: str
    line_number: int
    line_content: str
    context_before: List[str] = field(default_factory=list)
    context_after: List[str] = field(default_factory=list)
    description: str = ''
    exploit: str = ''
    cwe: str = ''
    language: str = ''
    confidence: str = 'high'
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> dict:
        return asdict(self)
    
    def to_markdown(self) -> str:
        """Convert to Obsidian-compatible markdown"""
        md = f"""## {self.pattern_name}

**Severity**: {self.severity.upper()}  
**Category**: {self.category}  
**CWE**: {self.cwe}  
**File**: `{self.file_path}`  
**Line**: {self.line_number}  
**Language**: {self.language}  

### Vulnerable Code
```{self.language}
{chr(10).join(self.context_before)}
>>> {self.line_content}  # VULNERABLE
{chr(10).join(self.context_after)}
```

### Description
{self.description}

### Exploit
```
{self.exploit}
```

---
"""
        return md


@dataclass 
class ScanResult:
    """Complete scan result"""
    target_path: str
    scan_timestamp: str
    total_files: int
    files_scanned: int
    vulnerabilities: List[VulnerabilityMatch] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    stats: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            'target_path': self.target_path,
            'scan_timestamp': self.scan_timestamp,
            'total_files': self.total_files,
            'files_scanned': self.files_scanned,
            'vulnerabilities': [v.to_dict() for v in self.vulnerabilities],
            'errors': self.errors,
            'stats': self.stats,
        }
    
    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)
    
    def save_json(self, output_path: str):
        """Save results to JSON file"""
        with open(output_path, 'w') as f:
            f.write(self.to_json())
    
    def save_obsidian(self, output_dir: str, project_name: str = 'scan'):
        """Save results to Obsidian markdown files"""
        os.makedirs(output_dir, exist_ok=True)
        
        # Index file
        index_content = f"""# BrainX Security Scan - {project_name}

**Scan Date**: {self.scan_timestamp}  
**Target**: `{self.target_path}`  
**Files Scanned**: {self.files_scanned}/{self.total_files}  
**Vulnerabilities Found**: {len(self.vulnerabilities)}  

## Summary by Severity

| Severity | Count |
|----------|-------|
| Critical | {self.stats.get('by_severity', {}).get('critical', 0)} |
| High | {self.stats.get('by_severity', {}).get('high', 0)} |
| Medium | {self.stats.get('by_severity', {}).get('medium', 0)} |
| Low | {self.stats.get('by_severity', {}).get('low', 0)} |

## Summary by Category

| Category | Count |
|----------|-------|
"""
        for cat, count in self.stats.get('by_category', {}).items():
            index_content += f"| {cat} | {count} |\n"
        
        index_content += "\n## Findings\n\n"
        
        # Group by severity for listing
        by_severity = {'critical': [], 'high': [], 'medium': [], 'low': []}
        for v in self.vulnerabilities:
            sev = v.severity.lower()
            if sev in by_severity:
                by_severity[sev].append(v)
        
        for severity in ['critical', 'high', 'medium', 'low']:
            if by_severity[severity]:
                index_content += f"### {severity.upper()}\n\n"
                for v in by_severity[severity]:
                    safe_name = re.sub(r'[^\w\-]', '_', v.pattern_name)
                    index_content += f"- [[{safe_name}]] - {v.file_path}:{v.line_number}\n"
                index_content += "\n"
        
        # Save index
        with open(os.path.join(output_dir, f'{project_name}_index.md'), 'w') as f:
            f.write(index_content)
        
        # Individual finding files
        findings_dir = os.path.join(output_dir, 'findings')
        os.makedirs(findings_dir, exist_ok=True)
        
        for v in self.vulnerabilities:
            safe_name = re.sub(r'[^\w\-]', '_', f"{v.pattern_name}_{v.line_number}")
            finding_path = os.path.join(findings_dir, f'{safe_name}.md')
            with open(finding_path, 'w') as f:
                f.write(v.to_markdown())


class SASTScanner:
    """Multi-language SAST scanner"""
    
    def __init__(self, config: dict = None):
        self.config = config or {}
        self.context_lines = self.config.get('context_lines', 3)
        self.max_file_size = self.config.get('max_file_size', 10 * 1024 * 1024)  # 10MB
        self.exclude_patterns = self.config.get('exclude_patterns', [
            r'\.git/', r'node_modules/', r'vendor/', r'\.venv/',
            r'__pycache__/', r'\.idea/', r'\.vscode/',
            r'\.min\.js$', r'\.min\.css$',
        ])
        self.include_languages = self.config.get('include_languages', list(ALL_PATTERNS.keys()))
        self._compiled_patterns = {}
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Pre-compile all regex patterns for performance"""
        for lang in self.include_languages:
            lang_data = get_patterns(lang)
            patterns = lang_data.get('patterns', [])
            self._compiled_patterns[lang] = []
            for p in patterns:
                try:
                    compiled = re.compile(p['pattern'], re.IGNORECASE | re.MULTILINE)
                    self._compiled_patterns[lang].append({
                        'compiled': compiled,
                        'meta': p,
                    })
                except re.error as e:
                    print(f"[!] Failed to compile pattern {p['id']}: {e}")
    
    def _should_exclude(self, path: str) -> bool:
        """Check if path should be excluded"""
        for pattern in self.exclude_patterns:
            if re.search(pattern, path):
                return True
        return False
    
    def _detect_language(self, file_path: str) -> Optional[str]:
        """Detect language from file extension"""
        ext = os.path.splitext(file_path)[1].lower()
        return get_language_by_extension(ext)
    
    def _iter_files(self, target_path: str) -> Iterator[str]:
        """Iterate through scannable files"""
        target = Path(target_path)
        
        if target.is_file():
            yield str(target)
            return
        
        for root, dirs, files in os.walk(target):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if not self._should_exclude(os.path.join(root, d))]
            
            for fname in files:
                fpath = os.path.join(root, fname)
                if not self._should_exclude(fpath):
                    yield fpath
    
    def _get_context(self, lines: List[str], line_idx: int) -> tuple:
        """Get context lines around a match"""
        start = max(0, line_idx - self.context_lines)
        end = min(len(lines), line_idx + self.context_lines + 1)
        
        context_before = lines[start:line_idx]
        context_after = lines[line_idx + 1:end]
        
        return context_before, context_after
    
    def _scan_file(self, file_path: str) -> List[VulnerabilityMatch]:
        """Scan a single file"""
        matches = []
        
        # Detect language
        language = self._detect_language(file_path)
        if not language or language not in self._compiled_patterns:
            return matches
        
        # Read file
        try:
            stat = os.stat(file_path)
            if stat.st_size > self.max_file_size:
                return matches
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.split('\n')
        except Exception as e:
            return matches
        
        # Scan with each pattern
        for pattern_data in self._compiled_patterns[language]:
            compiled = pattern_data['compiled']
            meta = pattern_data['meta']
            
            for match in compiled.finditer(content):
                # Find line number
                line_start = content[:match.start()].count('\n')
                line_content = lines[line_start] if line_start < len(lines) else ''
                
                # Get context
                ctx_before, ctx_after = self._get_context(lines, line_start)
                
                # Create match object
                vuln = VulnerabilityMatch(
                    id=hashlib.md5(f"{file_path}:{line_start}:{meta['id']}".encode()).hexdigest()[:12],
                    pattern_id=meta['id'],
                    pattern_name=meta['name'],
                    category=meta['category'],
                    severity=meta['severity'],
                    file_path=file_path,
                    line_number=line_start + 1,
                    line_content=line_content.strip(),
                    context_before=ctx_before,
                    context_after=ctx_after,
                    description=meta.get('description', ''),
                    exploit=meta.get('exploit', ''),
                    cwe=meta.get('cwe', ''),
                    language=language,
                )
                matches.append(vuln)
        
        return matches
    
    def scan(self, target_path: str, workers: int = 4) -> ScanResult:
        """Scan target path for vulnerabilities"""
        start_time = datetime.now()
        
        # Collect files
        files = list(self._iter_files(target_path))
        total_files = len(files)
        
        # Scan files
        all_matches = []
        errors = []
        files_scanned = 0
        
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_file = {executor.submit(self._scan_file, f): f for f in files}
            
            for future in as_completed(future_to_file):
                fpath = future_to_file[future]
                try:
                    matches = future.result()
                    all_matches.extend(matches)
                    files_scanned += 1
                except Exception as e:
                    errors.append(f"Error scanning {fpath}: {str(e)}")
        
        # Calculate stats
        stats = self._calculate_stats(all_matches)
        stats['scan_duration'] = (datetime.now() - start_time).total_seconds()
        
        # Create result
        result = ScanResult(
            target_path=target_path,
            scan_timestamp=start_time.isoformat(),
            total_files=total_files,
            files_scanned=files_scanned,
            vulnerabilities=all_matches,
            errors=errors,
            stats=stats,
        )
        
        return result
    
    def _calculate_stats(self, matches: List[VulnerabilityMatch]) -> dict:
        """Calculate scan statistics"""
        stats = {
            'total': len(matches),
            'by_severity': {},
            'by_category': {},
            'by_language': {},
            'by_cwe': {},
        }
        
        for m in matches:
            # By severity
            sev = m.severity.lower()
            stats['by_severity'][sev] = stats['by_severity'].get(sev, 0) + 1
            
            # By category
            cat = m.category
            stats['by_category'][cat] = stats['by_category'].get(cat, 0) + 1
            
            # By language
            lang = m.language
            stats['by_language'][lang] = stats['by_language'].get(lang, 0) + 1
            
            # By CWE
            cwe = m.cwe
            if cwe:
                stats['by_cwe'][cwe] = stats['by_cwe'].get(cwe, 0) + 1
        
        return stats
    
    def quick_scan(self, target_path: str, severity_filter: str = None) -> List[VulnerabilityMatch]:
        """Quick scan with optional severity filter"""
        result = self.scan(target_path)
        
        if severity_filter:
            return [v for v in result.vulnerabilities if v.severity.lower() == severity_filter.lower()]
        
        return result.vulnerabilities


# CLI interface
if __name__ == '__main__':
    import sys
    import argparse
    
    parser = argparse.ArgumentParser(description='BrainX SAST Scanner')
    parser.add_argument('target', help='Target path to scan')
    parser.add_argument('-o', '--output', help='Output JSON file')
    parser.add_argument('-m', '--markdown', help='Output Obsidian markdown directory')
    parser.add_argument('-w', '--workers', type=int, default=4, help='Number of workers')
    parser.add_argument('-s', '--severity', choices=['critical', 'high', 'medium', 'low'],
                        help='Filter by severity')
    
    args = parser.parse_args()
    
    scanner = SASTScanner()
    result = scanner.scan(args.target, workers=args.workers)
    
    # Filter by severity if requested
    if args.severity:
        result.vulnerabilities = [v for v in result.vulnerabilities 
                                   if v.severity.lower() == args.severity]
    
    # Output results
    print(f"\n{'='*60}")
    print(f"BrainX SAST Scan Results")
    print(f"{'='*60}")
    print(f"Target: {result.target_path}")
    print(f"Files scanned: {result.files_scanned}/{result.total_files}")
    print(f"Vulnerabilities: {len(result.vulnerabilities)}")
    print(f"Duration: {result.stats.get('scan_duration', 0):.2f}s")
    print(f"\nBy Severity:")
    for sev in ['critical', 'high', 'medium', 'low']:
        count = result.stats.get('by_severity', {}).get(sev, 0)
        print(f"  {sev.upper()}: {count}")
    
    if args.output:
        result.save_json(args.output)
        print(f"\nJSON saved to: {args.output}")
    
    if args.markdown:
        result.save_obsidian(args.markdown, project_name=os.path.basename(args.target))
        print(f"Markdown saved to: {args.markdown}")
