#!/usr/bin/env python3
"""
⛓️ CHAIN VALIDATOR - Valida exploitability das chains encontradas
══════════════════════════════════════════════════════════════════
Target: gitlab.haufedev.systems
Objetivo: Verificar se as CVEs nas dependências do DOMPurify são exploráveis
"""

import json
import requests
from pathlib import Path
from datetime import datetime

OUTPUT = Path("/home/l3ster/research/brainx/output/deep_dissect")
TARGET = "https://gitlab.haufedev.systems"

# CVE Details and exploitation requirements
CVE_ANALYSIS = {
    # jQuery CVEs - XSS via HTML manipulation
    "CVE-2020-11022": {
        "package": "jquery",
        "affected": "<3.5.0",
        "type": "XSS",
        "vector": "HTML passed to jQuery DOM manipulation methods",
        "requirement": "jQuery must be loaded AND accept user-controlled HTML",
        "gitlab_check": "GitLab uses jQuery but sanitizes via DOMPurify BEFORE jQuery",
        "exploitable": "UNLIKELY",
        "reason": "DOMPurify sanitizes input BEFORE jQuery processes it"
    },
    "CVE-2020-11023": {
        "package": "jquery",
        "affected": "<3.5.0",
        "type": "XSS",
        "vector": "HTML containing <option> in jQuery.htmlPrefilter",
        "requirement": "Must pass HTML with <option> tags to jQuery",
        "gitlab_check": "Same as CVE-2020-11022",
        "exploitable": "UNLIKELY",
        "reason": "DOMPurify sanitizes before jQuery receives HTML"
    },
    "CVE-2019-11358": {
        "package": "jquery",
        "affected": "<3.4.0",
        "type": "Prototype Pollution",
        "vector": "jQuery.extend(true, {}, ...) with __proto__",
        "requirement": "Must control object passed to jQuery.extend deep merge",
        "gitlab_check": "GitLab doesn't expose $.extend to user input directly",
        "exploitable": "UNLIKELY",
        "reason": "No direct path from user input to $.extend"
    },
    
    # Lodash CVEs - Prototype Pollution (devDependency only)
    "CVE-2019-10744": {
        "package": "lodash",
        "affected": "<4.17.12",
        "type": "Prototype Pollution",
        "vector": "_.defaultsDeep with __proto__",
        "requirement": "Control object passed to defaultsDeep",
        "gitlab_check": "Lodash is DEV dependency - not in production bundle",
        "exploitable": "NOT_APPLICABLE",
        "reason": "DEV dependency only - not shipped to production"
    },
    "CVE-2020-8203": {
        "package": "lodash",
        "affected": "<4.17.19",
        "type": "Prototype Pollution",
        "vector": "_.zipObjectDeep with crafted array",
        "requirement": "Control arrays passed to zipObjectDeep",
        "gitlab_check": "DEV dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "DEV dependency only"
    },
    "CVE-2021-23337": {
        "package": "lodash",
        "affected": "<4.17.21",
        "type": "Command Injection",
        "vector": "_.template with crafted options",
        "requirement": "Control template options",
        "gitlab_check": "DEV dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "DEV dependency only"
    },
    
    # Minimist CVEs - Prototype Pollution (DEV only)
    "CVE-2020-7598": {
        "package": "minimist",
        "affected": "<0.2.1 || >=1.0.0 <1.2.3",
        "type": "Prototype Pollution",
        "vector": "--__proto__.x=y in CLI args",
        "requirement": "Control CLI arguments",
        "gitlab_check": "CLI tool - not exposed to web",
        "exploitable": "NOT_APPLICABLE",
        "reason": "Server-side CLI parsing only"
    },
    "CVE-2021-44906": {
        "package": "minimist",
        "affected": "<1.2.6",
        "type": "Prototype Pollution",
        "vector": "constructor.prototype pollution",
        "requirement": "Control CLI arguments",
        "gitlab_check": "CLI tool - not exposed to web",
        "exploitable": "NOT_APPLICABLE",
        "reason": "Server-side CLI parsing only"
    },
    
    # jsdom CVE (DEV only)
    "CVE-2021-20066": {
        "package": "jsdom",
        "affected": "<16.5.0",
        "type": "Stored XSS",
        "vector": "Script execution in jsdom environment",
        "requirement": "Control HTML passed to jsdom",
        "gitlab_check": "jsdom is DEV/test dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "TEST dependency - not in production"
    },
    
    # semver (build tool only)
    "CVE-2022-25883": {
        "package": "semver",
        "affected": "<5.7.2, 6.0.0-6.3.0, 7.0.0-7.5.1",
        "type": "ReDoS",
        "vector": "Crafted version string",
        "requirement": "Control version string input",
        "gitlab_check": "Build tool dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "Build-time dependency only"
    },
    
    # tough-cookie
    "CVE-2023-26136": {
        "package": "tough-cookie",
        "affected": "<4.1.3",
        "type": "Prototype Pollution",
        "vector": "Cookie parsing",
        "requirement": "Control cookie values",
        "gitlab_check": "jsdom dependency - test only",
        "exploitable": "NOT_APPLICABLE",
        "reason": "TEST dependency chain"
    },
    
    # ws WebSocket
    "CVE-2021-32640": {
        "package": "ws",
        "affected": "<5.2.3, 6.x<6.2.2, 7.x<7.4.6",
        "type": "ReDoS",
        "vector": "Crafted Sec-WebSocket-Protocol header",
        "requirement": "Control WebSocket headers",
        "gitlab_check": "Test/dev dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "TEST dependency"
    },
    
    # Additional found
    "CVE-2020-7774": {
        "package": "y18n",
        "affected": "<3.2.2, 4.x<4.0.1, 5.x<5.0.5",
        "type": "Prototype Pollution",
        "vector": "y18n().setLocale",
        "requirement": "Control locale setting",
        "gitlab_check": "CLI dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "Build tool dependency"
    },
    "CVE-2020-7608": {
        "package": "yargs-parser",
        "affected": "<5.0.1, 6.x-12.x<13.1.2, 14.x-17.x<18.1.1",
        "type": "Prototype Pollution",
        "vector": "CLI argument parsing",
        "requirement": "Control CLI args",
        "gitlab_check": "CLI dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "Build tool dependency"
    },
    "CVE-2021-3807": {
        "package": "ansi-regex",
        "affected": ">2.1.1 <5.0.1, >=6.0.0 <6.0.1",
        "type": "ReDoS",
        "vector": "Crafted ANSI escape sequences",
        "requirement": "Control string with ANSI codes",
        "gitlab_check": "CLI/terminal dependency",
        "exploitable": "NOT_APPLICABLE",
        "reason": "CLI/build dependency"
    },
    "CVE-2022-24999": {
        "package": "qs",
        "affected": "<6.10.3, 6.11.x<6.11.0",
        "type": "Prototype Pollution",
        "vector": "Crafted query string",
        "requirement": "Control query string parsing",
        "gitlab_check": "karma dependency - test only",
        "exploitable": "NOT_APPLICABLE",
        "reason": "TEST dependency"
    }
}


def check_gitlab_frontend():
    """Check what's actually loaded in GitLab frontend"""
    print("\n" + "="*80)
    print("🔍 CHECKING GITLAB FRONTEND DEPENDENCIES")
    print("="*80)
    
    # Check swagger bundle
    try:
        r = requests.get(f"{TARGET}/-/swagger_ui/swagger-ui-bundle.js", timeout=30)
        if r.ok:
            content = r.text[:50000]
            checks = {
                "jQuery": "jquery" in content.lower() or "jQuery" in content,
                "lodash": "lodash" in content.lower() or "_.debounce" in content,
                "minimist": "minimist" in content,
                "jsdom": "jsdom" in content,
            }
            print("\n  Swagger Bundle Analysis:")
            for lib, found in checks.items():
                status = "✅ FOUND" if found else "❌ NOT FOUND"
                print(f"    {lib}: {status}")
    except Exception as e:
        print(f"  ⚠️ Error checking swagger: {e}")
    
    # Check main GitLab assets
    try:
        r = requests.get(f"{TARGET}/users/sign_in", timeout=30)
        if r.ok:
            # Look for script tags
            import re
            scripts = re.findall(r'src="([^"]+\.js[^"]*)"', r.text)
            print(f"\n  Found {len(scripts)} script tags in sign_in page")
    except Exception as e:
        print(f"  ⚠️ Error: {e}")


def validate_chains():
    """Validate each chain's exploitability"""
    print("\n" + "="*80)
    print("⛓️ CHAIN VALIDATION RESULTS")
    print("="*80)
    
    # Load chains
    report_file = OUTPUT / "deep_dissect_report.json"
    if not report_file.exists():
        print("  ❌ No report found. Run brutal_deep_dissector.py first.")
        return
    
    with open(report_file) as f:
        report = json.load(f)
    
    chains = report.get("chains", [])
    
    results = {
        "EXPLOITABLE": [],
        "UNLIKELY": [],
        "NOT_APPLICABLE": [],
        "UNKNOWN": []
    }
    
    for chain in chains:
        cve = chain.get("cve", "")
        if cve in CVE_ANALYSIS:
            analysis = CVE_ANALYSIS[cve]
            status = analysis["exploitable"]
            results[status].append({
                "cve": cve,
                "chain": chain["path"],
                "reason": analysis["reason"],
                "type": analysis["type"]
            })
        else:
            results["UNKNOWN"].append({
                "cve": cve,
                "chain": chain["path"],
                "reason": "No analysis available",
                "type": chain.get("type", "unknown")
            })
    
    # Print results
    print("\n  🔴 POTENTIALLY EXPLOITABLE:")
    if results["EXPLOITABLE"]:
        for item in results["EXPLOITABLE"]:
            print(f"      {item['cve']}: {' → '.join(item['chain'])}")
            print(f"         Type: {item['type']}")
    else:
        print("      None found")
    
    print("\n  🟡 UNLIKELY (defenses in place):")
    for item in results["UNLIKELY"]:
        print(f"      {item['cve']}: {item['reason']}")
    
    print("\n  ⚪ NOT APPLICABLE (dev/build dependencies):")
    for item in results["NOT_APPLICABLE"]:
        print(f"      {item['cve']}: {item['reason']}")
    
    # Save validation report
    validation = {
        "timestamp": datetime.now().isoformat(),
        "target": TARGET,
        "summary": {
            "exploitable": len(results["EXPLOITABLE"]),
            "unlikely": len(results["UNLIKELY"]),
            "not_applicable": len(results["NOT_APPLICABLE"]),
            "unknown": len(results["UNKNOWN"])
        },
        "results": results
    }
    
    val_file = OUTPUT / "chain_validation.json"
    with open(val_file, 'w') as f:
        json.dump(validation, f, indent=2)
    
    print(f"\n  📄 Validation saved: {val_file}")
    return validation


def generate_final_assessment():
    """Generate final exploitability assessment"""
    print("\n" + "="*80)
    print("📋 FINAL EXPLOITABILITY ASSESSMENT")
    print("="*80)
    
    print("""
  TARGET: gitlab.haufedev.systems (GitLab EE 18.8.2)
  
  DOMPURIFY DEPENDENCY CHAIN ANALYSIS:
  ════════════════════════════════════
  
  The deep dissector found 331 dependencies with 17 potential chains.
  
  VERDICT: 🟡 NO DIRECTLY EXPLOITABLE CHAINS FOUND
  
  REASONS:
  ─────────────────────────────────────────────────────────────────────
  1. jQuery CVEs (CVE-2020-11022/23, CVE-2019-11358):
     → DOMPurify sanitizes HTML BEFORE jQuery processes it
     → No path to inject malicious HTML that bypasses DOMPurify
  
  2. Lodash/Minimist/jsdom CVEs:
     → These are DEV/TEST dependencies only
     → NOT included in production GitLab frontend bundle
     → Only affect build/test environments
  
  3. semver/yargs/ansi-regex CVEs:
     → Build tool dependencies
     → No exposure to web frontend
  
  ALTERNATIVE ATTACK VECTORS TO INVESTIGATE:
  ─────────────────────────────────────────────────────────────────────
  1. GraphQL Mutations (330 found - introspection enabled)
     → BOLA/IDOR via mutations
     → Mass assignment via mutation inputs
  
  2. Metrics Endpoint
     → Version disclosure: 18.8.2-ee
     → Internal service information
  
  3. Server-Side vulnerabilities
     → GitLab Rails application bugs
     → CVE search for GitLab 18.8.2
  
  4. CI/CD Pipeline abuse
     → Runner token theft
     → Secret extraction
    """)


def main():
    print("""
╔════════════════════════════════════════════════════════════════════════════╗
║  ⛓️ CHAIN VALIDATOR - Exploitability Analysis                              ║
║  Target: gitlab.haufedev.systems                                           ║
╚════════════════════════════════════════════════════════════════════════════╝
    """)
    
    check_gitlab_frontend()
    validate_chains()
    generate_final_assessment()


if __name__ == "__main__":
    main()
