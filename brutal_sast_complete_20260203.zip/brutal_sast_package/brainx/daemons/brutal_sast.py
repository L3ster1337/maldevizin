#!/usr/bin/env python3
"""
BrutalHunter SAST Daemon - Deep JS/TS Security Analysis
Specifically tuned for sanitizer libraries like DOMPurify

Hunts for:
- XSS bypass patterns
- Regex ReDoS vulnerabilities
- Prototype pollution
- DOM clobbering vectors
- mXSS (mutation XSS) patterns
- Parser differential bugs
- Bypass gadgets
"""

import os
import re
import json
import hashlib
import asyncio
import logging
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional, Any, Tuple
from collections import defaultdict

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(name)s | %(levelname)s | %(message)s'
)
log = logging.getLogger("BrutalSAST")

@dataclass
class Finding:
    id: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW, INFO
    category: str
    title: str
    file: str
    line: int
    code_snippet: str
    description: str
    cwe: Optional[str] = None
    confidence: float = 0.8
    confirmed: bool = False
    exploit_hint: Optional[str] = None

@dataclass
class ScanStats:
    files_scanned: int = 0
    lines_analyzed: int = 0
    findings_count: int = 0
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

# ═══════════════════════════════════════════════════════════════
# VULNERABILITY PATTERNS - Sanitizer/XSS Focus
# ═══════════════════════════════════════════════════════════════

VULN_PATTERNS = {
    # ───────────────────────────────────────────────────────────
    # XSS BYPASS VECTORS
    # ───────────────────────────────────────────────────────────
    "xss_innerhtml_assignment": {
        "pattern": r"\.innerHTML\s*=(?!=)",
        "severity": "HIGH",
        "category": "XSS",
        "cwe": "CWE-79",
        "description": "Direct innerHTML assignment - potential XSS sink",
        "exploit_hint": "Test with: <img src=x onerror=alert(1)>"
    },
    "xss_outerhtml_assignment": {
        "pattern": r"\.outerHTML\s*=(?!=)",
        "severity": "HIGH", 
        "category": "XSS",
        "cwe": "CWE-79",
        "description": "Direct outerHTML assignment - potential XSS sink"
    },
    "xss_document_write": {
        "pattern": r"document\.write\s*\(",
        "severity": "HIGH",
        "category": "XSS",
        "cwe": "CWE-79",
        "description": "document.write usage - classic XSS vector"
    },
    "xss_insertadjacenthtml": {
        "pattern": r"\.insertAdjacentHTML\s*\(",
        "severity": "MEDIUM",
        "category": "XSS",
        "cwe": "CWE-79",
        "description": "insertAdjacentHTML usage - potential XSS"
    },
    
    # ───────────────────────────────────────────────────────────
    # mXSS (Mutation XSS) Patterns
    # ───────────────────────────────────────────────────────────
    "mxss_namespace_confusion": {
        "pattern": r"(createElementNS|setAttributeNS)\s*\([^)]*['\"]http",
        "severity": "HIGH",
        "category": "mXSS",
        "cwe": "CWE-79",
        "description": "Namespace manipulation - potential mXSS via SVG/MathML",
        "exploit_hint": "Test SVG/MathML namespace switches"
    },
    "mxss_template_element": {
        "pattern": r"['\"]template['\"]|<template|\.content\b",
        "severity": "MEDIUM",
        "category": "mXSS",
        "description": "Template element handling - check for mXSS via template"
    },
    "mxss_noscript_handling": {
        "pattern": r"['\"]noscript['\"]|<noscript",
        "severity": "MEDIUM",
        "category": "mXSS", 
        "description": "noscript element - parser differential mXSS vector"
    },
    "mxss_svg_foreignobject": {
        "pattern": r"foreignObject|foreignobject",
        "severity": "HIGH",
        "category": "mXSS",
        "description": "SVG foreignObject - namespace escape mXSS"
    },
    "mxss_math_annotation": {
        "pattern": r"annotation-xml|math:annotation",
        "severity": "HIGH",
        "category": "mXSS",
        "description": "MathML annotation-xml - integration point mXSS"
    },
    
    # ───────────────────────────────────────────────────────────
    # REGEX ReDoS
    # ───────────────────────────────────────────────────────────
    "redos_nested_quantifier": {
        "pattern": r"(?:\/[^\/]+\/|\bRegExp\s*\([^)]+\))[^;]*[+*]\s*[+*?]",
        "severity": "HIGH",
        "category": "ReDoS",
        "cwe": "CWE-1333",
        "description": "Nested quantifiers in regex - potential ReDoS",
        "exploit_hint": "Craft input with repeated pattern to trigger exponential backtracking"
    },
    "redos_alternation_overlap": {
        "pattern": r"\/[^\/]*\([^)]*\|[^)]*\)[^\/]*[+*][^\/]*\/",
        "severity": "MEDIUM",
        "category": "ReDoS",
        "cwe": "CWE-1333",
        "description": "Alternation with quantifier - check for overlapping patterns"
    },
    "redos_backreference": {
        "pattern": r"\/[^\/]*\\[1-9][^\/]*[+*][^\/]*\/",
        "severity": "MEDIUM",
        "category": "ReDoS",
        "description": "Backreference with quantifier - potential ReDoS"
    },
    
    # ───────────────────────────────────────────────────────────
    # PROTOTYPE POLLUTION
    # ───────────────────────────────────────────────────────────
    "proto_pollution_proto": {
        "pattern": r"__proto__|prototype\s*\[|Object\.setPrototypeOf",
        "severity": "CRITICAL",
        "category": "Prototype Pollution",
        "cwe": "CWE-1321",
        "description": "__proto__ or prototype manipulation",
        "exploit_hint": "Try: {\"__proto__\": {\"polluted\": true}}"
    },
    "proto_pollution_constructor": {
        "pattern": r"constructor\s*\[\s*['\"]prototype",
        "severity": "CRITICAL",
        "category": "Prototype Pollution",
        "cwe": "CWE-1321",
        "description": "constructor.prototype access pattern"
    },
    "proto_pollution_merge": {
        "pattern": r"(Object\.assign|\.extend|merge|deepMerge|deepCopy)\s*\(",
        "severity": "MEDIUM",
        "category": "Prototype Pollution",
        "description": "Object merge function - check for prototype pollution"
    },
    
    # ───────────────────────────────────────────────────────────
    # DOM CLOBBERING
    # ───────────────────────────────────────────────────────────
    "dom_clobber_id_access": {
        "pattern": r"window\s*\[\s*['\"][^'\"]+['\"]\s*\]|document\s*\[\s*['\"]",
        "severity": "MEDIUM",
        "category": "DOM Clobbering",
        "cwe": "CWE-79",
        "description": "Dynamic window/document property access - clobbering risk"
    },
    "dom_clobber_form_elements": {
        "pattern": r"\.elements\s*\[|form\s*\.\s*[a-zA-Z]",
        "severity": "LOW",
        "category": "DOM Clobbering",
        "description": "Form elements access - potential clobbering"
    },
    
    # ───────────────────────────────────────────────────────────
    # SANITIZER BYPASS PATTERNS
    # ───────────────────────────────────────────────────────────
    "bypass_event_handler": {
        "pattern": r"on[a-z]+\s*=|['\"]on[a-z]+['\"]",
        "severity": "INFO",
        "category": "Event Handler",
        "description": "Event handler pattern - verify sanitization"
    },
    "bypass_javascript_uri": {
        "pattern": r"javascript\s*:|data\s*:|vbscript\s*:",
        "severity": "MEDIUM",
        "category": "URI Scheme",
        "description": "Dangerous URI scheme handling"
    },
    "bypass_svg_script": {
        "pattern": r"<svg[^>]*>|<\/svg>|xlink:href",
        "severity": "MEDIUM",
        "category": "SVG",
        "description": "SVG element handling - check script execution"
    },
    "bypass_math_element": {
        "pattern": r"<math[^>]*>|<\/math>",
        "severity": "MEDIUM",
        "category": "MathML",
        "description": "MathML element - namespace escape vector"
    },
    
    # ───────────────────────────────────────────────────────────
    # ENCODING/PARSING
    # ───────────────────────────────────────────────────────────
    "encoding_entity_decode": {
        "pattern": r"&[a-zA-Z]+;|&#x?[0-9a-fA-F]+;",
        "severity": "INFO",
        "category": "Encoding",
        "description": "HTML entity handling - check double encoding"
    },
    "encoding_unicode_normalization": {
        "pattern": r"normalize\s*\(|String\.fromCharCode|fromCodePoint",
        "severity": "LOW",
        "category": "Encoding",
        "description": "Unicode handling - check normalization bypass"
    },
    "parser_createcontextualfragment": {
        "pattern": r"createContextualFragment\s*\(",
        "severity": "HIGH",
        "category": "Parser",
        "description": "createContextualFragment - context-dependent parsing"
    },
    
    # ───────────────────────────────────────────────────────────
    # DANGEROUS FUNCTIONS
    # ───────────────────────────────────────────────────────────
    "dangerous_eval": {
        "pattern": r"\beval\s*\(|Function\s*\(|setTimeout\s*\([^,)]*['\"]|setInterval\s*\([^,)]*['\"]",
        "severity": "CRITICAL",
        "category": "Code Injection",
        "cwe": "CWE-94",
        "description": "Dynamic code execution"
    },
    "dangerous_new_function": {
        "pattern": r"new\s+Function\s*\(",
        "severity": "CRITICAL",
        "category": "Code Injection",
        "cwe": "CWE-94",
        "description": "new Function() - dynamic code execution"
    },
    
    # ───────────────────────────────────────────────────────────
    # ALLOWLIST/BLOCKLIST ISSUES
    # ───────────────────────────────────────────────────────────
    "allowlist_incomplete": {
        "pattern": r"(allowed|whitelist|safe)\s*[=:]\s*\[",
        "severity": "INFO",
        "category": "Configuration",
        "description": "Allowlist definition - verify completeness"
    },
    "blocklist_bypass": {
        "pattern": r"(blocked|blacklist|forbidden|dangerous)\s*[=:]\s*\[",
        "severity": "INFO",
        "category": "Configuration", 
        "description": "Blocklist definition - blocklists are bypassable"
    },
    
    # ───────────────────────────────────────────────────────────
    # TYPE CONFUSION
    # ───────────────────────────────────────────────────────────
    "type_confusion_typeof": {
        "pattern": r"typeof\s+[^=!]+\s*[!=]=\s*['\"](?:string|object|function)",
        "severity": "LOW",
        "category": "Type Confusion",
        "description": "Type checking - verify null/undefined handling"
    },
    "type_confusion_instanceof": {
        "pattern": r"instanceof\s+(?:Array|Object|String|Element)",
        "severity": "LOW",
        "category": "Type Confusion",
        "description": "instanceof check - cross-realm bypass possible"
    },
}

# Additional patterns for DOMPurify-specific analysis
DOMPURIFY_SPECIFIC = {
    "config_allow_unknown_protocols": {
        "pattern": r"ALLOW_UNKNOWN_PROTOCOLS|allowUnknownProtocols",
        "severity": "HIGH",
        "category": "Configuration",
        "description": "ALLOW_UNKNOWN_PROTOCOLS - dangerous config option"
    },
    "config_return_dom": {
        "pattern": r"RETURN_DOM|returnDom",
        "severity": "MEDIUM",
        "category": "Configuration",
        "description": "RETURN_DOM mode - verify DOM handling"
    },
    "config_in_place": {
        "pattern": r"IN_PLACE|inPlace",
        "severity": "MEDIUM",
        "category": "Configuration",
        "description": "IN_PLACE mode - mutates original DOM"
    },
    "config_trusted_types": {
        "pattern": r"TRUSTED_TYPES|trustedTypes",
        "severity": "INFO",
        "category": "Configuration",
        "description": "Trusted Types integration"
    },
    "hook_registration": {
        "pattern": r"addHook\s*\(|removeHook\s*\(",
        "severity": "INFO",
        "category": "Hooks",
        "description": "Hook registration - custom processing"
    },
    "sanitize_call": {
        "pattern": r"DOMPurify\.sanitize\s*\(|sanitize\s*\(",
        "severity": "INFO",
        "category": "Sanitization",
        "description": "Sanitize function call"
    },
}


class BrutalSASTDaemon:
    def __init__(self, target_path: str, output_dir: Optional[str] = None):
        self.target_path = Path(target_path).resolve()
        self.session_id = hashlib.md5(f"{target_path}{datetime.now().isoformat()}".encode()).hexdigest()[:12]
        self.output_dir = Path(output_dir or f"~/.brainx/sast/{self.session_id}").expanduser()
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.findings: List[Finding] = []
        self.stats = ScanStats()
        self.file_cache: Dict[str, str] = {}
        
        # Compile patterns
        self.patterns: Dict[str, Dict] = {}
        for name, config in {**VULN_PATTERNS, **DOMPURIFY_SPECIFIC}.items():
            try:
                self.patterns[name] = {
                    **config,
                    "compiled": re.compile(config["pattern"], re.IGNORECASE | re.MULTILINE)
                }
            except re.error as e:
                log.warning(f"Failed to compile pattern {name}: {e}")
                
        log.info(f"Loaded {len(self.patterns)} vulnerability patterns")
        
    def scan(self) -> Dict[str, Any]:
        """Main scan method"""
        self.stats.start_time = datetime.now()
        
        log.info("=" * 70)
        log.info("💀 BRUTALHUNTER SAST DAEMON")
        log.info("=" * 70)
        log.info(f"Target: {self.target_path}")
        log.info(f"Session: {self.session_id}")
        log.info(f"Output: {self.output_dir}")
        log.info("")
        
        # Phase 1: Discover files
        files = self._discover_files()
        log.info(f"[PHASE 1] Discovered {len(files)} source files")
        
        # Phase 2: Pattern scanning
        log.info("[PHASE 2] Running pattern analysis...")
        for file in files:
            self._scan_file(file)
            
        # Phase 3: Semantic analysis
        log.info("[PHASE 3] Running semantic analysis...")
        self._semantic_analysis()
        
        # Phase 4: Data flow analysis
        log.info("[PHASE 4] Running data flow analysis...")
        self._dataflow_analysis()
        
        # Phase 5: Generate report
        log.info("[PHASE 5] Generating report...")
        self.stats.end_time = datetime.now()
        
        return self._generate_report()
        
    def _discover_files(self) -> List[Path]:
        """Discover all source files"""
        extensions = {'.js', '.ts', '.mjs', '.jsx', '.tsx'}
        files = []
        
        for ext in extensions:
            files.extend(self.target_path.rglob(f"*{ext}"))
            
        # Filter out node_modules, dist, etc.
        files = [f for f in files if 
                 'node_modules' not in str(f) and
                 '.min.' not in f.name]
                 
        return files
        
    def _scan_file(self, file_path: Path):
        """Scan a single file for vulnerabilities"""
        try:
            content = file_path.read_text(errors='ignore')
            self.file_cache[str(file_path)] = content
            lines = content.split('\n')
            
            self.stats.files_scanned += 1
            self.stats.lines_analyzed += len(lines)
            
            relative_path = str(file_path.relative_to(self.target_path))
            
            for pattern_name, config in self.patterns.items():
                regex = config["compiled"]
                
                for match in regex.finditer(content):
                    # Find line number
                    line_num = content[:match.start()].count('\n') + 1
                    
                    # Get code snippet (3 lines context)
                    start_line = max(0, line_num - 2)
                    end_line = min(len(lines), line_num + 2)
                    snippet = '\n'.join(lines[start_line:end_line])
                    
                    finding = Finding(
                        id=f"SAST-{self.session_id}-{len(self.findings)+1:04d}",
                        severity=config["severity"],
                        category=config["category"],
                        title=pattern_name.replace("_", " ").title(),
                        file=relative_path,
                        line=line_num,
                        code_snippet=snippet,
                        description=config["description"],
                        cwe=config.get("cwe"),
                        exploit_hint=config.get("exploit_hint")
                    )
                    
                    self.findings.append(finding)
                    
        except Exception as e:
            log.warning(f"Error scanning {file_path}: {e}")
            
    def _semantic_analysis(self):
        """Deep semantic analysis for DOMPurify-specific issues"""
        
        # Find main purify.ts/js file
        purify_files = list(self.target_path.rglob("purify.ts")) + list(self.target_path.rglob("purify.js"))
        
        for pf in purify_files:
            if 'node_modules' in str(pf) or 'dist' in str(pf):
                continue
                
            content = pf.read_text(errors='ignore')
            
            # Check for dangerous default configurations
            if 'ALLOW_DATA_ATTR' in content and 'true' in content:
                log.warning("  ⚠ ALLOW_DATA_ATTR enabled by default")
                
            # Check for known bypass patterns in allowed tags
            if re.search(r'ALLOWED_TAGS.*\bstyle\b', content, re.IGNORECASE):
                self.findings.append(Finding(
                    id=f"SAST-{self.session_id}-SEM-001",
                    severity="MEDIUM",
                    category="Configuration",
                    title="Style Tag Allowed",
                    file=str(pf.relative_to(self.target_path)),
                    line=0,
                    code_snippet="ALLOWED_TAGS includes 'style'",
                    description="Style tags can be used for CSS injection and data exfiltration"
                ))
                
            # Check regex complexity
            self._analyze_regex_complexity(content, pf)
            
    def _analyze_regex_complexity(self, content: str, file_path: Path):
        """Analyze regex patterns for ReDoS vulnerabilities"""
        
        # Find all regex patterns
        regex_patterns = re.findall(r'(?:\/([^\/\n]+)\/[gimsuvy]*|new\s+RegExp\s*\([\'"]([^\'"]+)[\'"])', content)
        
        for pattern in regex_patterns:
            p = pattern[0] or pattern[1]
            if not p:
                continue
                
            # Check for dangerous patterns
            issues = []
            
            # Nested quantifiers: (a+)+ or (a*)*
            if re.search(r'\([^)]*[+*]\)[+*?]', p):
                issues.append("Nested quantifiers")
                
            # Overlapping alternation with quantifier
            if re.search(r'\([^)]*\|[^)]*\)[+*]', p):
                issues.append("Alternation with quantifier")
                
            # Long chains of optional groups
            if p.count('?') > 5:
                issues.append("Many optional groups")
                
            if issues:
                self.findings.append(Finding(
                    id=f"SAST-{self.session_id}-REDOS-{len([f for f in self.findings if 'REDOS' in f.id])+1:03d}",
                    severity="HIGH" if "Nested" in str(issues) else "MEDIUM",
                    category="ReDoS",
                    title="Potentially Vulnerable Regex",
                    file=str(file_path.relative_to(self.target_path)),
                    line=0,
                    code_snippet=f"/{p}/",
                    description=f"Regex issues: {', '.join(issues)}",
                    cwe="CWE-1333",
                    exploit_hint="Craft input with repeated pattern to test exponential time"
                ))
                
    def _dataflow_analysis(self):
        """Simple data flow analysis to trace user input to sinks"""
        
        sinks = ['innerHTML', 'outerHTML', 'insertAdjacentHTML', 'document.write']
        sources = ['input', 'dirty', 'html', 'content', 'data']
        
        for file_path, content in self.file_cache.items():
            lines = content.split('\n')
            
            for i, line in enumerate(lines):
                # Check if line has a sink
                for sink in sinks:
                    if sink in line:
                        # Check if any source is in nearby lines
                        context = '\n'.join(lines[max(0, i-5):min(len(lines), i+5)])
                        for source in sources:
                            if source.lower() in context.lower():
                                # Potential tainted data flow
                                self.findings.append(Finding(
                                    id=f"SAST-{self.session_id}-FLOW-{len([f for f in self.findings if 'FLOW' in f.id])+1:03d}",
                                    severity="MEDIUM",
                                    category="Data Flow",
                                    title=f"Potential Tainted Flow: {source} → {sink}",
                                    file=Path(file_path).relative_to(self.target_path).as_posix(),
                                    line=i+1,
                                    code_snippet=line.strip(),
                                    description=f"User-controlled data ({source}) may flow to dangerous sink ({sink})"
                                ))
                                break
                                
    def _generate_report(self) -> Dict[str, Any]:
        """Generate final report"""
        
        # Deduplicate findings
        seen = set()
        unique_findings = []
        for f in self.findings:
            key = f"{f.file}:{f.line}:{f.category}"
            if key not in seen:
                seen.add(key)
                unique_findings.append(f)
        self.findings = unique_findings
        
        # Count by severity
        severity_counts = defaultdict(int)
        for f in self.findings:
            severity_counts[f.severity] += 1
            
        self.stats.findings_count = len(self.findings)
        
        # Print summary
        log.info("")
        log.info("=" * 70)
        log.info("📊 SAST ANALYSIS COMPLETE")
        log.info("=" * 70)
        log.info(f"Files scanned: {self.stats.files_scanned}")
        log.info(f"Lines analyzed: {self.stats.lines_analyzed:,}")
        log.info(f"Duration: {(self.stats.end_time - self.stats.start_time).total_seconds():.2f}s")
        log.info("")
        log.info(f"🔴 Critical: {severity_counts['CRITICAL']}")
        log.info(f"🟠 High: {severity_counts['HIGH']}")
        log.info(f"🟡 Medium: {severity_counts['MEDIUM']}")
        log.info(f"🔵 Low: {severity_counts['LOW']}")
        log.info(f"ℹ️  Info: {severity_counts['INFO']}")
        log.info("")
        
        # Show critical/high findings
        important = [f for f in self.findings if f.severity in ('CRITICAL', 'HIGH')]
        if important:
            log.info("🚨 IMPORTANT FINDINGS:")
            for f in important[:20]:
                log.info(f"   [{f.severity}] {f.title}")
                log.info(f"      {f.file}:{f.line}")
                log.info(f"      {f.description}")
                if f.exploit_hint:
                    log.info(f"      💡 {f.exploit_hint}")
                log.info("")
                
        # Generate report
        report = {
            "session_id": self.session_id,
            "target": str(self.target_path),
            "timestamp": datetime.now().isoformat(),
            "stats": {
                "files_scanned": self.stats.files_scanned,
                "lines_analyzed": self.stats.lines_analyzed,
                "duration_seconds": (self.stats.end_time - self.stats.start_time).total_seconds(),
            },
            "summary": dict(severity_counts),
            "findings": [
                {
                    "id": f.id,
                    "severity": f.severity,
                    "category": f.category,
                    "title": f.title,
                    "file": f.file,
                    "line": f.line,
                    "code_snippet": f.code_snippet,
                    "description": f.description,
                    "cwe": f.cwe,
                    "exploit_hint": f.exploit_hint,
                }
                for f in self.findings
            ]
        }
        
        # Save JSON
        with open(self.output_dir / "sast_report.json", 'w') as f:
            json.dump(report, f, indent=2)
            
        # Save Markdown
        md = self._generate_markdown(report)
        with open(self.output_dir / "SAST_REPORT.md", 'w') as f:
            f.write(md)
            
        log.info(f"📁 Reports saved: {self.output_dir}")
        
        return report
        
    def _generate_markdown(self, report: Dict) -> str:
        """Generate markdown report"""
        
        md = f"""# 💀 BrutalHunter SAST Report

**Target:** {report['target']}
**Date:** {report['timestamp']}
**Session:** {report['session_id']}

---

## 📊 Summary

| Metric | Value |
|--------|-------|
| Files Scanned | {report['stats']['files_scanned']} |
| Lines Analyzed | {report['stats']['lines_analyzed']:,} |
| Duration | {report['stats']['duration_seconds']:.2f}s |
| Total Findings | {len(report['findings'])} |

### Severity Distribution

| Severity | Count |
|----------|-------|
| 🔴 Critical | {report['summary'].get('CRITICAL', 0)} |
| 🟠 High | {report['summary'].get('HIGH', 0)} |
| 🟡 Medium | {report['summary'].get('MEDIUM', 0)} |
| 🔵 Low | {report['summary'].get('LOW', 0)} |
| ℹ️ Info | {report['summary'].get('INFO', 0)} |

---

## 🚨 Findings

"""
        # Group by severity
        for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']:
            findings = [f for f in report['findings'] if f['severity'] == severity]
            if not findings:
                continue
                
            emoji = {'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡', 'LOW': '🔵', 'INFO': 'ℹ️'}[severity]
            md += f"\n### {emoji} {severity} ({len(findings)})\n\n"
            
            for f in findings:
                cwe = f"[{f['cwe']}]" if f['cwe'] else ""
                md += f"""#### {f['title']} {cwe}

- **ID:** `{f['id']}`
- **Category:** {f['category']}
- **Location:** `{f['file']}:{f['line']}`
- **Description:** {f['description']}

```javascript
{f['code_snippet']}
```

"""
                if f['exploit_hint']:
                    md += f"> 💡 **Exploit Hint:** {f['exploit_hint']}\n\n"
                    
                md += "---\n\n"
                
        md += """
## 📋 Recommendations

1. Review all CRITICAL and HIGH severity findings immediately
2. Verify regex patterns for ReDoS vulnerabilities
3. Ensure proper sanitization of all user inputs
4. Test mXSS vectors with namespace switches
5. Validate allowlist/blocklist configurations

---

*Generated by BrutalHunter SAST Daemon*
"""
        return md


def main():
    import argparse
    parser = argparse.ArgumentParser(description="BrutalHunter SAST Daemon")
    parser.add_argument("target", help="Path to source code")
    parser.add_argument("--output", "-o", help="Output directory")
    parser.add_argument("--daemon", "-d", action="store_true", help="Run as daemon (continuous)")
    args = parser.parse_args()
    
    scanner = BrutalSASTDaemon(args.target, args.output)
    results = scanner.scan()
    
    # Print final stats
    critical = results['summary'].get('CRITICAL', 0)
    high = results['summary'].get('HIGH', 0)
    
    if critical > 0 or high > 0:
        print(f"\n🚨🚨🚨 {critical} CRITICAL, {high} HIGH FINDINGS - REVIEW REQUIRED 🚨🚨🚨\n")
        

if __name__ == "__main__":
    main()
