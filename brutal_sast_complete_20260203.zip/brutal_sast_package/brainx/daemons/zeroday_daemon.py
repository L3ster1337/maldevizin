#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║    ██████╗ ██████╗  █████╗ ██╗   ██╗    ██████╗  █████╗ ███████╗███╗   ███╗  ║
║   ██╔═████╗██╔══██╗██╔══██╗╚██╗ ██╔╝    ██╔══██╗██╔══██╗██╔════╝████╗ ████║  ║
║   ██║██╔██║██║  ██║███████║ ╚████╔╝     ██║  ██║███████║█████╗  ██╔████╔██║  ║
║   ████╔╝██║██║  ██║██╔══██║  ╚██╔╝      ██║  ██║██╔══██║██╔══╝  ██║╚██╔╝██║  ║
║   ╚██████╔╝██████╔╝██║  ██║   ██║       ██████╔╝██║  ██║███████╗██║ ╚═╝ ██║  ║
║    ╚═════╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝       ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝     ╚═╝  ║
║                                                                              ║
║                    0day Hunter Daemon - Runs While You Sleep                 ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

This daemon continuously analyzes source code for 0day vulnerabilities.
Runs indefinitely until:
  1. An exploitable vulnerability is found
  2. Manual stop
  3. Max iterations reached

Features:
  - Multiple SAST engines (Semgrep, CodeQL, custom rules)
  - AI-powered analysis for false positive filtering
  - Auto exploit generation
  - Real-time notifications

Usage:
  python zeroday_daemon.py start /path/to/source
  python zeroday_daemon.py stop
  python zeroday_daemon.py status
"""

import os
import sys
import json
import signal
import asyncio
import logging
import subprocess
import hashlib
from pathlib import Path
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Set
from enum import Enum
import time
import threading

sys.path.insert(0, str(Path(__file__).parent.parent))

from brain_core import BrainX, BrainTask, TaskType

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

DAEMON_NAME = "zeroday_hunter"
CONFIG_DIR = Path.home() / '.brainx'
DAEMON_DIR = CONFIG_DIR / 'daemons'
LOGS_DIR = CONFIG_DIR / 'logs'
RESULTS_DIR = CONFIG_DIR / 'results' / 'zeroday'

for d in [CONFIG_DIR, DAEMON_DIR, LOGS_DIR, RESULTS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

PID_FILE = DAEMON_DIR / 'zeroday.pid'
STATUS_FILE = DAEMON_DIR / 'zeroday.status'
TARGETS_FILE = DAEMON_DIR / 'zeroday_targets.json'

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | 0day | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / 'zeroday_daemon.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('0dayDaemon')


# ═══════════════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════════════

class VulnSeverity(Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


@dataclass
class VulnFinding:
    """A vulnerability finding"""
    id: str
    file: str
    line: int
    vuln_type: str
    severity: VulnSeverity
    code_snippet: str
    description: str
    engine: str
    exploitable: bool = False
    ai_analysis: str = ""
    poc_code: str = ""
    cve_potential: bool = False
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict:
        d = asdict(self)
        d['severity'] = self.severity.value
        return d


@dataclass
class DaemonStatus:
    """Daemon status"""
    running: bool = False
    pid: int = 0
    started: str = ""
    iterations: int = 0
    findings_count: int = 0
    last_scan: str = ""
    targets: List[str] = field(default_factory=list)
    current_target: str = ""


# ═══════════════════════════════════════════════════════════════════════════════
# SAST ENGINES
# ═══════════════════════════════════════════════════════════════════════════════

class SASTEngine:
    """Base SAST engine"""
    
    @staticmethod
    def run_semgrep(source_path: Path) -> List[VulnFinding]:
        """Run Semgrep SAST"""
        findings = []
        
        try:
            # Run with security rules
            result = subprocess.run(
                ['semgrep', 
                 '--config', 'p/security-audit',
                 '--config', 'p/owasp-top-ten', 
                 '--json',
                 str(source_path)],
                capture_output=True, text=True, timeout=600
            )
            
            if result.stdout:
                data = json.loads(result.stdout)
                
                for r in data.get('results', []):
                    severity_map = {
                        'ERROR': VulnSeverity.HIGH,
                        'WARNING': VulnSeverity.MEDIUM,
                        'INFO': VulnSeverity.LOW,
                    }
                    
                    finding = VulnFinding(
                        id=hashlib.md5(f"{r.get('path')}{r.get('start', {}).get('line')}{r.get('check_id')}".encode()).hexdigest()[:12],
                        file=r.get('path', ''),
                        line=r.get('start', {}).get('line', 0),
                        vuln_type=r.get('check_id', 'unknown'),
                        severity=severity_map.get(r.get('extra', {}).get('severity', 'INFO'), VulnSeverity.INFO),
                        code_snippet=r.get('extra', {}).get('lines', ''),
                        description=r.get('extra', {}).get('message', ''),
                        engine='semgrep'
                    )
                    findings.append(finding)
                    
        except Exception as e:
            logger.warning(f"Semgrep error: {e}")
        
        return findings
    
    @staticmethod
    def run_bandit(source_path: Path) -> List[VulnFinding]:
        """Run Bandit for Python"""
        findings = []
        
        try:
            result = subprocess.run(
                ['bandit', '-r', '-f', 'json', str(source_path)],
                capture_output=True, text=True, timeout=300
            )
            
            if result.stdout:
                data = json.loads(result.stdout)
                
                severity_map = {
                    'HIGH': VulnSeverity.HIGH,
                    'MEDIUM': VulnSeverity.MEDIUM,
                    'LOW': VulnSeverity.LOW,
                }
                
                for r in data.get('results', []):
                    finding = VulnFinding(
                        id=hashlib.md5(f"{r.get('filename')}{r.get('line_number')}{r.get('test_id')}".encode()).hexdigest()[:12],
                        file=r.get('filename', ''),
                        line=r.get('line_number', 0),
                        vuln_type=r.get('test_id', 'unknown'),
                        severity=severity_map.get(r.get('issue_severity', 'LOW'), VulnSeverity.LOW),
                        code_snippet=r.get('code', ''),
                        description=r.get('issue_text', ''),
                        engine='bandit'
                    )
                    findings.append(finding)
                    
        except Exception as e:
            logger.warning(f"Bandit error: {e}")
        
        return findings
    
    @staticmethod
    def run_custom_patterns(source_path: Path) -> List[VulnFinding]:
        """Run custom 0day hunting patterns"""
        findings = []
        
        # Dangerous patterns to search for
        patterns = [
            # SQL Injection
            (r'execute\s*\([^)]*%.*%', 'sql_injection', VulnSeverity.CRITICAL),
            (r'f"[^"]*\{[^}]*\}[^"]*(?:SELECT|INSERT|UPDATE|DELETE)', 'sql_injection', VulnSeverity.CRITICAL),
            
            # Command Injection
            (r'os\.system\s*\([^)]*\+', 'command_injection', VulnSeverity.CRITICAL),
            (r'subprocess\.(?:call|run|Popen)\s*\([^)]*shell\s*=\s*True', 'command_injection', VulnSeverity.CRITICAL),
            (r'eval\s*\([^)]*(?:input|request|param)', 'code_injection', VulnSeverity.CRITICAL),
            
            # Path Traversal
            (r'open\s*\([^)]*(?:\.\.|\+|%)', 'path_traversal', VulnSeverity.HIGH),
            
            # Deserialization
            (r'pickle\.loads?\s*\(', 'unsafe_deserialization', VulnSeverity.CRITICAL),
            (r'yaml\.(?:load|unsafe_load)\s*\([^)]*Loader', 'unsafe_deserialization', VulnSeverity.HIGH),
            
            # SSTI
            (r'render_template_string\s*\([^)]*(?:request|param)', 'ssti', VulnSeverity.CRITICAL),
            (r'Template\s*\([^)]*(?:request|param)', 'ssti', VulnSeverity.HIGH),
            
            # XXE
            (r'etree\.parse\s*\(', 'xxe', VulnSeverity.HIGH),
            
            # Hardcoded Secrets
            (r'(?:password|secret|api_key|token)\s*=\s*["\'][^"\']{8,}["\']', 'hardcoded_secret', VulnSeverity.MEDIUM),
        ]
        
        import re
        
        for file_path in source_path.rglob('*.py'):
            try:
                content = file_path.read_text(errors='ignore')
                lines = content.split('\n')
                
                for pattern, vuln_type, severity in patterns:
                    for i, line in enumerate(lines, 1):
                        if re.search(pattern, line, re.IGNORECASE):
                            finding = VulnFinding(
                                id=hashlib.md5(f"{file_path}{i}{vuln_type}".encode()).hexdigest()[:12],
                                file=str(file_path),
                                line=i,
                                vuln_type=vuln_type,
                                severity=severity,
                                code_snippet=line.strip(),
                                description=f"Potential {vuln_type.replace('_', ' ')} vulnerability",
                                engine='custom_patterns'
                            )
                            findings.append(finding)
                            
            except Exception as e:
                logger.warning(f"Error scanning {file_path}: {e}")
        
        return findings


# ═══════════════════════════════════════════════════════════════════════════════
# 0DAY DAEMON
# ═══════════════════════════════════════════════════════════════════════════════

class ZerodayDaemon:
    """
    0day Hunter Daemon
    
    Continuously scans source code for vulnerabilities.
    Stops when finding critical exploitable vulnerability.
    """
    
    def __init__(self, targets: List[str], brain: BrainX = None):
        self.targets = targets
        self.brain = brain
        self.running = False
        self.iteration = 0
        self.findings: List[VulnFinding] = []
        self.seen_ids: Set[str] = set()
        self.start_time = None
        self.current_target = ""
        
        # Signal handlers
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle stop signals"""
        logger.info(f"📛 Received signal {signum}, stopping...")
        self.running = False
    
    async def start(self):
        """Start the daemon"""
        self.running = True
        self.start_time = datetime.now()
        
        # Save PID
        PID_FILE.write_text(str(os.getpid()))
        
        # Load previous findings to avoid duplicates
        self._load_seen()
        
        logger.info("=" * 60)
        logger.info("🔬 0day Hunter Daemon Started")
        logger.info(f"   Targets: {len(self.targets)}")
        logger.info(f"   PID: {os.getpid()}")
        logger.info("   Will hunt until 0day found!")
        logger.info("=" * 60)
        
        await self._hunt_loop()
    
    async def _hunt_loop(self):
        """Main hunting loop"""
        
        while self.running:
            self.iteration += 1
            
            logger.info(f"\n🔄 Hunting iteration {self.iteration}")
            
            for target in self.targets:
                if not self.running:
                    break
                
                self.current_target = target
                self._update_status()
                
                target_path = Path(target)
                
                if not target_path.exists():
                    # Maybe it's a git URL?
                    if target.startswith('http') or target.startswith('git@'):
                        target_path = await self._clone_repo(target)
                    else:
                        logger.warning(f"Target not found: {target}")
                        continue
                
                # Run all SAST engines
                new_findings = await self._scan_target(target_path)
                
                # Filter new findings
                new_findings = [f for f in new_findings if f.id not in self.seen_ids]
                
                if new_findings:
                    logger.info(f"  🎯 Found {len(new_findings)} new potential vulnerabilities")
                    
                    # AI analysis
                    if self.brain:
                        new_findings = await self._ai_analyze(new_findings)
                    
                    # Check for critical exploitable vulns
                    critical = [f for f in new_findings 
                               if f.severity == VulnSeverity.CRITICAL and f.exploitable]
                    
                    if critical:
                        logger.info("=" * 60)
                        logger.info("🚨 CRITICAL 0DAY FOUND!")
                        for f in critical:
                            logger.info(f"  • {f.vuln_type}: {f.file}:{f.line}")
                        logger.info("=" * 60)
                        
                        # Generate exploits
                        await self._generate_exploits(critical)
                        
                        # Save and stop
                        self.findings.extend(new_findings)
                        self._save_findings()
                        self.running = False
                        break
                    
                    # Add to findings
                    self.findings.extend(new_findings)
                    for f in new_findings:
                        self.seen_ids.add(f.id)
            
            # Save progress
            self._save_findings()
            self._update_status()
            
            if self.running:
                # Wait before next iteration
                logger.info(f"  💤 Sleeping 60s before next hunt...")
                await asyncio.sleep(60)
        
        # Cleanup
        self._cleanup()
    
    async def _clone_repo(self, url: str) -> Path:
        """Clone git repository"""
        dest = Path('/tmp/brainx_0day') / hashlib.md5(url.encode()).hexdigest()[:8]
        
        if dest.exists():
            # Update
            subprocess.run(['git', 'pull'], cwd=dest, capture_output=True, timeout=120)
        else:
            # Clone
            dest.parent.mkdir(parents=True, exist_ok=True)
            subprocess.run(
                ['git', 'clone', '--depth', '1', url, str(dest)],
                capture_output=True, timeout=300
            )
        
        return dest
    
    async def _scan_target(self, target_path: Path) -> List[VulnFinding]:
        """Scan target with all engines"""
        all_findings = []
        
        logger.info(f"  🔍 Scanning: {target_path}")
        
        # Semgrep
        semgrep_findings = SASTEngine.run_semgrep(target_path)
        logger.info(f"    ✓ Semgrep: {len(semgrep_findings)} findings")
        all_findings.extend(semgrep_findings)
        
        # Bandit (Python)
        bandit_findings = SASTEngine.run_bandit(target_path)
        logger.info(f"    ✓ Bandit: {len(bandit_findings)} findings")
        all_findings.extend(bandit_findings)
        
        # Custom patterns
        custom_findings = SASTEngine.run_custom_patterns(target_path)
        logger.info(f"    ✓ Custom: {len(custom_findings)} findings")
        all_findings.extend(custom_findings)
        
        # Deduplicate
        seen = set()
        unique = []
        for f in all_findings:
            key = f"{f.file}:{f.line}:{f.vuln_type}"
            if key not in seen:
                seen.add(key)
                unique.append(f)
        
        return unique
    
    async def _ai_analyze(self, findings: List[VulnFinding]) -> List[VulnFinding]:
        """Use AI to analyze findings"""
        logger.info(f"  🧠 AI analyzing {len(findings)} findings...")
        
        for finding in findings[:20]:  # Limit to avoid rate limits
            try:
                task = BrainTask(
                    task_type=TaskType.GENERAL,
                    input_data=f"""Analyze this vulnerability for 0day potential:

File: {finding.file}
Line: {finding.line}
Type: {finding.vuln_type}
Severity: {finding.severity.value}
Code: ```
{finding.code_snippet[:500]}
```
Description: {finding.description}

Answer concisely:
1. Is this a real vulnerability? (yes/no)
2. Is it exploitable? (yes/no)  
3. CVE potential? (yes/no)
4. Brief explanation (1-2 sentences)
"""
                )
                
                result = await self.brain.think(task)
                analysis = result.output.lower()
                
                finding.ai_analysis = result.output
                finding.exploitable = 'exploitable' in analysis and 'yes' in analysis
                finding.cve_potential = 'cve' in analysis and 'yes' in analysis
                
            except Exception as e:
                logger.warning(f"AI analysis failed: {e}")
        
        return findings
    
    async def _generate_exploits(self, findings: List[VulnFinding]):
        """Generate PoC exploits for critical findings"""
        if not self.brain:
            return
        
        logger.info("  🛠️  Generating exploits...")
        
        for finding in findings:
            try:
                task = BrainTask(
                    task_type=TaskType.GENERAL,
                    input_data=f"""Generate a working PoC exploit for this vulnerability:

Type: {finding.vuln_type}
File: {finding.file}
Line: {finding.line}
Code:
```
{finding.code_snippet}
```

Provide Python exploit code that demonstrates the vulnerability.
Include comments explaining each step.
"""
                )
                
                result = await self.brain.think(task)
                finding.poc_code = result.output
                
                # Save exploit to file
                exploit_file = RESULTS_DIR / f'exploit_{finding.id}.py'
                exploit_file.write_text(f"""#!/usr/bin/env python3
'''
0day Exploit - Auto-generated by BrainX
Target: {finding.file}:{finding.line}
Type: {finding.vuln_type}
Generated: {datetime.now().isoformat()}
'''

{result.output}
""")
                logger.info(f"    ✓ Exploit saved: {exploit_file}")
                
            except Exception as e:
                logger.warning(f"Exploit generation failed: {e}")
    
    def _save_findings(self):
        """Save findings to disk"""
        output_file = RESULTS_DIR / f'findings_{datetime.now().strftime("%Y%m%d")}.json'
        
        data = {
            'timestamp': datetime.now().isoformat(),
            'iterations': self.iteration,
            'targets': self.targets,
            'findings': [f.to_dict() for f in self.findings]
        }
        
        output_file.write_text(json.dumps(data, indent=2))
    
    def _load_seen(self):
        """Load previously seen finding IDs"""
        for f in RESULTS_DIR.glob('findings_*.json'):
            try:
                data = json.loads(f.read_text())
                for finding in data.get('findings', []):
                    self.seen_ids.add(finding.get('id', ''))
            except:
                pass
    
    def _update_status(self):
        """Update daemon status file"""
        status = DaemonStatus(
            running=self.running,
            pid=os.getpid(),
            started=self.start_time.isoformat() if self.start_time else "",
            iterations=self.iteration,
            findings_count=len(self.findings),
            last_scan=datetime.now().isoformat(),
            targets=self.targets,
            current_target=self.current_target
        )
        
        STATUS_FILE.write_text(json.dumps(asdict(status), indent=2))
    
    def _cleanup(self):
        """Cleanup on exit"""
        logger.info("🧹 Cleaning up...")
        
        PID_FILE.unlink(missing_ok=True)
        
        # Final save
        self._save_findings()
        self._update_status()
        
        logger.info(f"✓ Daemon stopped. Total findings: {len(self.findings)}")


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

async def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description='0day Hunter Daemon',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Start daemon with local source
  python zeroday_daemon.py start /path/to/source
  
  # Start with multiple targets
  python zeroday_daemon.py start /src1 /src2 https://github.com/user/repo
  
  # Check status
  python zeroday_daemon.py status
  
  # Stop daemon
  python zeroday_daemon.py stop
"""
    )
    
    subparsers = parser.add_subparsers(dest='command')
    
    # Start
    start = subparsers.add_parser('start', help='Start daemon')
    start.add_argument('targets', nargs='+', help='Source paths or git URLs')
    
    # Stop
    subparsers.add_parser('stop', help='Stop daemon')
    
    # Status
    subparsers.add_parser('status', help='Check status')
    
    args = parser.parse_args()
    
    if args.command == 'start':
        # Check if already running
        if PID_FILE.exists():
            try:
                pid = int(PID_FILE.read_text())
                os.kill(pid, 0)
                print(f"⚠️  Daemon already running (PID {pid})")
                return
            except:
                PID_FILE.unlink()
        
        # Save targets
        TARGETS_FILE.write_text(json.dumps(args.targets))
        
        # Initialize brain
        brain = BrainX(verbose=False)
        try:
            await brain.initialize()
        except:
            print("⚠️  AI offline, continuing without AI analysis")
            brain = None
        
        # Start daemon
        daemon = ZerodayDaemon(args.targets, brain)
        await daemon.start()
        
        if brain:
            await brain.close()
    
    elif args.command == 'stop':
        if PID_FILE.exists():
            pid = int(PID_FILE.read_text())
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"✓ Sent stop signal to daemon (PID {pid})")
            except ProcessLookupError:
                print("⚠️  Daemon not running")
                PID_FILE.unlink()
        else:
            print("⚠️  No daemon running")
    
    elif args.command == 'status':
        if STATUS_FILE.exists():
            status = json.loads(STATUS_FILE.read_text())
            
            running = status.get('running', False)
            if PID_FILE.exists():
                try:
                    pid = int(PID_FILE.read_text())
                    os.kill(pid, 0)
                except:
                    running = False
            
            icon = '🟢' if running else '🔴'
            
            print(f"\n{icon} 0day Hunter Daemon Status")
            print("-" * 40)
            print(f"  Running:     {'Yes' if running else 'No'}")
            print(f"  PID:         {status.get('pid', 'N/A')}")
            print(f"  Started:     {status.get('started', 'N/A')}")
            print(f"  Iterations:  {status.get('iterations', 0)}")
            print(f"  Findings:    {status.get('findings_count', 0)}")
            print(f"  Last Scan:   {status.get('last_scan', 'N/A')}")
            print(f"  Targets:     {status.get('targets', [])}")
            print()
        else:
            print("⚠️  No daemon status found")
    
    else:
        parser.print_help()


if __name__ == '__main__':
    asyncio.run(main())
